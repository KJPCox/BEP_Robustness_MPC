function plotexperiments(data)

yhat = data.yhat;
yref = data.yref;
yfb = data.yfb;
yfb_sinspec = data.yfb_sinspec;
v = data.v;
tout = data.tout;
umpc = data.umpc;
utot = data.utot;
sin_int = data.sin_int;
numper = data.numper;
tplant = data.tplant;
kc = data.kc;
fs_mpc = data.fs_mpc;

tmpc = yhat.time;

eUKF = yfb_sinspec-yhat.signals.values;
eMPC = yhat.signals.values-yref;

y_sinspec = reshape(yfb_sinspec(end-sin_int*numper/2+1:end),[sin_int,numper/2,1]);
    
Y = fft(y_sinspec);
        

[PY,PstdY,f] = fSingleSidedAmplitudeSpectrum(Y,fs_mpc);
PY(1) = []; PstdY(1) = []; f(1) = [];

figure
semilogy(f,PY)
xlabel('f [Hz]'), ylabel('magnitude [m]')
legend('output amplitude spectrum')


figure
hold on
plot(tplant,yfb,'k--')
plot(tmpc,yhat.signals.values,'r')
plot(tmpc,yref,'b')
legend('ymeas','yhat','yref')
xlabel('t [s]'),ylabel('y [m]')


figure
subplot(2,1,1)
plot(tmpc,eUKF)
ylabel('e [m]')
legend('eUKF = ymeas - yhat')
subplot(2,1,2)
plot(tmpc,eMPC)
xlabel('t [s]'), ylabel('e [m]')
legend('eMPC = yhat - yref')

figure
subplot(3,1,1)
plot(tout,v)
ylabel('u [V]')
legend('uOUT')
subplot(3,1,2)
plot(tmpc,umpc)
ylabel('u [V]')
legend('uMPC')
subplot(3,1,3)
plot(tplant,utot)
xlabel('t [s]'), ylabel('u [V]')
legend('uTOT')

figure
subplot(2,1,1)
plot(tplant,yfb)
ylabel('y [m]')
legend('yNL')
subplot(2,1,2)
plot(tplant,kc*(yfb.^3))
xlabel('t [s]'), ylabel('u [V]')
legend('uNL')
end
