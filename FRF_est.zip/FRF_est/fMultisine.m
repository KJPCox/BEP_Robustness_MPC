function varargout = fMultisine(fs,N,P,R,A,type,fmin,fmax,ngroup)
% Random phase multisine
%
% * fs = sampling frequency
% * N = number of samples per period
% * P = number of periods
% * R = number of realisations
% * A = signal amplitude
% * type is either 'full' or 'odd'
% * fmin can be left [] if a lowpass multisine is required
% * fmax = maximum excited frequency
% * ngroup = number of lines among which a detection line is randomly
%   selected (= Inf if no detection line required)
%
% J.P. No�l, VUB-ULg, 2015.

fres = fs/N;
flmax = ceil(fmax/fres);

if strcmp(type,'odd')
    flmax = flmax/2;
end

exclines = 1:flmax;                                        %DC always excluded

if ~isinf(ngroup)
    nempty = floor((flmax-ngroup)/ngroup);                 % number of detection lines
    randint = floor(ngroup*rand(nempty+1,1))+1;            % random choice of integer numbers from 1:1:Nblock
    detectlines = (0:nempty)'*ngroup + randint;
    exclines(detectlines) = [];
end

if strcmp(type,'odd')
    exclines = 2*exclines-1;
end

if ~isempty(fmin)
    flmin = ceil(fmin/fres);                               % conversion from lowpass to bandpass
    exclines(exclines < flmin) = [];
end

S = zeros(N,R);
S(exclines+1,:) = 1;

S = S.*exp(complex(0,2*pi*rand(size(S))));

s = 2*real(ifft(S));

if length(A) < R
    A = repmat(A,[1 R]); %same amplitude given to all realisations.
end
for i=1:R
    s(:,i) = A(i)*s(:,i)/std(s(:,i));
end

s = repmat(s,[1 1 P]); %NxRxP.
s = permute(s,[1 3 2]); %NxPxR.

if R == 1
    s = squeeze(s);
end

if nargout >= 1
    varargout(1) = {s};
end
if nargout >= 2
    varargout(2) = {exclines};
end

% Non-excited lines.
non_lines = 1:N/2;
non_lines(exclines+1) = [];
non_odd = non_lines(logical(mod(non_lines-1,2)))-1;
non_even = non_lines(~mod(non_lines-1,2))-1;

if nargout >= 3
    varargout(3) = {non_odd};
end
if nargout >= 4
    varargout(4) = {non_even};
end

end