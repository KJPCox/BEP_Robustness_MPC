/*
 * Closed_loop_SISO_New_types.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Closed_loop_SISO_New".
 *
 * Model version              : 1.114
 * Simulink Coder version : 9.0 (R2018b) 24-May-2018
 * C source code generated on : Thu Feb 25 12:23:56 2021
 *
 * Target selection: ectarget.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Closed_loop_SISO_New_types_h_
#define RTW_HEADER_Closed_loop_SISO_New_types_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
#include "zero_crossing_types.h"
#ifndef DEFINED_TYPEDEF_FOR_struct_2A8qfYst9mSmW2psmi5WuG_
#define DEFINED_TYPEDEF_FOR_struct_2A8qfYst9mSmW2psmi5WuG_

typedef struct {
  real_T dimensions;
  real_T values[327680];
} struct_2A8qfYst9mSmW2psmi5WuG;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_RujzpD6pgEnUG4zqMD67kG_
#define DEFINED_TYPEDEF_FOR_struct_RujzpD6pgEnUG4zqMD67kG_

typedef struct {
  real_T time[327680];
  struct_2A8qfYst9mSmW2psmi5WuG signals;
} struct_RujzpD6pgEnUG4zqMD67kG;

#endif

/* Parameters (default storage) */
typedef struct P_Closed_loop_SISO_New_T_ P_Closed_loop_SISO_New_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_Closed_loop_SISO_New_T RT_MODEL_Closed_loop_SISO_New_T;

#endif                                 /* RTW_HEADER_Closed_loop_SISO_New_types_h_ */
