/*
 * Closed_loop_SISO_New_dt.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Closed_loop_SISO_New".
 *
 * Model version              : 1.114
 * Simulink Coder version : 9.0 (R2018b) 24-May-2018
 * C source code generated on : Thu Feb 25 12:23:56 2021
 *
 * Target selection: ectarget.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "ext_types.h"

/* data type size table */
static uint_T rtDataTypeSizes[] = {
  sizeof(real_T),
  sizeof(real32_T),
  sizeof(int8_T),
  sizeof(uint8_T),
  sizeof(int16_T),
  sizeof(uint16_T),
  sizeof(int32_T),
  sizeof(uint32_T),
  sizeof(boolean_T),
  sizeof(fcn_call_T),
  sizeof(int_T),
  sizeof(pointer_T),
  sizeof(action_T),
  2*sizeof(uint32_T),
  sizeof(struct_2A8qfYst9mSmW2psmi5WuG),
  sizeof(struct_RujzpD6pgEnUG4zqMD67kG)
};

/* data type name table */
static const char_T * rtDataTypeNames[] = {
  "real_T",
  "real32_T",
  "int8_T",
  "uint8_T",
  "int16_T",
  "uint16_T",
  "int32_T",
  "uint32_T",
  "boolean_T",
  "fcn_call_T",
  "int_T",
  "pointer_T",
  "action_T",
  "timer_uint32_pair_T",
  "struct_2A8qfYst9mSmW2psmi5WuG",
  "struct_RujzpD6pgEnUG4zqMD67kG"
};

/* data type transitions for block I/O structure */
static DataTypeTransition rtBTransitions[] = {
  { (char_T *)(&Closed_loop_SISO_New_B.ec_EL3102_adc_a[0]), 0, 0, 21 },

  { (char_T *)(&Closed_loop_SISO_New_B.Compare), 8, 0, 1 }
  ,

  { (char_T *)(&Closed_loop_SISO_New_DW.TmpRTBAtSum1Inport1_Buffer0), 0, 0, 1 },

  { (char_T *)(&Closed_loop_SISO_New_DW.ToWorkspace_PWORK.LoggedData), 11, 0, 13
  },

  { (char_T *)(&Closed_loop_SISO_New_DW.FromWorkspace1_IWORK.PrevIndex), 10, 0,
    1 }
};

/* data type transition table for block I/O structure */
static DataTypeTransitionTable rtBTransTable = {
  5U,
  rtBTransitions
};

/* data type transitions for Parameters structure */
static DataTypeTransition rtPTransitions[] = {
  { (char_T *)(&Closed_loop_SISO_New_P.kc), 0, 0, 89 }
};

/* data type transition table for Parameters structure */
static DataTypeTransitionTable rtPTransTable = {
  1U,
  rtPTransitions
};

/* [EOF] Closed_loop_SISO_New_dt.h */
