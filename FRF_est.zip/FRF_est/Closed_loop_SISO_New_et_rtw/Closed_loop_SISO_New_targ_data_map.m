  function targMap = targDataMap(),

  ;%***********************
  ;% Create Parameter Map *
  ;%***********************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 1;
    sectIdxOffset = 0;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc paramMap
    ;%
    paramMap.nSections           = nTotSects;
    paramMap.sectIdxOffset       = sectIdxOffset;
      paramMap.sections(nTotSects) = dumSection; %prealloc
    paramMap.nTotData            = -1;
    
    ;%
    ;% Auto data (Closed_loop_SISO_New_P)
    ;%
      section.nData     = 44;
      section.data(44)  = dumData; %prealloc
      
	  ;% Closed_loop_SISO_New_P.kc
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% Closed_loop_SISO_New_P.ku1
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 1;
	
	  ;% Closed_loop_SISO_New_P.ku2
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 2;
	
	  ;% Closed_loop_SISO_New_P.ku3
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 3;
	
	  ;% Closed_loop_SISO_New_P.ku4
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 4;
	
	  ;% Closed_loop_SISO_New_P.ku5
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 5;
	
	  ;% Closed_loop_SISO_New_P.ky1
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 6;
	
	  ;% Closed_loop_SISO_New_P.ky2
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 7;
	
	  ;% Closed_loop_SISO_New_P.ky3
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 8;
	
	  ;% Closed_loop_SISO_New_P.ky4
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 9;
	
	  ;% Closed_loop_SISO_New_P.ky5
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 10;
	
	  ;% Closed_loop_SISO_New_P.o1
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 11;
	
	  ;% Closed_loop_SISO_New_P.o2
	  section.data(13).logicalSrcIdx = 12;
	  section.data(13).dtTransOffset = 12;
	
	  ;% Closed_loop_SISO_New_P.o3
	  section.data(14).logicalSrcIdx = 13;
	  section.data(14).dtTransOffset = 13;
	
	  ;% Closed_loop_SISO_New_P.o4
	  section.data(15).logicalSrcIdx = 14;
	  section.data(15).dtTransOffset = 14;
	
	  ;% Closed_loop_SISO_New_P.o5
	  section.data(16).logicalSrcIdx = 15;
	  section.data(16).dtTransOffset = 15;
	
	  ;% Closed_loop_SISO_New_P.p1
	  section.data(17).logicalSrcIdx = 16;
	  section.data(17).dtTransOffset = 16;
	
	  ;% Closed_loop_SISO_New_P.p2
	  section.data(18).logicalSrcIdx = 17;
	  section.data(18).dtTransOffset = 25;
	
	  ;% Closed_loop_SISO_New_P.p3
	  section.data(19).logicalSrcIdx = 18;
	  section.data(19).dtTransOffset = 34;
	
	  ;% Closed_loop_SISO_New_P.p4
	  section.data(20).logicalSrcIdx = 19;
	  section.data(20).dtTransOffset = 43;
	
	  ;% Closed_loop_SISO_New_P.p5
	  section.data(21).logicalSrcIdx = 20;
	  section.data(21).dtTransOffset = 52;
	
	  ;% Closed_loop_SISO_New_P.y_offset
	  section.data(22).logicalSrcIdx = 21;
	  section.data(22).dtTransOffset = 61;
	
	  ;% Closed_loop_SISO_New_P.CompareToConstant_const
	  section.data(23).logicalSrcIdx = 22;
	  section.data(23).dtTransOffset = 62;
	
	  ;% Closed_loop_SISO_New_P.nsensor_Value
	  section.data(24).logicalSrcIdx = 23;
	  section.data(24).dtTransOffset = 63;
	
	  ;% Closed_loop_SISO_New_P.ec_EL3102_adc_P1_Size
	  section.data(25).logicalSrcIdx = 24;
	  section.data(25).dtTransOffset = 64;
	
	  ;% Closed_loop_SISO_New_P.ec_EL3102_adc_P1
	  section.data(26).logicalSrcIdx = 25;
	  section.data(26).dtTransOffset = 66;
	
	  ;% Closed_loop_SISO_New_P.ec_EL3102_adc_P1_Size_j
	  section.data(27).logicalSrcIdx = 26;
	  section.data(27).dtTransOffset = 67;
	
	  ;% Closed_loop_SISO_New_P.ec_EL3102_adc_P1_o
	  section.data(28).logicalSrcIdx = 27;
	  section.data(28).dtTransOffset = 69;
	
	  ;% Closed_loop_SISO_New_P.ec_EL3102_adc_P1_Size_k
	  section.data(29).logicalSrcIdx = 28;
	  section.data(29).dtTransOffset = 70;
	
	  ;% Closed_loop_SISO_New_P.ec_EL3102_adc_P1_b
	  section.data(30).logicalSrcIdx = 29;
	  section.data(30).dtTransOffset = 72;
	
	  ;% Closed_loop_SISO_New_P.Constant_Value
	  section.data(31).logicalSrcIdx = 30;
	  section.data(31).dtTransOffset = 73;
	
	  ;% Closed_loop_SISO_New_P.ec_EL4132_dac_P1_Size
	  section.data(32).logicalSrcIdx = 31;
	  section.data(32).dtTransOffset = 74;
	
	  ;% Closed_loop_SISO_New_P.ec_EL4132_dac_P1
	  section.data(33).logicalSrcIdx = 32;
	  section.data(33).dtTransOffset = 76;
	
	  ;% Closed_loop_SISO_New_P.TmpRTBAtSum1Inport1_InitialCond
	  section.data(34).logicalSrcIdx = 33;
	  section.data(34).dtTransOffset = 77;
	
	  ;% Closed_loop_SISO_New_P.Saturation_UpperSat
	  section.data(35).logicalSrcIdx = 34;
	  section.data(35).dtTransOffset = 78;
	
	  ;% Closed_loop_SISO_New_P.Saturation_LowerSat
	  section.data(36).logicalSrcIdx = 35;
	  section.data(36).dtTransOffset = 79;
	
	  ;% Closed_loop_SISO_New_P.ec_EL4132_dac_P1_Size_n
	  section.data(37).logicalSrcIdx = 36;
	  section.data(37).dtTransOffset = 80;
	
	  ;% Closed_loop_SISO_New_P.ec_EL4132_dac_P1_p
	  section.data(38).logicalSrcIdx = 37;
	  section.data(38).dtTransOffset = 82;
	
	  ;% Closed_loop_SISO_New_P.Saturation1_UpperSat
	  section.data(39).logicalSrcIdx = 38;
	  section.data(39).dtTransOffset = 83;
	
	  ;% Closed_loop_SISO_New_P.Saturation1_LowerSat
	  section.data(40).logicalSrcIdx = 39;
	  section.data(40).dtTransOffset = 84;
	
	  ;% Closed_loop_SISO_New_P.Saturation2_UpperSat
	  section.data(41).logicalSrcIdx = 40;
	  section.data(41).dtTransOffset = 85;
	
	  ;% Closed_loop_SISO_New_P.Saturation2_LowerSat
	  section.data(42).logicalSrcIdx = 41;
	  section.data(42).dtTransOffset = 86;
	
	  ;% Closed_loop_SISO_New_P.Saturation2_UpperSat_a
	  section.data(43).logicalSrcIdx = 42;
	  section.data(43).dtTransOffset = 87;
	
	  ;% Closed_loop_SISO_New_P.Saturation2_LowerSat_b
	  section.data(44).logicalSrcIdx = 43;
	  section.data(44).dtTransOffset = 88;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(1) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (parameter)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    paramMap.nTotData = nTotData;
    


  ;%**************************
  ;% Create Block Output Map *
  ;%**************************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 2;
    sectIdxOffset = 0;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc sigMap
    ;%
    sigMap.nSections           = nTotSects;
    sigMap.sectIdxOffset       = sectIdxOffset;
      sigMap.sections(nTotSects) = dumSection; %prealloc
    sigMap.nTotData            = -1;
    
    ;%
    ;% Auto data (Closed_loop_SISO_New_B)
    ;%
      section.nData     = 18;
      section.data(18)  = dumData; %prealloc
      
	  ;% Closed_loop_SISO_New_B.ec_EL3102_adc_a
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% Closed_loop_SISO_New_B.Gain9
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 2;
	
	  ;% Closed_loop_SISO_New_B.Gain8
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 3;
	
	  ;% Closed_loop_SISO_New_B.ec_EL3102_adc_f
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 4;
	
	  ;% Closed_loop_SISO_New_B.Gain7
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 6;
	
	  ;% Closed_loop_SISO_New_B.Gain6
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 7;
	
	  ;% Closed_loop_SISO_New_B.ec_EL3102_adc_m
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 8;
	
	  ;% Closed_loop_SISO_New_B.Gain5
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 10;
	
	  ;% Closed_loop_SISO_New_B.y
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 11;
	
	  ;% Closed_loop_SISO_New_B.Sum
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 12;
	
	  ;% Closed_loop_SISO_New_B.y_n
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 13;
	
	  ;% Closed_loop_SISO_New_B.TmpRTBAtSum1Inport1
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 14;
	
	  ;% Closed_loop_SISO_New_B.utot
	  section.data(13).logicalSrcIdx = 12;
	  section.data(13).dtTransOffset = 15;
	
	  ;% Closed_loop_SISO_New_B.Saturation
	  section.data(14).logicalSrcIdx = 13;
	  section.data(14).dtTransOffset = 16;
	
	  ;% Closed_loop_SISO_New_B.Saturation1
	  section.data(15).logicalSrcIdx = 14;
	  section.data(15).dtTransOffset = 17;
	
	  ;% Closed_loop_SISO_New_B.Saturation2
	  section.data(16).logicalSrcIdx = 15;
	  section.data(16).dtTransOffset = 18;
	
	  ;% Closed_loop_SISO_New_B.Saturation2_e
	  section.data(17).logicalSrcIdx = 16;
	  section.data(17).dtTransOffset = 19;
	
	  ;% Closed_loop_SISO_New_B.v
	  section.data(18).logicalSrcIdx = 17;
	  section.data(18).dtTransOffset = 20;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(1) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% Closed_loop_SISO_New_B.Compare
	  section.data(1).logicalSrcIdx = 18;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(2) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (signal)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    sigMap.nTotData = nTotData;
    


  ;%*******************
  ;% Create DWork Map *
  ;%*******************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 3;
    sectIdxOffset = 2;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc dworkMap
    ;%
    dworkMap.nSections           = nTotSects;
    dworkMap.sectIdxOffset       = sectIdxOffset;
      dworkMap.sections(nTotSects) = dumSection; %prealloc
    dworkMap.nTotData            = -1;
    
    ;%
    ;% Auto data (Closed_loop_SISO_New_DW)
    ;%
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% Closed_loop_SISO_New_DW.TmpRTBAtSum1Inport1_Buffer0
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(1) = section;
      clear section
      
      section.nData     = 8;
      section.data(8)  = dumData; %prealloc
      
	  ;% Closed_loop_SISO_New_DW.ToWorkspace_PWORK.LoggedData
	  section.data(1).logicalSrcIdx = 1;
	  section.data(1).dtTransOffset = 0;
	
	  ;% Closed_loop_SISO_New_DW.ToWorkspace1_PWORK.LoggedData
	  section.data(2).logicalSrcIdx = 2;
	  section.data(2).dtTransOffset = 1;
	
	  ;% Closed_loop_SISO_New_DW.input_sensor_PWORK.LoggedData
	  section.data(3).logicalSrcIdx = 3;
	  section.data(3).dtTransOffset = 2;
	
	  ;% Closed_loop_SISO_New_DW.output_sensor_PWORK.LoggedData
	  section.data(4).logicalSrcIdx = 4;
	  section.data(4).dtTransOffset = 3;
	
	  ;% Closed_loop_SISO_New_DW.y_PWORK.LoggedData
	  section.data(5).logicalSrcIdx = 5;
	  section.data(5).dtTransOffset = 4;
	
	  ;% Closed_loop_SISO_New_DW.FromWorkspace1_PWORK.TimePtr
	  section.data(6).logicalSrcIdx = 6;
	  section.data(6).dtTransOffset = 5;
	
	  ;% Closed_loop_SISO_New_DW.Scope1_PWORK.LoggedData
	  section.data(7).logicalSrcIdx = 7;
	  section.data(7).dtTransOffset = 6;
	
	  ;% Closed_loop_SISO_New_DW.Scope_PWORK.LoggedData
	  section.data(8).logicalSrcIdx = 8;
	  section.data(8).dtTransOffset = 12;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(2) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% Closed_loop_SISO_New_DW.FromWorkspace1_IWORK.PrevIndex
	  section.data(1).logicalSrcIdx = 9;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(3) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (dwork)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    dworkMap.nTotData = nTotData;
    


  ;%
  ;% Add individual maps to base struct.
  ;%

  targMap.paramMap  = paramMap;    
  targMap.signalMap = sigMap;
  targMap.dworkMap  = dworkMap;
  
  ;%
  ;% Add checksums to base struct.
  ;%


  targMap.checksum0 = 264527593;
  targMap.checksum1 = 2335964818;
  targMap.checksum2 = 1817800176;
  targMap.checksum3 = 3448516955;

