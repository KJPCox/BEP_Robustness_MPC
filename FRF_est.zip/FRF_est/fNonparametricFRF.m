function [G,covG] = fNonparametricFRF(U,Y) 
% fNonparametricFRF outputs:
%       - (G) nonparametric FRF;
%       - (covG) total covariance of the estimate G (= stochastic nonlinear
%         contributions + noise).
% Based on inputs:
%       - (U) [N x P x R] FFT of steady-state input data, where P is the
%       number of periods, N the number of data points per period and R > 1
%       the number of realisations;
%       - (Y) [N x P x R] FFT of steady-state measurement data.

R = size(Y,3);

Umean = mean(U,2); % Average over periods
Ymean = mean(Y,2); % Average over periods

G_ = squeeze(Ymean./Umean);
G = mean(G_,2); % Average over realisations

NG = G_ - repmat(G,[1 R]); % G - Gmean for every [N x R]
covG = squeeze(1/(R-1)/R*sum(abs(NG).^2,2));
end