function xk1 = StateFcn(xk,U)
    % Extract input and output from U
    uk = U(26);
    yk = U(1);
    
    % Recreate discrete state-space matrices from U
    Ad = reshape(U(2:17),4,4);
    Bd = reshape(U(18:21),4,1);
    Ed = reshape(U(22:25),4,1);
    
    % State equation
    xk1 = Ad*xk + Bd*uk + Ed*yk^3;
end