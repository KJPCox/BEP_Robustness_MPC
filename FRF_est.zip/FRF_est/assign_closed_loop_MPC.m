%------------------------------------------------
% Assign parameters to simulink
%------------------------------------------------
ws = get_param('Closed_loop_MPC','modelworkspace');

% Assign simulation options
assignin(ws,'tmax',max(uff.time));
assignin(ws,'Ts',Ts);

% Assign input signals
assignin(ws,'uff',uff);

% Assign feedback controller parameters
% assignin(ws,'A',A);
% assignin(ws,'B',B);
% assignin(ws,'C',C);
% assignin(ws,'D',D);

% Assign polynomials
assignin(ws,'p1',p{1});
assignin(ws,'p2',p{3}); % using p{3} improves final mapping
assignin(ws,'p3',p{3});
assignin(ws,'p4',p{4});
assignin(ws,'p5',p{5});

% Assign offset
assignin(ws,'o1',o{1});
assignin(ws,'o2',o{2});
assignin(ws,'o3',o{3});
assignin(ws,'o4',o{4});
assignin(ws,'o5',o{5});

% Assign voltage gain
assignin(ws,'ku1',ku{1});
assignin(ws,'ku2',ku{2});
assignin(ws,'ku3',ku{3});
assignin(ws,'ku4',ku{4});
assignin(ws,'ku5',ku{5});

% Assign calibration gain
assignin(ws,'ky1',ky{1});
assignin(ws,'ky2',ky{2});
assignin(ws,'ky3',ky{3});
assignin(ws,'ky4',ky{4});
assignin(ws,'ky5',ky{5});