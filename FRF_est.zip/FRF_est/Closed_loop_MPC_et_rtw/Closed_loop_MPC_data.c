/*
 * Closed_loop_MPC_data.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Closed_loop_MPC".
 *
 * Model version              : 1.120
 * Simulink Coder version : 9.0 (R2018b) 24-May-2018
 * C source code generated on : Tue Jun 15 11:15:40 2021
 *
 * Target selection: ectarget.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Closed_loop_MPC.h"
#include "Closed_loop_MPC_private.h"

/* Block parameters (default storage) */
P_Closed_loop_MPC_T Closed_loop_MPC_P = {
  /* Variable: mpc
   * Referenced by: '<S2>/MATLAB Function'
   */
  {
    { -0.0014363853360674125, -0.0008516381299695805, 0.0018656752177477131,
      0.0063558186810464285, 0.011874473326475876, 0.00511464639286077,
      0.011030223416583241, 0.016711449753258369, 0.021199077854935071,
      0.023819244216465328, 0.030634149843882557, 0.060153572669903191,
      0.0885007045652276, 0.11564091702002438, 0.14156014912818676,
      -0.015654410540543888, -0.032901971584953491, -0.051748601053218136,
      -0.072148903600862485, -0.094002798459529829, 1.0, 1.0, 1.0, 1.0, 1.0 },

    { -3.5598038640204718e-6, 7.9500787172662266e-5, 0.0002373710852394791,
      0.0004503121159673371, 0.00069496149184181686, 0.0, -3.5598038640204718e-6,
      7.9500787172662266e-5, 0.0002373710852394791, 0.0004503121159673371, 0.0,
      0.0, -3.5598038640204718e-6, 7.9500787172662266e-5, 0.0002373710852394791,
      0.0, 0.0, 0.0, -3.5598038640204718e-6, 7.9500787172662266e-5, 0.0, 0.0,
      0.0, 0.0, -3.5598038640204718e-6 },

    { -5575.49001714529, -178414.97975462838, -494090.7042003863,
      -913219.06513564382, -1390044.8546164054, 0.0, -5575.49001714529,
      -178414.97975462838, -494090.7042003863, -913219.06513564382, 0.0, 0.0,
      -5575.49001714529, -178414.97975462838, -494090.7042003863, 0.0, 0.0, 0.0,
      -5575.49001714529, -178414.97975462838, 0.0, 0.0, 0.0, 0.0,
      -5575.49001714529 },

    { 300000000.0, 0.0, 0.0, 0.0, 0.0, 0.0, 300000000.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      300000000.0, 0.0, 0.0, 0.0, 0.0, 0.0, 300000000.0, 0.0, 0.0, 0.0, 0.0, 0.0,
      300000000.0 },

    { 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0,
      0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0 },
    5.0,

    { 0.88928010472199537, 0.44338440688267972, -0.0050508170853227567,
      0.016029403410655257, -0.46518487405067127, 0.87560436614483139,
      0.017415427675893835, -0.015042326734143761, 0.0054721456512482735,
      -0.021141243812100204, 0.98819800871857022, 0.040703733345033549,
      -0.018473649108702375, -0.048740734159598322, -0.049599396740143818,
      0.99047928447235944 },

    { 0.008483874638181222, 0.020641327534951459, -0.0099663665179975484,
      -0.018843557046552675 },

    { -0.0028924618738394386, 0.0034323793925787804, 0.031670401661820967,
      -0.01410399548663999 },
    0.001953125,
    0.009765625,
    0.0
  },

  /* Variable: Ad
   * Referenced by: '<S4>/Constant4'
   */
  { 0.88928010472199537, 0.44338440688267972, -0.0050508170853227567,
    0.016029403410655257, -0.46518487405067127, 0.87560436614483139,
    0.017415427675893835, -0.015042326734143761, 0.0054721456512482735,
    -0.021141243812100204, 0.98819800871857022, 0.040703733345033549,
    -0.018473649108702375, -0.048740734159598322, -0.049599396740143818,
    0.99047928447235944 },

  /* Variable: Bd
   * Referenced by: '<S4>/Constant3'
   */
  { 0.008483874638181222, 0.020641327534951459, -0.0099663665179975484,
    -0.018843557046552675 },

  /* Variable: Cc
   * Referenced by:
   *   '<Root>/Constant2'
   *   '<Root>/Gain1'
   *   '<S2>/Gain'
   *   '<S2>/Gain1'
   */
  { -0.0028924618738394386, 0.0034323793925787804, 0.031670401661820967,
    -0.01410399548663999 },

  /* Variable: Ed
   * Referenced by: '<S4>/Constant1'
   */
  { -1.5239757383134987E+7, -4.0950431703393951E+7, 1.9075377723034121E+7,
    3.6388508784201287E+7 },

  /* Variable: kc
   * Referenced by: '<Root>/Gain'
   */
  2.0E+9,

  /* Variable: ku1
   * Referenced by: '<S9>/Gain'
   */
  0.9,

  /* Variable: ku2
   * Referenced by: '<S9>/Gain1'
   */
  0.9,

  /* Variable: ku3
   * Referenced by: '<S9>/Gain2'
   */
  0.9,

  /* Variable: ku4
   * Referenced by: '<S9>/Gain3'
   */
  0.9,

  /* Variable: ku5
   * Referenced by: '<S9>/Gain4'
   */
  0.9,

  /* Variable: ky1
   * Referenced by: '<S9>/Gain9'
   */
  0.0014711270209060165,

  /* Variable: ky2
   * Referenced by: '<S9>/Gain8'
   */
  0.0010953537484850297,

  /* Variable: ky3
   * Referenced by: '<S9>/Gain7'
   */
  0.0013073093857132075,

  /* Variable: ky4
   * Referenced by: '<S9>/Gain6'
   */
  0.0016010332156881847,

  /* Variable: ky5
   * Referenced by: '<S9>/Gain5'
   */
  0.000931519218060358,

  /* Variable: o1
   * Referenced by: '<S9>/Constant'
   */
  3.9968160811765436,

  /* Variable: o2
   * Referenced by: '<S9>/Constant1'
   */
  4.416226011940485,

  /* Variable: o3
   * Referenced by: '<S9>/Constant2'
   */
  7.8718536098555614,

  /* Variable: o4
   * Referenced by: '<S9>/Constant3'
   */
  6.9928364017859774,

  /* Variable: o5
   * Referenced by: '<S9>/Constant5'
   */
  5.9916004708268584,

  /* Variable: p1
   * Referenced by: '<S9>/Polynomial'
   */
  { 0.0023790071185090366, -0.057630635083187817, 0.5896882252898068,
    -3.3209450195567691, 11.244874343339497, -23.502053155795878,
    30.015845809243448, -23.007983101497519, 11.864336262350207 },

  /* Variable: p2
   * Referenced by: '<S9>/Polynomial1'
   */
  { 0.00074322211504302359, -0.021362472547475635, 0.25244502957816212,
    -1.6164472306616784, 6.1785801271350138, -14.586712686983553,
    21.247636173693124, -19.073476076963949, 11.844168873563451 },

  /* Variable: p3
   * Referenced by: '<S9>/Polynomial2'
   */
  { 0.00074322211504302359, -0.021362472547475635, 0.25244502957816212,
    -1.6164472306616784, 6.1785801271350138, -14.586712686983553,
    21.247636173693124, -19.073476076963949, 11.844168873563451 },

  /* Variable: p4
   * Referenced by: '<S9>/Polynomial3'
   */
  { -0.00072279458047684608, 0.01402075217613682, -0.1085939164635078,
    0.40135172950343151, -0.51105216718729585, -1.2832980716721274,
    6.0006452077685362, -10.063497320587294, 9.84199867973437 },

  /* Variable: p5
   * Referenced by: '<S9>/Polynomial5'
   */
  { -0.00072279458047684608, 0.01402075217613682, -0.1085939164635078,
    0.40135172950343151, -0.51105216718729585, -1.2832980716721274,
    6.0006452077685362, -10.063497320587294, 9.84199867973437 },

  /* Variable: x0
   * Referenced by: '<S2>/Unit Delay'
   */
  { 0.0, 0.0, 0.0, 0.0 },

  /* Variable: y_offset
   * Referenced by: '<Root>/Constant1'
   */
  0.0049568832274905208,

  /* Mask Parameter: CompareToConstant_const
   * Referenced by: '<S1>/Constant'
   */
  0.0007,

  /* Expression: 1
   * Referenced by: '<Root>/nsensor'
   */
  1.0,

  /* Computed Parameter: ec_EL3102_adc_P1_Size
   * Referenced by: '<S10>/ec_EL3102_adc'
   */
  { 1.0, 1.0 },

  /* Expression: link_id
   * Referenced by: '<S10>/ec_EL3102_adc'
   */
  1.0,

  /* Computed Parameter: ec_EL3102_adc_P1_Size_j
   * Referenced by: '<S12>/ec_EL3102_adc'
   */
  { 1.0, 1.0 },

  /* Expression: link_id
   * Referenced by: '<S12>/ec_EL3102_adc'
   */
  2.0,

  /* Computed Parameter: ec_EL3102_adc_P1_Size_k
   * Referenced by: '<S11>/ec_EL3102_adc'
   */
  { 1.0, 1.0 },

  /* Expression: link_id
   * Referenced by: '<S11>/ec_EL3102_adc'
   */
  3.0,

  /* Expression: p.R{1}
   * Referenced by: '<S5>/R1'
   */
  1.0,

  /* Expression: 0
   * Referenced by: synthesized block
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S2>/Unit Delay2'
   */
  0.0,

  /* Expression: zeros(N+1,1)
   * Referenced by: '<S2>/Constant'
   */
  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

  /* Expression: 0
   * Referenced by: '<S2>/Unit Delay4'
   */
  0.0,

  /* Expression: 0
   * Referenced by: synthesized block
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S2>/Unit Delay3'
   */
  0.0,

  /* Expression: 0
   * Referenced by: synthesized block
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<Root>/Constant'
   */
  0.0,

  /* Expression: 0.0
   * Referenced by: '<S2>/Delay'
   */
  0.0,

  /* Expression: 0
   * Referenced by: synthesized block
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S2>/Unit Delay1'
   */
  0.0,

  /* Computed Parameter: ec_EL4132_dac_P1_Size
   * Referenced by: '<S13>/ec_EL4132_dac'
   */
  { 1.0, 1.0 },

  /* Expression: link_id
   * Referenced by: '<S13>/ec_EL4132_dac'
   */
  1.0,

  /* Expression: 2.5
   * Referenced by: '<S8>/Saturation'
   */
  2.5,

  /* Expression: -2.5
   * Referenced by: '<S8>/Saturation'
   */
  -2.5,

  /* Computed Parameter: ec_EL4132_dac_P1_Size_n
   * Referenced by: '<S14>/ec_EL4132_dac'
   */
  { 1.0, 1.0 },

  /* Expression: link_id
   * Referenced by: '<S14>/ec_EL4132_dac'
   */
  2.0,

  /* Expression: 2.5
   * Referenced by: '<S8>/Saturation1'
   */
  2.5,

  /* Expression: -2.5
   * Referenced by: '<S8>/Saturation1'
   */
  -2.5,

  /* Expression: 2.5
   * Referenced by: '<S8>/Saturation2'
   */
  2.5,

  /* Expression: -2.5
   * Referenced by: '<S8>/Saturation2'
   */
  -2.5,

  /* Expression: 2.5
   * Referenced by: '<S3>/Saturation2'
   */
  2.5,

  /* Expression: -2.5
   * Referenced by: '<S3>/Saturation2'
   */
  -2.5,

  /* Expression: p.Q
   * Referenced by: '<S5>/Q'
   */
  { 5.0, 0.0, 0.0, 0.0, 0.0, 5.0, 0.0, 0.0, 0.0, 0.0, 5.0, 0.0, 0.0, 0.0, 0.0,
    5.0 },

  /* Expression: p.InitialCovariance
   * Referenced by: '<S5>/DataStoreMemory - P'
   */
  { 0.001, 0.0, 0.0, 0.0, 0.0, 0.001, 0.0, 0.0, 0.0, 0.0, 0.001, 0.0, 0.0, 0.0,
    0.0, 0.001 },

  /* Expression: p.InitialState
   * Referenced by: '<S5>/DataStoreMemory - x'
   */
  { 0.0, 0.0, 0.0, 0.0 },

  /* Expression: true()
   * Referenced by: '<S5>/BlockOrdering'
   */
  1,

  /* Expression: true()
   * Referenced by: '<S5>/Enable1'
   */
  1,

  /* Computed Parameter: Delay_DelayLength
   * Referenced by: '<S2>/Delay'
   */
  0U
};
