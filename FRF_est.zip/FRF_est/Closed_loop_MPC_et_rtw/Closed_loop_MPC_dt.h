/*
 * Closed_loop_MPC_dt.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Closed_loop_MPC".
 *
 * Model version              : 1.120
 * Simulink Coder version : 9.0 (R2018b) 24-May-2018
 * C source code generated on : Tue Jun 15 11:15:40 2021
 *
 * Target selection: ectarget.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "ext_types.h"

/* data type size table */
static uint_T rtDataTypeSizes[] = {
  sizeof(real_T),
  sizeof(real32_T),
  sizeof(int8_T),
  sizeof(uint8_T),
  sizeof(int16_T),
  sizeof(uint16_T),
  sizeof(int32_T),
  sizeof(uint32_T),
  sizeof(boolean_T),
  sizeof(fcn_call_T),
  sizeof(int_T),
  sizeof(pointer_T),
  sizeof(action_T),
  2*sizeof(uint32_T),
  sizeof(struct_GRz8E8KusokWhh8FsKTDAD),
  sizeof(struct_rVo5tL04ryB5Cew6cWrJnF),
  sizeof(struct_l8AW0MJTHdrCC4rMsbiMbD)
};

/* data type name table */
static const char_T * rtDataTypeNames[] = {
  "real_T",
  "real32_T",
  "int8_T",
  "uint8_T",
  "int16_T",
  "uint16_T",
  "int32_T",
  "uint32_T",
  "boolean_T",
  "fcn_call_T",
  "int_T",
  "pointer_T",
  "action_T",
  "timer_uint32_pair_T",
  "struct_GRz8E8KusokWhh8FsKTDAD",
  "struct_rVo5tL04ryB5Cew6cWrJnF",
  "struct_l8AW0MJTHdrCC4rMsbiMbD"
};

/* data type transitions for block I/O structure */
static DataTypeTransition rtBTransitions[] = {
  { (char_T *)(&Closed_loop_MPC_B.ec_EL3102_adc_a[0]), 0, 0, 61 },

  { (char_T *)(&Closed_loop_MPC_B.Compare), 8, 0, 1 }
  ,

  { (char_T *)(&Closed_loop_MPC_DW.UnitDelay2_DSTATE[0]), 0, 0, 55 },

  { (char_T *)(&Closed_loop_MPC_DW.ToWorkspace_PWORK.LoggedData), 11, 0, 19 },

  { (char_T *)(&Closed_loop_MPC_DW.FromWorkspace1_IWORK.PrevIndex), 10, 0, 1 },

  { (char_T *)(&Closed_loop_MPC_DW.Correct1_SubsysRanBC), 2, 0, 1 }
};

/* data type transition table for block I/O structure */
static DataTypeTransitionTable rtBTransTable = {
  6U,
  rtBTransitions
};

/* data type transitions for Parameters structure */
static DataTypeTransition rtPTransitions[] = {
  { (char_T *)(&Closed_loop_MPC_P.mpc), 14, 0, 1 },

  { (char_T *)(&Closed_loop_MPC_P.Ad[0]), 0, 0, 172 },

  { (char_T *)(&Closed_loop_MPC_P.BlockOrdering_Value), 8, 0, 2 },

  { (char_T *)(&Closed_loop_MPC_P.Delay_DelayLength), 3, 0, 1 }
};

/* data type transition table for Parameters structure */
static DataTypeTransitionTable rtPTransTable = {
  4U,
  rtPTransitions
};

/* [EOF] Closed_loop_MPC_dt.h */
