/*
 * Closed_loop_MPC_types.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Closed_loop_MPC".
 *
 * Model version              : 1.120
 * Simulink Coder version : 9.0 (R2018b) 24-May-2018
 * C source code generated on : Tue Jun 15 11:15:40 2021
 *
 * Target selection: ectarget.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Closed_loop_MPC_types_h_
#define RTW_HEADER_Closed_loop_MPC_types_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
#include "zero_crossing_types.h"
#ifndef DEFINED_TYPEDEF_FOR_struct_GRz8E8KusokWhh8FsKTDAD_
#define DEFINED_TYPEDEF_FOR_struct_GRz8E8KusokWhh8FsKTDAD_

typedef struct {
  real_T Sx[25];
  real_T Su[25];
  real_T Sg[25];
  real_T Omega[25];
  real_T Psi[25];
  real_T N;
  real_T Ad[16];
  real_T Bd[4];
  real_T C[4];
  real_T ts_in;
  real_T ts_out;
  real_T osd;
} struct_GRz8E8KusokWhh8FsKTDAD;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_rVo5tL04ryB5Cew6cWrJnF_
#define DEFINED_TYPEDEF_FOR_struct_rVo5tL04ryB5Cew6cWrJnF_

typedef struct {
  real_T dimensions;
  real_T values[4100];
} struct_rVo5tL04ryB5Cew6cWrJnF;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_l8AW0MJTHdrCC4rMsbiMbD_
#define DEFINED_TYPEDEF_FOR_struct_l8AW0MJTHdrCC4rMsbiMbD_

typedef struct {
  real_T time[4100];
  struct_rVo5tL04ryB5Cew6cWrJnF signals;
} struct_l8AW0MJTHdrCC4rMsbiMbD;

#endif

#ifndef struct_emxArray_real_T
#define struct_emxArray_real_T

struct emxArray_real_T
{
  real_T *data;
  int32_T *size;
  int32_T allocatedSize;
  int32_T numDimensions;
  boolean_T canFreeData;
};

#endif                                 /*struct_emxArray_real_T*/

#ifndef typedef_emxArray_real_T_Closed_loop_M_T
#define typedef_emxArray_real_T_Closed_loop_M_T

typedef struct emxArray_real_T emxArray_real_T_Closed_loop_M_T;

#endif                                 /*typedef_emxArray_real_T_Closed_loop_M_T*/

/* Custom Type definition for MATLAB Function: '<S15>/Correct' */
#ifndef struct_tag_s6CvQ9GUK1lvWrphk2Hhm1C
#define struct_tag_s6CvQ9GUK1lvWrphk2Hhm1C

struct tag_s6CvQ9GUK1lvWrphk2Hhm1C
{
  char_T FcnName[14];
  boolean_T IsSimulinkFcn;
  real_T NumberOfExtraArgumentInports;
  boolean_T HasAdditiveNoise;
  real_T Alpha;
  real_T Beta;
  real_T Kappa;
};

#endif                                 /*struct_tag_s6CvQ9GUK1lvWrphk2Hhm1C*/

#ifndef typedef_s6CvQ9GUK1lvWrphk2Hhm1C_Close_T
#define typedef_s6CvQ9GUK1lvWrphk2Hhm1C_Close_T

typedef struct tag_s6CvQ9GUK1lvWrphk2Hhm1C s6CvQ9GUK1lvWrphk2Hhm1C_Close_T;

#endif                                 /*typedef_s6CvQ9GUK1lvWrphk2Hhm1C_Close_T*/

/* Custom Type definition for MATLAB Function: '<S17>/Predict' */
#ifndef struct_tag_slb7T4LagrVMMppno8nP56F
#define struct_tag_slb7T4LagrVMMppno8nP56F

struct tag_slb7T4LagrVMMppno8nP56F
{
  char_T FcnName[8];
  boolean_T IsSimulinkFcn;
  real_T NumberOfExtraArgumentInports;
  boolean_T HasAdditiveNoise;
  real_T Alpha;
  real_T Beta;
  real_T Kappa;
};

#endif                                 /*struct_tag_slb7T4LagrVMMppno8nP56F*/

#ifndef typedef_slb7T4LagrVMMppno8nP56F_Close_T
#define typedef_slb7T4LagrVMMppno8nP56F_Close_T

typedef struct tag_slb7T4LagrVMMppno8nP56F slb7T4LagrVMMppno8nP56F_Close_T;

#endif                                 /*typedef_slb7T4LagrVMMppno8nP56F_Close_T*/

/* Parameters (default storage) */
typedef struct P_Closed_loop_MPC_T_ P_Closed_loop_MPC_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_Closed_loop_MPC_T RT_MODEL_Closed_loop_MPC_T;

#endif                                 /* RTW_HEADER_Closed_loop_MPC_types_h_ */
