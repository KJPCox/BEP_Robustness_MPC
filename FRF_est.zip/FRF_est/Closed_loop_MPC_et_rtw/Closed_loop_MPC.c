/*
 * Closed_loop_MPC.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Closed_loop_MPC".
 *
 * Model version              : 1.120
 * Simulink Coder version : 9.0 (R2018b) 24-May-2018
 * C source code generated on : Tue Jun 15 11:15:40 2021
 *
 * Target selection: ectarget.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Closed_loop_MPC.h"
#include "Closed_loop_MPC_private.h"
#include "Closed_loop_MPC_dt.h"

/* Block signals (default storage) */
B_Closed_loop_MPC_T Closed_loop_MPC_B;

/* Block states (default storage) */
DW_Closed_loop_MPC_T Closed_loop_MPC_DW;

/* Real-time model */
RT_MODEL_Closed_loop_MPC_T Closed_loop_MPC_M_;
RT_MODEL_Closed_loop_MPC_T *const Closed_loop_MPC_M = &Closed_loop_MPC_M_;

/* Forward declaration for local functions */
static void Closed_loop_MPC_emxInit_real_T(emxArray_real_T_Closed_loop_M_T
  **pEmxArray, int32_T numDimensions);
static void Closed_emxEnsureCapacity_real_T(emxArray_real_T_Closed_loop_M_T
  *emxArray, int32_T oldNumel);
static void Closed_loop_MPC_power(const real_T a_data[], const int32_T *a_size,
  real_T y_data[], int32_T *y_size);
static real_T Closed_loop_MPC_xnrm2(int32_T n, const real_T x_data[], int32_T
  ix0);
static void Closed_loop_MPC_xgeqp3(real_T A_data[], int32_T A_size[2], real_T
  tau_data[], int32_T *tau_size, int32_T jpvt_data[], int32_T jpvt_size[2]);
static void Closed_loop_MPC_lusolve(const real_T A_data[], const int32_T A_size
  [2], const real_T B_data[], const int32_T B_size[2], real_T X_data[], int32_T
  X_size[2]);
static void Closed_loop_MPC_mldivide(const real_T A_data[], const int32_T
  A_size[2], const real_T B_data[], const int32_T B_size[2], real_T Y_data[],
  int32_T Y_size[2]);
static void Closed_loop_MPC_emxFree_real_T(emxArray_real_T_Closed_loop_M_T
  **pEmxArray);
static void rate_monotonic_scheduler(void);
int32_T div_nzp_s32_floor(int32_T numerator, int32_T denominator)
{
  uint32_T absNumerator;
  uint32_T absDenominator;
  uint32_T tempAbsQuotient;
  boolean_T quotientNeedsNegation;
  absNumerator = numerator < 0 ? ~(uint32_T)numerator + 1U : (uint32_T)numerator;
  absDenominator = denominator < 0 ? ~(uint32_T)denominator + 1U : (uint32_T)
    denominator;
  quotientNeedsNegation = ((numerator < 0) != (denominator < 0));
  tempAbsQuotient = absNumerator / absDenominator;
  if (quotientNeedsNegation) {
    absNumerator %= absDenominator;
    if (absNumerator > 0U) {
      tempAbsQuotient++;
    }
  }

  return quotientNeedsNegation ? -(int32_T)tempAbsQuotient : (int32_T)
    tempAbsQuotient;
}

time_T rt_SimUpdateDiscreteEvents(
  int_T rtmNumSampTimes, void *rtmTimingData, int_T *rtmSampleHitPtr, int_T
  *rtmPerTaskSampleHits )
{
  rtmSampleHitPtr[1] = rtmStepTask(Closed_loop_MPC_M, 1);
  rtmSampleHitPtr[2] = rtmStepTask(Closed_loop_MPC_M, 2);
  rtmSampleHitPtr[3] = rtmStepTask(Closed_loop_MPC_M, 3);
  UNUSED_PARAMETER(rtmNumSampTimes);
  UNUSED_PARAMETER(rtmTimingData);
  UNUSED_PARAMETER(rtmPerTaskSampleHits);
  return(-1);
}

/*
 *   This function updates active task flag for each subrate
 * and rate transition flags for tasks that exchange data.
 * The function assumes rate-monotonic multitasking scheduler.
 * The function must be called at model base rate so that
 * the generated code self-manages all its subrates and rate
 * transition flags.
 */
static void rate_monotonic_scheduler(void)
{
  /* To ensure a deterministic data transfer between two rates,
   * data is transferred at the priority of a fast task and the frequency
   * of the slow task.  The following flags indicate when the data transfer
   * happens.  That is, a rate interaction flag is set true when both rates
   * will run, and false otherwise.
   */

  /* tid 0 shares data with slower tid rate: 2 */
  Closed_loop_MPC_M->Timing.RateInteraction.TID0_2 =
    (Closed_loop_MPC_M->Timing.TaskCounters.TID[2] == 0);

  /* update PerTaskSampleHits matrix for non-inline sfcn */
  Closed_loop_MPC_M->Timing.perTaskSampleHits[2] =
    Closed_loop_MPC_M->Timing.RateInteraction.TID0_2;

  /* tid 1 shares data with slower tid rate: 2 */
  if (Closed_loop_MPC_M->Timing.TaskCounters.TID[1] == 0) {
    Closed_loop_MPC_M->Timing.RateInteraction.TID1_2 =
      (Closed_loop_MPC_M->Timing.TaskCounters.TID[2] == 0);

    /* update PerTaskSampleHits matrix for non-inline sfcn */
    Closed_loop_MPC_M->Timing.perTaskSampleHits[6] =
      Closed_loop_MPC_M->Timing.RateInteraction.TID1_2;
  }

  /* tid 2 shares data with slower tid rate: 3 */
  if (Closed_loop_MPC_M->Timing.TaskCounters.TID[2] == 0) {
    Closed_loop_MPC_M->Timing.RateInteraction.TID2_3 =
      (Closed_loop_MPC_M->Timing.TaskCounters.TID[3] == 0);

    /* update PerTaskSampleHits matrix for non-inline sfcn */
    Closed_loop_MPC_M->Timing.perTaskSampleHits[11] =
      Closed_loop_MPC_M->Timing.RateInteraction.TID2_3;
  }

  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (Closed_loop_MPC_M->Timing.TaskCounters.TID[2])++;
  if ((Closed_loop_MPC_M->Timing.TaskCounters.TID[2]) > 7) {/* Sample time: [0.001953125s, 0.0s] */
    Closed_loop_MPC_M->Timing.TaskCounters.TID[2] = 0;
  }

  (Closed_loop_MPC_M->Timing.TaskCounters.TID[3])++;
  if ((Closed_loop_MPC_M->Timing.TaskCounters.TID[3]) > 39) {/* Sample time: [0.009765625s, 0.0s] */
    Closed_loop_MPC_M->Timing.TaskCounters.TID[3] = 0;
  }
}

real_T rt_powd_snf(real_T u0, real_T u1)
{
  real_T y;
  real_T tmp;
  real_T tmp_0;
  if (rtIsNaN(u0) || rtIsNaN(u1)) {
    y = (rtNaN);
  } else {
    tmp = fabs(u0);
    tmp_0 = fabs(u1);
    if (rtIsInf(u1)) {
      if (tmp == 1.0) {
        y = 1.0;
      } else if (tmp > 1.0) {
        if (u1 > 0.0) {
          y = (rtInf);
        } else {
          y = 0.0;
        }
      } else if (u1 > 0.0) {
        y = 0.0;
      } else {
        y = (rtInf);
      }
    } else if (tmp_0 == 0.0) {
      y = 1.0;
    } else if (tmp_0 == 1.0) {
      if (u1 > 0.0) {
        y = u0;
      } else {
        y = 1.0 / u0;
      }
    } else if (u1 == 2.0) {
      y = u0 * u0;
    } else if ((u1 == 0.5) && (u0 >= 0.0)) {
      y = sqrt(u0);
    } else if ((u0 < 0.0) && (u1 > floor(u1))) {
      y = (rtNaN);
    } else {
      y = pow(u0, u1);
    }
  }

  return y;
}

static void Closed_loop_MPC_emxInit_real_T(emxArray_real_T_Closed_loop_M_T
  **pEmxArray, int32_T numDimensions)
{
  emxArray_real_T_Closed_loop_M_T *emxArray;
  int32_T i;
  *pEmxArray = (emxArray_real_T_Closed_loop_M_T *)malloc(sizeof
    (emxArray_real_T_Closed_loop_M_T));
  emxArray = *pEmxArray;
  emxArray->data = (real_T *)NULL;
  emxArray->numDimensions = numDimensions;
  emxArray->size = (int32_T *)malloc(sizeof(int32_T) * numDimensions);
  emxArray->allocatedSize = 0;
  emxArray->canFreeData = true;
  for (i = 0; i < numDimensions; i++) {
    emxArray->size[i] = 0;
  }
}

real_T rt_roundd_snf(real_T u)
{
  real_T y;
  if (fabs(u) < 4.503599627370496E+15) {
    if (u >= 0.5) {
      y = floor(u + 0.5);
    } else if (u > -0.5) {
      y = u * 0.0;
    } else {
      y = ceil(u - 0.5);
    }
  } else {
    y = u;
  }

  return y;
}

static void Closed_emxEnsureCapacity_real_T(emxArray_real_T_Closed_loop_M_T
  *emxArray, int32_T oldNumel)
{
  int32_T newNumel;
  int32_T i;
  void *newData;
  if (oldNumel < 0) {
    oldNumel = 0;
  }

  newNumel = 1;
  for (i = 0; i < emxArray->numDimensions; i++) {
    newNumel *= emxArray->size[i];
  }

  if (newNumel > emxArray->allocatedSize) {
    i = emxArray->allocatedSize;
    if (i < 16) {
      i = 16;
    }

    while (i < newNumel) {
      if (i > 1073741823) {
        i = MAX_int32_T;
      } else {
        i <<= 1;
      }
    }

    newData = calloc((uint32_T)i, sizeof(real_T));
    if (emxArray->data != NULL) {
      memcpy(newData, emxArray->data, sizeof(real_T) * oldNumel);
      if (emxArray->canFreeData) {
        free(emxArray->data);
      }
    }

    emxArray->data = (real_T *)newData;
    emxArray->allocatedSize = i;
    emxArray->canFreeData = true;
  }
}

/* Function for MATLAB Function: '<S2>/MATLAB Function' */
static void Closed_loop_MPC_power(const real_T a_data[], const int32_T *a_size,
  real_T y_data[], int32_T *y_size)
{
  real_T z1_data[11];
  int32_T loop_ub;
  int8_T a_idx_0;
  a_idx_0 = (int8_T)*a_size;
  if (0 <= a_idx_0 - 1) {
    memcpy(&z1_data[0], &y_data[0], a_idx_0 * sizeof(real_T));
  }

  for (loop_ub = 0; loop_ub < a_idx_0; loop_ub++) {
    z1_data[loop_ub] = rt_powd_snf(a_data[loop_ub], 3.0);
  }

  *y_size = (int8_T)*a_size;
  if (0 <= a_idx_0 - 1) {
    memcpy(&y_data[0], &z1_data[0], a_idx_0 * sizeof(real_T));
  }
}

/* Function for MATLAB Function: '<S2>/MATLAB Function' */
static real_T Closed_loop_MPC_xnrm2(int32_T n, const real_T x_data[], int32_T
  ix0)
{
  real_T y;
  real_T scale;
  int32_T kend;
  real_T absxk;
  real_T t;
  int32_T k;
  y = 0.0;
  if (n >= 1) {
    if (n == 1) {
      y = fabs(x_data[ix0 - 1]);
    } else {
      scale = 3.3121686421112381E-170;
      kend = (ix0 + n) - 1;
      for (k = ix0; k <= kend; k++) {
        absxk = fabs(x_data[k - 1]);
        if (absxk > scale) {
          t = scale / absxk;
          y = y * t * t + 1.0;
          scale = absxk;
        } else {
          t = absxk / scale;
          y += t * t;
        }
      }

      y = scale * sqrt(y);
    }
  }

  return y;
}

real_T rt_hypotd_snf(real_T u0, real_T u1)
{
  real_T y;
  real_T a;
  a = fabs(u0);
  y = fabs(u1);
  if (a < y) {
    a /= y;
    y *= sqrt(a * a + 1.0);
  } else if (a > y) {
    y /= a;
    y = sqrt(y * y + 1.0) * a;
  } else {
    if (!rtIsNaN(y)) {
      y = a * 1.4142135623730951;
    }
  }

  return y;
}

/* Function for MATLAB Function: '<S2>/MATLAB Function' */
static void Closed_loop_MPC_xgeqp3(real_T A_data[], int32_T A_size[2], real_T
  tau_data[], int32_T *tau_size, int32_T jpvt_data[], int32_T jpvt_size[2])
{
  int32_T m;
  int32_T n;
  int32_T mn;
  real_T work_data[5];
  real_T vn1_data[5];
  real_T vn2_data[5];
  int32_T i_i;
  int32_T nmi;
  int32_T b_n;
  int32_T yk;
  int32_T ix;
  real_T smax;
  real_T s;
  int32_T b_ix;
  int32_T iy;
  int32_T b_i;
  int32_T c_ix;
  int32_T h;
  int32_T b_ia;
  int32_T d_ix;
  int32_T exitg1;
  boolean_T exitg2;
  m = A_size[0];
  n = A_size[1];
  if (A_size[0] < A_size[1]) {
    mn = A_size[0];
  } else {
    mn = A_size[1];
  }

  *tau_size = (int8_T)mn;
  if (A_size[1] < 1) {
    b_n = 0;
  } else {
    b_n = A_size[1];
  }

  jpvt_size[0] = 1;
  jpvt_size[1] = b_n;
  if (b_n > 0) {
    jpvt_data[0] = 1;
    yk = 1;
    for (i_i = 2; i_i <= b_n; i_i++) {
      yk++;
      jpvt_data[i_i - 1] = yk;
    }
  }

  if ((A_size[0] != 0) && (A_size[1] != 0)) {
    b_n = (int8_T)A_size[1];
    for (b_ix = 0; b_ix < b_n; b_ix++) {
      work_data[b_ix] = 0.0;
    }

    b_n = 1;
    for (yk = 0; yk < n; yk++) {
      vn1_data[yk] = Closed_loop_MPC_xnrm2(m, A_data, b_n);
      vn2_data[yk] = vn1_data[yk];
      b_n += m;
    }

    for (b_n = 0; b_n < mn; b_n++) {
      i_i = b_n * m + b_n;
      nmi = n - b_n;
      yk = m - b_n;
      if (nmi < 1) {
        b_i = 0;
      } else {
        b_i = 1;
        if (nmi > 1) {
          ix = b_n;
          smax = fabs(vn1_data[b_n]);
          for (b_ix = 2; b_ix <= nmi; b_ix++) {
            ix++;
            s = fabs(vn1_data[ix]);
            if (s > smax) {
              b_i = b_ix;
              smax = s;
            }
          }
        }
      }

      ix = (b_n + b_i) - 1;
      if (ix + 1 != b_n + 1) {
        b_ix = m * ix;
        iy = m * b_n;
        for (b_i = 0; b_i < m; b_i++) {
          smax = A_data[b_ix];
          A_data[b_ix] = A_data[iy];
          A_data[iy] = smax;
          b_ix++;
          iy++;
        }

        b_ix = jpvt_data[ix];
        jpvt_data[ix] = jpvt_data[b_n];
        jpvt_data[b_n] = b_ix;
        vn1_data[ix] = vn1_data[b_n];
        vn2_data[ix] = vn2_data[b_n];
      }

      if (b_n + 1 < m) {
        smax = A_data[i_i];
        tau_data[b_n] = 0.0;
        if (yk > 0) {
          s = Closed_loop_MPC_xnrm2(yk - 1, A_data, i_i + 2);
          if (s != 0.0) {
            s = rt_hypotd_snf(A_data[i_i], s);
            if (A_data[i_i] >= 0.0) {
              s = -s;
            }

            if (fabs(s) < 1.0020841800044864E-292) {
              ix = -1;
              b_ix = i_i + yk;
              do {
                ix++;
                for (iy = i_i + 1; iy < b_ix; iy++) {
                  A_data[iy] *= 9.9792015476736E+291;
                }

                s *= 9.9792015476736E+291;
                smax *= 9.9792015476736E+291;
              } while (!(fabs(s) >= 1.0020841800044864E-292));

              s = rt_hypotd_snf(smax, Closed_loop_MPC_xnrm2(yk - 1, A_data, i_i
                + 2));
              if (smax >= 0.0) {
                s = -s;
              }

              tau_data[b_n] = (s - smax) / s;
              smax = 1.0 / (smax - s);
              b_ix = i_i + yk;
              for (iy = i_i + 1; iy < b_ix; iy++) {
                A_data[iy] *= smax;
              }

              for (b_i = 0; b_i <= ix; b_i++) {
                s *= 1.0020841800044864E-292;
              }

              smax = s;
            } else {
              tau_data[b_n] = (s - A_data[i_i]) / s;
              smax = 1.0 / (A_data[i_i] - s);
              ix = i_i + yk;
              for (b_ix = i_i + 1; b_ix < ix; b_ix++) {
                A_data[b_ix] *= smax;
              }

              smax = s;
            }
          }
        }

        A_data[i_i] = smax;
      } else {
        tau_data[b_n] = 0.0;
      }

      if (b_n + 1 < n) {
        smax = A_data[i_i];
        A_data[i_i] = 1.0;
        b_ix = ((b_n + 1) * m + b_n) + 1;
        if (tau_data[b_n] != 0.0) {
          ix = yk;
          b_i = (i_i + yk) - 1;
          while ((ix > 0) && (A_data[b_i] == 0.0)) {
            ix--;
            b_i--;
          }

          b_i = nmi - 2;
          exitg2 = false;
          while ((!exitg2) && (b_i + 1 > 0)) {
            nmi = b_i * m + b_ix;
            iy = nmi;
            do {
              exitg1 = 0;
              if (iy <= (nmi + ix) - 1) {
                if (A_data[iy - 1] != 0.0) {
                  exitg1 = 1;
                } else {
                  iy++;
                }
              } else {
                b_i--;
                exitg1 = 2;
              }
            } while (exitg1 == 0);

            if (exitg1 == 1) {
              exitg2 = true;
            }
          }

          nmi = b_i;
        } else {
          ix = 0;
          nmi = -1;
        }

        if (ix > 0) {
          if (nmi + 1 != 0) {
            for (b_i = 0; b_i <= nmi; b_i++) {
              work_data[b_i] = 0.0;
            }

            b_i = 0;
            iy = m * nmi + b_ix;
            d_ix = b_ix;
            while ((m > 0) && (d_ix <= iy)) {
              c_ix = i_i;
              s = 0.0;
              h = (d_ix + ix) - 1;
              for (b_ia = d_ix; b_ia <= h; b_ia++) {
                s += A_data[b_ia - 1] * A_data[c_ix];
                c_ix++;
              }

              work_data[b_i] += s;
              b_i++;
              d_ix += m;
            }
          }

          if (!(-tau_data[b_n] == 0.0)) {
            b_ix--;
            b_i = 0;
            for (iy = 0; iy <= nmi; iy++) {
              if (work_data[b_i] != 0.0) {
                s = work_data[b_i] * -tau_data[b_n];
                d_ix = i_i;
                c_ix = ix + b_ix;
                for (h = b_ix; h < c_ix; h++) {
                  A_data[h] += A_data[d_ix] * s;
                  d_ix++;
                }
              }

              b_i++;
              b_ix += m;
            }
          }
        }

        A_data[i_i] = smax;
      }

      for (i_i = b_n + 1; i_i < n; i_i++) {
        if (vn1_data[i_i] != 0.0) {
          nmi = A_size[0] * i_i + b_n;
          smax = fabs(A_data[nmi]) / vn1_data[i_i];
          smax = 1.0 - smax * smax;
          if (smax < 0.0) {
            smax = 0.0;
          }

          s = vn1_data[i_i] / vn2_data[i_i];
          s = s * s * smax;
          if (s <= 1.4901161193847656E-8) {
            if (b_n + 1 < m) {
              vn1_data[i_i] = Closed_loop_MPC_xnrm2(yk - 1, A_data, nmi + 2);
              vn2_data[i_i] = vn1_data[i_i];
            } else {
              vn1_data[i_i] = 0.0;
              vn2_data[i_i] = 0.0;
            }
          } else {
            vn1_data[i_i] *= sqrt(smax);
          }
        }
      }
    }
  }
}

/* Function for MATLAB Function: '<S2>/MATLAB Function' */
static void Closed_loop_MPC_lusolve(const real_T A_data[], const int32_T A_size
  [2], const real_T B_data[], const int32_T B_size[2], real_T X_data[], int32_T
  X_size[2])
{
  int32_T n;
  int32_T nb;
  real_T b_A_data[25];
  int32_T ipiv_data[5];
  int32_T mmj;
  int32_T b_n;
  int32_T yk;
  real_T smax;
  real_T s;
  int32_T iy;
  int32_T c_ix;
  int32_T e;
  int32_T ijA;
  int32_T jBcol;
  int32_T mmj_tmp;
  n = A_size[1];
  jBcol = A_size[0] * A_size[1] - 1;
  if (0 <= jBcol) {
    memcpy(&b_A_data[0], &A_data[0], (jBcol + 1) * sizeof(real_T));
  }

  b_n = A_size[1];
  if (b_n < 1) {
    b_n = 0;
  }

  if (b_n > 0) {
    ipiv_data[0] = 1;
    yk = 1;
    for (nb = 2; nb <= b_n; nb++) {
      yk++;
      ipiv_data[nb - 1] = yk;
    }
  }

  if (A_size[1] >= 1) {
    nb = A_size[1] - 1;
    if (nb >= A_size[1]) {
      nb = A_size[1];
    }

    for (mmj = 0; mmj < nb; mmj++) {
      mmj_tmp = n - mmj;
      jBcol = (n + 1) * mmj;
      if (mmj_tmp < 1) {
        b_n = -1;
      } else {
        b_n = 0;
        if (mmj_tmp > 1) {
          yk = jBcol;
          smax = fabs(b_A_data[jBcol]);
          for (iy = 2; iy <= mmj_tmp; iy++) {
            yk++;
            s = fabs(b_A_data[yk]);
            if (s > smax) {
              b_n = iy - 1;
              smax = s;
            }
          }
        }
      }

      if (b_A_data[jBcol + b_n] != 0.0) {
        if (b_n != 0) {
          iy = mmj + b_n;
          ipiv_data[mmj] = iy + 1;
          yk = mmj;
          for (b_n = 0; b_n < n; b_n++) {
            smax = b_A_data[yk];
            b_A_data[yk] = b_A_data[iy];
            b_A_data[iy] = smax;
            yk += n;
            iy += n;
          }
        }

        iy = jBcol + mmj_tmp;
        for (b_n = jBcol + 1; b_n < iy; b_n++) {
          b_A_data[b_n] /= b_A_data[jBcol];
        }
      }

      yk = jBcol + n;
      b_n = yk + 1;
      for (iy = 0; iy <= mmj_tmp - 2; iy++) {
        smax = b_A_data[yk];
        if (b_A_data[yk] != 0.0) {
          c_ix = jBcol + 1;
          e = mmj_tmp + b_n;
          for (ijA = b_n; ijA < e - 1; ijA++) {
            b_A_data[ijA] += b_A_data[c_ix] * -smax;
            c_ix++;
          }
        }

        yk += n;
        b_n += n;
      }
    }
  }

  nb = B_size[1] - 1;
  X_size[0] = B_size[0];
  X_size[1] = B_size[1];
  jBcol = B_size[0] * B_size[1] - 1;
  if (0 <= jBcol) {
    memcpy(&X_data[0], &B_data[0], (jBcol + 1) * sizeof(real_T));
  }

  for (b_n = 0; b_n <= n - 2; b_n++) {
    if (b_n + 1 != ipiv_data[b_n]) {
      yk = ipiv_data[b_n] - 1;
      for (mmj = 0; mmj <= nb; mmj++) {
        jBcol = X_size[0] * mmj;
        smax = X_data[jBcol + b_n];
        X_data[b_n + jBcol] = X_data[jBcol + yk];
        X_data[yk + jBcol] = smax;
      }
    }
  }

  if ((B_size[1] != 0) && ((B_size[0] != 0) && (B_size[1] != 0))) {
    for (mmj = 0; mmj <= nb; mmj++) {
      jBcol = n * mmj;
      for (iy = 0; iy < n; iy++) {
        b_n = n * iy;
        if (X_data[iy + jBcol] != 0.0) {
          for (yk = iy + 1; yk < n; yk++) {
            c_ix = yk + jBcol;
            X_data[c_ix] -= X_data[iy + jBcol] * b_A_data[yk + b_n];
          }
        }
      }
    }

    for (mmj = 0; mmj <= nb; mmj++) {
      jBcol = n * mmj;
      for (iy = n - 1; iy + 1 > 0; iy--) {
        b_n = n * iy;
        mmj_tmp = iy + jBcol;
        if (X_data[mmj_tmp] != 0.0) {
          X_data[mmj_tmp] /= b_A_data[iy + b_n];
          for (yk = 0; yk < iy; yk++) {
            c_ix = yk + jBcol;
            X_data[c_ix] -= X_data[mmj_tmp] * b_A_data[yk + b_n];
          }
        }
      }
    }
  }
}

/* Function for MATLAB Function: '<S2>/MATLAB Function' */
static void Closed_loop_MPC_mldivide(const real_T A_data[], const int32_T
  A_size[2], const real_T B_data[], const int32_T B_size[2], real_T Y_data[],
  int32_T Y_size[2])
{
  real_T b_A_data[25];
  real_T tau_data[5];
  int32_T jpvt_data[5];
  int32_T rankR;
  int32_T minmn;
  int32_T maxmn;
  real_T b_B_data[25];
  int32_T b_i;
  real_T wj;
  int32_T b_j;
  int32_T b_A_size[2];
  int32_T jpvt_size[2];
  int32_T b_B_size_idx_0;
  int8_T c_idx_0;
  int8_T c_idx_1;
  int32_T Y_data_tmp;
  int32_T Y_data_tmp_0;
  real_T wj_tmp;
  if ((A_size[0] == 0) || (A_size[1] == 0) || ((B_size[0] == 0) || (B_size[1] ==
        0))) {
    c_idx_0 = (int8_T)A_size[1];
    c_idx_1 = (int8_T)B_size[1];
    Y_size[0] = c_idx_0;
    Y_size[1] = c_idx_1;
    minmn = c_idx_0 * c_idx_1 - 1;
    for (b_B_size_idx_0 = 0; b_B_size_idx_0 <= minmn; b_B_size_idx_0++) {
      Y_data[b_B_size_idx_0] = 0.0;
    }
  } else if (A_size[0] == A_size[1]) {
    Closed_loop_MPC_lusolve(A_data, A_size, B_data, B_size, Y_data, Y_size);
  } else {
    b_A_size[0] = A_size[0];
    b_A_size[1] = A_size[1];
    minmn = A_size[0] * A_size[1] - 1;
    if (0 <= minmn) {
      memcpy(&b_A_data[0], &A_data[0], (minmn + 1) * sizeof(real_T));
    }

    Closed_loop_MPC_xgeqp3(b_A_data, b_A_size, tau_data, &minmn, jpvt_data,
      jpvt_size);
    rankR = 0;
    if (b_A_size[0] < b_A_size[1]) {
      minmn = b_A_size[0];
      maxmn = b_A_size[1];
    } else {
      minmn = b_A_size[1];
      maxmn = b_A_size[0];
    }

    if (minmn > 0) {
      while ((rankR < minmn) && (!(fabs(b_A_data[b_A_size[0] * rankR + rankR]) <=
               2.2204460492503131E-15 * (real_T)maxmn * fabs(b_A_data[0])))) {
        rankR++;
      }
    }

    c_idx_0 = (int8_T)b_A_size[1];
    c_idx_1 = (int8_T)B_size[1];
    Y_size[0] = c_idx_0;
    Y_size[1] = c_idx_1;
    minmn = c_idx_0 * c_idx_1 - 1;
    for (b_B_size_idx_0 = 0; b_B_size_idx_0 <= minmn; b_B_size_idx_0++) {
      Y_data[b_B_size_idx_0] = 0.0;
    }

    b_B_size_idx_0 = B_size[0];
    minmn = B_size[0] * B_size[1] - 1;
    if (0 <= minmn) {
      memcpy(&b_B_data[0], &B_data[0], (minmn + 1) * sizeof(real_T));
    }

    minmn = b_A_size[0];
    if (b_A_size[0] < b_A_size[1]) {
      maxmn = b_A_size[0];
    } else {
      maxmn = b_A_size[1];
    }

    maxmn--;
    for (b_j = 0; b_j <= maxmn; b_j++) {
      if (tau_data[b_j] != 0.0) {
        for (Y_data_tmp = 0; Y_data_tmp < B_size[1]; Y_data_tmp++) {
          Y_data_tmp_0 = b_B_size_idx_0 * Y_data_tmp;
          wj_tmp = b_B_data[Y_data_tmp_0 + b_j];
          wj = wj_tmp;
          for (b_i = b_j + 1; b_i < minmn; b_i++) {
            wj += b_A_data[b_A_size[0] * b_j + b_i] * b_B_data[Y_data_tmp_0 +
              b_i];
          }

          wj *= tau_data[b_j];
          if (wj != 0.0) {
            b_B_data[b_j + Y_data_tmp_0] = wj_tmp - wj;
            for (b_i = b_j + 1; b_i < minmn; b_i++) {
              b_B_data[b_i + Y_data_tmp_0] -= b_A_data[b_A_size[0] * b_j + b_i] *
                wj;
            }
          }
        }
      }
    }

    for (minmn = 0; minmn < B_size[1]; minmn++) {
      for (maxmn = 0; maxmn < rankR; maxmn++) {
        Y_data[(jpvt_data[maxmn] + c_idx_0 * minmn) - 1] =
          b_B_data[b_B_size_idx_0 * minmn + maxmn];
      }

      for (maxmn = rankR - 1; maxmn + 1 > 0; maxmn--) {
        b_j = c_idx_0 * minmn;
        Y_data_tmp = (b_j + jpvt_data[maxmn]) - 1;
        Y_data_tmp_0 = b_A_size[0] * maxmn;
        Y_data[(jpvt_data[maxmn] + b_j) - 1] = Y_data[Y_data_tmp] /
          b_A_data[Y_data_tmp_0 + maxmn];
        for (b_i = 0; b_i < maxmn; b_i++) {
          Y_data[(jpvt_data[b_i] + b_j) - 1] -= Y_data[Y_data_tmp] *
            b_A_data[Y_data_tmp_0 + b_i];
        }
      }
    }
  }
}

static void Closed_loop_MPC_emxFree_real_T(emxArray_real_T_Closed_loop_M_T
  **pEmxArray)
{
  if (*pEmxArray != (emxArray_real_T_Closed_loop_M_T *)NULL) {
    if (((*pEmxArray)->data != (real_T *)NULL) && (*pEmxArray)->canFreeData) {
      free((*pEmxArray)->data);
    }

    free((*pEmxArray)->size);
    free(*pEmxArray);
    *pEmxArray = (emxArray_real_T_Closed_loop_M_T *)NULL;
  }
}

/* Model output function for TID0 */
void Closed_loop_MPC_output0(void)     /* Sample time: [0.0s, 0.0s] */
{
  int_T idx;
  real_T rtb_Gain;
  real_T rtb_Abs;

  {                                    /* Sample time: [0.0s, 0.0s] */
    rate_monotonic_scheduler();
  }

  /* S-Function (ec_EL3102_adc): '<S10>/ec_EL3102_adc' */

  /* Level2 S-Function Block: '<S10>/ec_EL3102_adc' (ec_EL3102_adc) */
  {
    SimStruct *rts = Closed_loop_MPC_M->childSfunctions[0];
    sfcnOutputs(rts,0);
  }

  /* Gain: '<S9>/Gain' */
  rtb_Gain = Closed_loop_MPC_P.ku1 * Closed_loop_MPC_B.ec_EL3102_adc_a[0];

  /* Polyval: '<S9>/Polynomial' */
  rtb_Abs = Closed_loop_MPC_P.p1[0];
  for (idx = 0; idx < 8; idx++) {
    rtb_Abs = rtb_Abs * rtb_Gain + Closed_loop_MPC_P.p1[idx + 1];
  }

  /* End of Polyval: '<S9>/Polynomial' */

  /* Gain: '<S9>/Gain9' incorporates:
   *  Constant: '<S9>/Constant'
   *  Sum: '<S9>/Add'
   */
  Closed_loop_MPC_B.Gain9 = (rtb_Abs - Closed_loop_MPC_P.o1) *
    Closed_loop_MPC_P.ky1;

  /* Gain: '<S9>/Gain1' */
  rtb_Gain = Closed_loop_MPC_P.ku2 * Closed_loop_MPC_B.ec_EL3102_adc_a[1];

  /* Polyval: '<S9>/Polynomial1' */
  rtb_Abs = Closed_loop_MPC_P.p2[0];
  for (idx = 0; idx < 8; idx++) {
    rtb_Abs = rtb_Abs * rtb_Gain + Closed_loop_MPC_P.p2[idx + 1];
  }

  /* End of Polyval: '<S9>/Polynomial1' */

  /* Gain: '<S9>/Gain8' incorporates:
   *  Constant: '<S9>/Constant1'
   *  Sum: '<S9>/Add1'
   */
  Closed_loop_MPC_B.Gain8 = (rtb_Abs - Closed_loop_MPC_P.o2) *
    Closed_loop_MPC_P.ky2;

  /* S-Function (ec_EL3102_adc): '<S12>/ec_EL3102_adc' */

  /* Level2 S-Function Block: '<S12>/ec_EL3102_adc' (ec_EL3102_adc) */
  {
    SimStruct *rts = Closed_loop_MPC_M->childSfunctions[1];
    sfcnOutputs(rts,0);
  }

  /* Gain: '<S9>/Gain2' */
  rtb_Gain = Closed_loop_MPC_P.ku3 * Closed_loop_MPC_B.ec_EL3102_adc_f[0];

  /* Polyval: '<S9>/Polynomial2' */
  rtb_Abs = Closed_loop_MPC_P.p3[0];
  for (idx = 0; idx < 8; idx++) {
    rtb_Abs = rtb_Abs * rtb_Gain + Closed_loop_MPC_P.p3[idx + 1];
  }

  /* End of Polyval: '<S9>/Polynomial2' */

  /* Gain: '<S9>/Gain7' incorporates:
   *  Constant: '<S9>/Constant2'
   *  Sum: '<S9>/Add2'
   */
  Closed_loop_MPC_B.Gain7 = (rtb_Abs - Closed_loop_MPC_P.o3) *
    Closed_loop_MPC_P.ky3;

  /* Gain: '<S9>/Gain3' */
  rtb_Gain = Closed_loop_MPC_P.ku4 * Closed_loop_MPC_B.ec_EL3102_adc_f[1];

  /* Polyval: '<S9>/Polynomial3' */
  rtb_Abs = Closed_loop_MPC_P.p4[0];
  for (idx = 0; idx < 8; idx++) {
    rtb_Abs = rtb_Abs * rtb_Gain + Closed_loop_MPC_P.p4[idx + 1];
  }

  /* End of Polyval: '<S9>/Polynomial3' */

  /* Gain: '<S9>/Gain6' incorporates:
   *  Constant: '<S9>/Constant3'
   *  Sum: '<S9>/Add3'
   */
  Closed_loop_MPC_B.Gain6 = (rtb_Abs - Closed_loop_MPC_P.o4) *
    Closed_loop_MPC_P.ky4;

  /* S-Function (ec_EL3102_adc): '<S11>/ec_EL3102_adc' */

  /* Level2 S-Function Block: '<S11>/ec_EL3102_adc' (ec_EL3102_adc) */
  {
    SimStruct *rts = Closed_loop_MPC_M->childSfunctions[2];
    sfcnOutputs(rts,0);
  }

  /* Gain: '<S9>/Gain4' */
  rtb_Gain = Closed_loop_MPC_P.ku5 * Closed_loop_MPC_B.ec_EL3102_adc_m[1];

  /* Polyval: '<S9>/Polynomial5' */
  rtb_Abs = Closed_loop_MPC_P.p5[0];
  for (idx = 0; idx < 8; idx++) {
    rtb_Abs = rtb_Abs * rtb_Gain + Closed_loop_MPC_P.p5[idx + 1];
  }

  /* End of Polyval: '<S9>/Polynomial5' */

  /* Gain: '<S9>/Gain5' incorporates:
   *  Constant: '<S9>/Constant5'
   *  Sum: '<S9>/Add5'
   */
  Closed_loop_MPC_B.Gain5 = (rtb_Abs - Closed_loop_MPC_P.o5) *
    Closed_loop_MPC_P.ky5;

  /* MultiPortSwitch: '<Root>/Index Vector' incorporates:
   *  Constant: '<Root>/nsensor'
   */
  switch ((int32_T)Closed_loop_MPC_P.nsensor_Value) {
   case 1:
    Closed_loop_MPC_B.y = Closed_loop_MPC_B.Gain9;
    break;

   case 2:
    Closed_loop_MPC_B.y = Closed_loop_MPC_B.Gain8;
    break;

   case 3:
    Closed_loop_MPC_B.y = Closed_loop_MPC_B.Gain7;
    break;

   case 4:
    Closed_loop_MPC_B.y = Closed_loop_MPC_B.Gain6;
    break;

   default:
    Closed_loop_MPC_B.y = Closed_loop_MPC_B.Gain5;
    break;
  }

  /* End of MultiPortSwitch: '<Root>/Index Vector' */

  /* Sum: '<Root>/Sum' incorporates:
   *  Constant: '<Root>/Constant1'
   */
  Closed_loop_MPC_B.Sum = Closed_loop_MPC_B.y - Closed_loop_MPC_P.y_offset;

  /* RelationalOperator: '<S1>/Compare' incorporates:
   *  Abs: '<Root>/Abs'
   *  Constant: '<S1>/Constant'
   */
  Closed_loop_MPC_B.Compare = (fabs(Closed_loop_MPC_B.Sum) >
    Closed_loop_MPC_P.CompareToConstant_const);

  /* Stop: '<Root>/Stop Simulation' */
  if (Closed_loop_MPC_B.Compare) {
    rtmSetStopRequested(Closed_loop_MPC_M, 1);
  }

  /* End of Stop: '<Root>/Stop Simulation' */

  /* ToWorkspace: '<Root>/To Workspace' */
  rt_UpdateLogVar((LogVar *)(LogVar*)
                  (Closed_loop_MPC_DW.ToWorkspace_PWORK.LoggedData),
                  &Closed_loop_MPC_B.Sum, 0);

  /* ZeroOrderHold: '<Root>/Zero-Order Hold' */
  if (Closed_loop_MPC_M->Timing.RateInteraction.TID0_2) {
    Closed_loop_MPC_B.ZeroOrderHold = Closed_loop_MPC_B.Sum;
  }

  /* End of ZeroOrderHold: '<Root>/Zero-Order Hold' */

  /* RateTransition: '<Root>/u' */
  if (Closed_loop_MPC_M->Timing.RateInteraction.TID1_2) {
    Closed_loop_MPC_B.u_l = Closed_loop_MPC_DW.u_Buffer0;
  }

  /* End of RateTransition: '<Root>/u' */

  /* Sum: '<Root>/Sum1' incorporates:
   *  Fcn: '<Root>/Fcn'
   *  Gain: '<Root>/Gain'
   */
  Closed_loop_MPC_B.utot = Closed_loop_MPC_B.u_l - (0.0 * rt_powd_snf
    (Closed_loop_MPC_B.Sum, 5.0) + rt_powd_snf(Closed_loop_MPC_B.Sum, 3.0)) *
    Closed_loop_MPC_P.kc;

  /* ZeroOrderHold: '<Root>/Zero-Order Hold1' */
  Closed_loop_MPC_B.ZeroOrderHold1 = Closed_loop_MPC_B.utot;

  /* ToWorkspace: '<Root>/To Workspace4' */
  rt_UpdateLogVar((LogVar *)(LogVar*)
                  (Closed_loop_MPC_DW.ToWorkspace4_PWORK.LoggedData),
                  &Closed_loop_MPC_B.ZeroOrderHold1, 0);

  /* RateTransition: '<Root>/TmpRTBAtTo Workspace5Inport1' */
  if (Closed_loop_MPC_M->Timing.RateInteraction.TID1_2) {
    Closed_loop_MPC_B.TmpRTBAtToWorkspace5Inport1 = Closed_loop_MPC_B.Sum;
  }

  /* End of RateTransition: '<Root>/TmpRTBAtTo Workspace5Inport1' */

  /* Scope: '<Root>/input_sensor' */
  {
    real_T u[6];
    u[0] = Closed_loop_MPC_M->Timing.t[1];
    ;
    u[1] = Closed_loop_MPC_B.ec_EL3102_adc_a[0];
    u[2] = Closed_loop_MPC_B.ec_EL3102_adc_a[1];
    u[3] = Closed_loop_MPC_B.ec_EL3102_adc_f[0];
    u[4] = Closed_loop_MPC_B.ec_EL3102_adc_f[1];
    u[5] = Closed_loop_MPC_B.ec_EL3102_adc_m[1];
    rt_UpdateLogVar((LogVar *)Closed_loop_MPC_DW.input_sensor_PWORK.LoggedData,
                    u, 0);
  }

  /* Scope: '<Root>/output_sensor' */
  {
    real_T u[6];
    u[0] = Closed_loop_MPC_M->Timing.t[1];
    ;
    u[1] = Closed_loop_MPC_B.Gain9;
    u[2] = Closed_loop_MPC_B.Gain8;
    u[3] = Closed_loop_MPC_B.Gain7;
    u[4] = Closed_loop_MPC_B.Gain6;
    u[5] = Closed_loop_MPC_B.Gain5;
    rt_UpdateLogVar((LogVar *)Closed_loop_MPC_DW.output_sensor_PWORK.LoggedData,
                    u, 0);
  }

  /* Scope: '<Root>/y' */
  {
    real_T u[2];
    u[0] = Closed_loop_MPC_M->Timing.t[1];
    ;
    u[1] = Closed_loop_MPC_B.y;
    rt_UpdateLogVar((LogVar *)Closed_loop_MPC_DW.y_PWORK.LoggedData, u, 0);
  }

  /* S-Function (ec_EL4132_dac): '<S13>/ec_EL4132_dac' */

  /* Level2 S-Function Block: '<S13>/ec_EL4132_dac' (ec_EL4132_dac) */
  {
    SimStruct *rts = Closed_loop_MPC_M->childSfunctions[3];
    sfcnOutputs(rts,0);
  }

  /* Saturate: '<S8>/Saturation' */
  if (Closed_loop_MPC_B.ZeroOrderHold1 > Closed_loop_MPC_P.Saturation_UpperSat)
  {
    Closed_loop_MPC_B.Saturation = Closed_loop_MPC_P.Saturation_UpperSat;
  } else if (Closed_loop_MPC_B.ZeroOrderHold1 <
             Closed_loop_MPC_P.Saturation_LowerSat) {
    Closed_loop_MPC_B.Saturation = Closed_loop_MPC_P.Saturation_LowerSat;
  } else {
    Closed_loop_MPC_B.Saturation = Closed_loop_MPC_B.ZeroOrderHold1;
  }

  /* End of Saturate: '<S8>/Saturation' */

  /* Scope: '<S7>/Scope' */
  {
    real_T u[2];
    u[0] = Closed_loop_MPC_M->Timing.t[1];
    ;
    u[1] = Closed_loop_MPC_B.Saturation;
    rt_UpdateLogVar((LogVar *)Closed_loop_MPC_DW.Scope_PWORK.LoggedData, u, 0);
  }

  /* S-Function (ec_EL4132_dac): '<S14>/ec_EL4132_dac' */

  /* Level2 S-Function Block: '<S14>/ec_EL4132_dac' (ec_EL4132_dac) */
  {
    SimStruct *rts = Closed_loop_MPC_M->childSfunctions[4];
    sfcnOutputs(rts,0);
  }

  /* Saturate: '<S8>/Saturation1' incorporates:
   *  Constant: '<Root>/Constant'
   */
  if (Closed_loop_MPC_P.Constant_Value_g >
      Closed_loop_MPC_P.Saturation1_UpperSat) {
    Closed_loop_MPC_B.Saturation1 = Closed_loop_MPC_P.Saturation1_UpperSat;
  } else if (Closed_loop_MPC_P.Constant_Value_g <
             Closed_loop_MPC_P.Saturation1_LowerSat) {
    Closed_loop_MPC_B.Saturation1 = Closed_loop_MPC_P.Saturation1_LowerSat;
  } else {
    Closed_loop_MPC_B.Saturation1 = Closed_loop_MPC_P.Constant_Value_g;
  }

  /* End of Saturate: '<S8>/Saturation1' */

  /* Saturate: '<S8>/Saturation2' incorporates:
   *  Constant: '<Root>/Constant'
   */
  if (Closed_loop_MPC_P.Constant_Value_g >
      Closed_loop_MPC_P.Saturation2_UpperSat) {
    Closed_loop_MPC_B.Saturation2 = Closed_loop_MPC_P.Saturation2_UpperSat;
  } else if (Closed_loop_MPC_P.Constant_Value_g <
             Closed_loop_MPC_P.Saturation2_LowerSat) {
    Closed_loop_MPC_B.Saturation2 = Closed_loop_MPC_P.Saturation2_LowerSat;
  } else {
    Closed_loop_MPC_B.Saturation2 = Closed_loop_MPC_P.Constant_Value_g;
  }

  /* End of Saturate: '<S8>/Saturation2' */

  /* Saturate: '<S3>/Saturation2' incorporates:
   *  Constant: '<Root>/Constant'
   */
  if (Closed_loop_MPC_P.Constant_Value_g >
      Closed_loop_MPC_P.Saturation2_UpperSat_a) {
    Closed_loop_MPC_B.Saturation2_e = Closed_loop_MPC_P.Saturation2_UpperSat_a;
  } else if (Closed_loop_MPC_P.Constant_Value_g <
             Closed_loop_MPC_P.Saturation2_LowerSat_b) {
    Closed_loop_MPC_B.Saturation2_e = Closed_loop_MPC_P.Saturation2_LowerSat_b;
  } else {
    Closed_loop_MPC_B.Saturation2_e = Closed_loop_MPC_P.Constant_Value_g;
  }

  /* End of Saturate: '<S3>/Saturation2' */
}

/* Model update function for TID0 */
void Closed_loop_MPC_update0(void)     /* Sample time: [0.0s, 0.0s] */
{
  /* Update absolute time */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++Closed_loop_MPC_M->Timing.clockTick0)) {
    ++Closed_loop_MPC_M->Timing.clockTickH0;
  }

  Closed_loop_MPC_M->Timing.t[0] = Closed_loop_MPC_M->Timing.clockTick0 *
    Closed_loop_MPC_M->Timing.stepSize0 + Closed_loop_MPC_M->Timing.clockTickH0 *
    Closed_loop_MPC_M->Timing.stepSize0 * 4294967296.0;

  /* Update absolute time */
  /* The "clockTick1" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick1"
   * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick1 and the high bits
   * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++Closed_loop_MPC_M->Timing.clockTick1)) {
    ++Closed_loop_MPC_M->Timing.clockTickH1;
  }

  Closed_loop_MPC_M->Timing.t[1] = Closed_loop_MPC_M->Timing.clockTick1 *
    Closed_loop_MPC_M->Timing.stepSize1 + Closed_loop_MPC_M->Timing.clockTickH1 *
    Closed_loop_MPC_M->Timing.stepSize1 * 4294967296.0;
}

/* Model output function for TID2 */
void Closed_loop_MPC_output2(void)     /* Sample time: [0.001953125s, 0.0s] */
{
  emxArray_real_T_Closed_loop_M_T *xref;
  real_T xaug[5];
  real_T yrefnow_data[11];
  real_T g_data[11];
  real_T gprev_data[11];
  real_T Su_data[25];
  real_T Omega_data[25];
  real_T GinvF_data[25];
  real_T uN_data[5];
  emxArray_real_T_Closed_loop_M_T *v;
  real_T u_data[5];
  boolean_T rEQ0;
  real_T b_q;
  real_T c_y_data[25];
  int32_T b_n;
  int32_T coffset;
  int32_T boffset;
  int32_T aoffset;
  int32_T e_k;
  int32_T d_m;
  int32_T c_inner;
  int32_T c_boffset;
  int32_T e_aoffset;
  real_T Y2[8];
  real_T tempY;
  real_T X2[32];
  real_T sqrtP[16];
  int32_T jmax;
  int32_T jj;
  real_T ajj;
  int32_T j;
  int32_T ix;
  int32_T iy;
  real_T gain[4];
  real_T Y2_0[32];
  real_T rtb_yref_[6];
  real_T rtb_xNew[4];
  real_T rtb_TmpSignalConversionAtSFunct[26];
  real_T b_q_data[6];
  real_T tempY_data[11];
  real_T Y2_1[16];
  int32_T g_size;
  int32_T Su_size[2];
  int32_T GinvF_size[2];
  int32_T tmp_size[2];
  real_T Y2_2;
  boolean_T exitg1;

  /* Reset subsysRan breadcrumbs */
  srClearBC(Closed_loop_MPC_DW.Correct1_SubsysRanBC);

  /* Outputs for Enabled SubSystem: '<S5>/Correct1' incorporates:
   *  EnablePort: '<S15>/Enable'
   */
  /* Constant: '<S5>/Enable1' */
  if (Closed_loop_MPC_P.Enable1_Value) {
    /* MATLAB Function: '<S15>/Correct' incorporates:
     *  Constant: '<Root>/Constant2'
     *  Constant: '<S5>/R1'
     *  DataStoreRead: '<S15>/Data Store ReadP'
     *  DataStoreRead: '<S15>/Data Store ReadX'
     */
    /* MATLAB Function 'Extras/UKFCorrect/Correct': '<S18>:1' */
    memcpy(&sqrtP[0], &Closed_loop_MPC_DW.P[0], sizeof(real_T) << 4U);
    jmax = 0;
    j = 1;
    exitg1 = false;
    while ((!exitg1) && (j - 1 < 4)) {
      jj = (((j - 1) << 2) + j) - 1;
      ajj = 0.0;
      if (j - 1 >= 1) {
        ix = j;
        iy = j;
        for (e_aoffset = 0; e_aoffset <= j - 2; e_aoffset++) {
          ajj += sqrtP[ix - 1] * sqrtP[iy - 1];
          ix += 4;
          iy += 4;
        }
      }

      ajj = sqrtP[jj] - ajj;
      if (ajj > 0.0) {
        ajj = sqrt(ajj);
        sqrtP[jj] = ajj;
        if (j < 4) {
          if (j - 1 != 0) {
            e_aoffset = j;
            ix = (((j - 2) << 2) + j) + 1;
            for (c_boffset = j + 1; c_boffset <= ix; c_boffset += 4) {
              tempY = -sqrtP[e_aoffset - 1];
              d_m = jj + 1;
              iy = (c_boffset - j) + 3;
              for (c_inner = c_boffset; c_inner <= iy; c_inner++) {
                sqrtP[d_m] += sqrtP[c_inner - 1] * tempY;
                d_m++;
              }

              e_aoffset += 4;
            }
          }

          ajj = 1.0 / ajj;
          ix = (jj - j) + 5;
          for (jj++; jj < ix; jj++) {
            sqrtP[jj] *= ajj;
          }
        }

        j++;
      } else {
        sqrtP[jj] = ajj;
        jmax = j;
        exitg1 = true;
      }
    }

    if (jmax == 0) {
      jmax = 5;
    }

    jmax--;
    for (j = 1; j < jmax; j++) {
      for (jj = 0; jj < j; jj++) {
        sqrtP[jj + (j << 2)] = 0.0;
      }
    }

    for (c_boffset = 0; c_boffset < 16; c_boffset++) {
      ajj = 0.002 * sqrtP[c_boffset];
      X2[c_boffset] = ajj;
      X2[c_boffset + 16] = -ajj;
      sqrtP[c_boffset] = ajj;
    }

    b_q = ((Closed_loop_MPC_P.Cc[0] * Closed_loop_MPC_DW.x[0] +
            Closed_loop_MPC_P.Cc[1] * Closed_loop_MPC_DW.x[1]) +
           Closed_loop_MPC_P.Cc[2] * Closed_loop_MPC_DW.x[2]) +
      Closed_loop_MPC_P.Cc[3] * Closed_loop_MPC_DW.x[3];
    ajj = b_q;
    for (jmax = 0; jmax < 8; jmax++) {
      ix = jmax << 2;
      tempY = X2[ix] + Closed_loop_MPC_DW.x[0];
      Y2_2 = Closed_loop_MPC_P.Cc[0] * tempY;
      X2[ix] = tempY;
      tempY = X2[ix + 1] + Closed_loop_MPC_DW.x[1];
      Y2_2 += Closed_loop_MPC_P.Cc[1] * tempY;
      X2[1 + ix] = tempY;
      tempY = X2[ix + 2] + Closed_loop_MPC_DW.x[2];
      Y2_2 += Closed_loop_MPC_P.Cc[2] * tempY;
      X2[2 + ix] = tempY;
      tempY = X2[ix + 3] + Closed_loop_MPC_DW.x[3];
      Y2_2 += Closed_loop_MPC_P.Cc[3] * tempY;
      X2[3 + ix] = tempY;
      ajj += Y2_2 * -0.125000125000125;
      Y2[jmax] = Y2_2;
    }

    ajj *= -999999.0;
    tempY = b_q - ajj;
    Y2_2 = 0.0;
    for (jmax = 0; jmax < 8; jmax++) {
      b_q = Y2[jmax] - ajj;
      X2[jmax << 2] -= Closed_loop_MPC_DW.x[0];
      X2[1 + (jmax << 2)] -= Closed_loop_MPC_DW.x[1];
      X2[2 + (jmax << 2)] -= Closed_loop_MPC_DW.x[2];
      X2[3 + (jmax << 2)] -= Closed_loop_MPC_DW.x[3];
      Y2_2 += b_q * b_q;
      Y2[jmax] = b_q;
    }

    tempY = (tempY * tempY * 0.999996999998 + -0.125000125000125 * Y2_2) *
      -999999.0 + Closed_loop_MPC_P.R1_Value;
    for (c_boffset = 0; c_boffset < 4; c_boffset++) {
      rtb_xNew[c_boffset] = 0.0;
      for (coffset = 0; coffset < 8; coffset++) {
        rtb_xNew[c_boffset] += X2[(coffset << 2) + c_boffset] * Y2[coffset];
      }

      gain[c_boffset] = rtb_xNew[c_boffset] * 125000.0 / tempY;
    }

    ajj = Closed_loop_MPC_B.ZeroOrderHold - ajj;

    /* '<S18>:1:29' */
    for (c_boffset = 0; c_boffset < 4; c_boffset++) {
      /* MATLAB Function: '<S15>/Correct' */
      b_q = gain[c_boffset] * tempY;

      /* DataStoreWrite: '<S15>/Data Store WriteP' incorporates:
       *  DataStoreRead: '<S15>/Data Store ReadP'
       *  MATLAB Function: '<S15>/Correct'
       */
      Closed_loop_MPC_DW.P[c_boffset] -= b_q * gain[0];
      Closed_loop_MPC_DW.P[c_boffset + 4] -= b_q * gain[1];
      Closed_loop_MPC_DW.P[c_boffset + 8] -= b_q * gain[2];
      Closed_loop_MPC_DW.P[c_boffset + 12] -= b_q * gain[3];

      /* DataStoreWrite: '<S15>/Data Store WriteX' incorporates:
       *  DataStoreRead: '<S15>/Data Store ReadX'
       *  MATLAB Function: '<S15>/Correct'
       */
      Closed_loop_MPC_DW.x[c_boffset] += gain[c_boffset] * ajj;
    }

    srUpdateBC(Closed_loop_MPC_DW.Correct1_SubsysRanBC);
  }

  /* End of Constant: '<S5>/Enable1' */
  /* End of Outputs for SubSystem: '<S5>/Correct1' */

  /* Outputs for Atomic SubSystem: '<S5>/Output' */
  /* DataStoreRead: '<S16>/Data Store Read' */
  Closed_loop_MPC_B.DataStoreRead[0] = Closed_loop_MPC_DW.x[0];
  Closed_loop_MPC_B.DataStoreRead[1] = Closed_loop_MPC_DW.x[1];
  Closed_loop_MPC_B.DataStoreRead[2] = Closed_loop_MPC_DW.x[2];
  Closed_loop_MPC_B.DataStoreRead[3] = Closed_loop_MPC_DW.x[3];

  /* End of Outputs for SubSystem: '<S5>/Output' */

  /* ToWorkspace: '<Root>/To Workspace1' */
  rt_UpdateLogVar((LogVar *)(LogVar*)
                  (Closed_loop_MPC_DW.ToWorkspace1_PWORK.LoggedData),
                  &Closed_loop_MPC_B.DataStoreRead[0], 0);

  /* Gain: '<Root>/Gain1' */
  Closed_loop_MPC_B.Gain1 = ((Closed_loop_MPC_P.Cc[0] *
    Closed_loop_MPC_B.DataStoreRead[0] + Closed_loop_MPC_P.Cc[1] *
    Closed_loop_MPC_B.DataStoreRead[1]) + Closed_loop_MPC_P.Cc[2] *
    Closed_loop_MPC_B.DataStoreRead[2]) + Closed_loop_MPC_P.Cc[3] *
    Closed_loop_MPC_B.DataStoreRead[3];

  /* ToWorkspace: '<Root>/To Workspace2' */
  {
    double locTime = Closed_loop_MPC_M->Timing.t[2];
    ;
    rt_UpdateStructLogVar((StructLogVar *)
                          Closed_loop_MPC_DW.ToWorkspace2_PWORK.LoggedData,
                          &locTime, &Closed_loop_MPC_B.Gain1);
  }

  /* RateTransition: '<Root>/v' incorporates:
   *  RateTransition: '<S2>/TmpRTBAtMATLAB FunctionInport8'
   */
  if (Closed_loop_MPC_M->Timing.RateInteraction.TID2_3) {
    Closed_loop_MPC_B.v = Closed_loop_MPC_DW.v_Buffer0;
    for (jmax = 0; jmax < 6; jmax++) {
      Closed_loop_MPC_B.TmpRTBAtMATLABFunctionInport8[jmax] =
        Closed_loop_MPC_DW.TmpRTBAtMATLABFunctionInport8_B[jmax];
    }
  }

  /* End of RateTransition: '<Root>/v' */

  /* DigitalClock: '<S2>/Digital Clock' */
  tempY = Closed_loop_MPC_M->Timing.t[2];

  /* MATLAB Function: '<S2>/MATLAB Function' */
  /* MATLAB Function 'MPC/MATLAB Function': '<S6>:1' */
  /* '<S6>:1:24' */
  /* '<S6>:1:72' */
  /* '<S6>:1:3' */
  /* '<S6>:1:4' */
  /* '<S6>:1:5' */
  /* '<S6>:1:6' */
  /* '<S6>:1:7' */
  /* '<S6>:1:8' */
  /* '<S6>:1:9' */
  /* '<S6>:1:15' */
  ajj = tempY;
  if ((!rtIsInf(tempY)) && (!rtIsNaN(tempY)) && ((!rtIsInf
        (Closed_loop_MPC_P.mpc.ts_out)) && (!rtIsNaN
        (Closed_loop_MPC_P.mpc.ts_out)))) {
    if (tempY == 0.0) {
      ajj = Closed_loop_MPC_P.mpc.ts_out * 0.0;
    } else {
      if (Closed_loop_MPC_P.mpc.ts_out != 0.0) {
        ajj = fmod(tempY, Closed_loop_MPC_P.mpc.ts_out);
        rEQ0 = (ajj == 0.0);
        if ((!rEQ0) && (Closed_loop_MPC_P.mpc.ts_out > floor
                        (Closed_loop_MPC_P.mpc.ts_out))) {
          b_q = fabs(tempY / Closed_loop_MPC_P.mpc.ts_out);
          rEQ0 = (fabs(b_q - floor(b_q + 0.5)) <= 2.2204460492503131E-16 * b_q);
        }

        if (rEQ0) {
          ajj = Closed_loop_MPC_P.mpc.ts_out * 0.0;
        } else {
          if ((tempY < 0.0) != (Closed_loop_MPC_P.mpc.ts_out < 0.0)) {
            ajj += Closed_loop_MPC_P.mpc.ts_out;
          }
        }
      }
    }
  } else {
    if (Closed_loop_MPC_P.mpc.ts_out != 0.0) {
      ajj = (rtNaN);
    }
  }

  Closed_loop_MPC_emxInit_real_T(&v, 2);

  /* MATLAB Function: '<S2>/MATLAB Function' */
  /* '<S6>:1:16' */
  ajj = rt_roundd_snf(-1.0 / Closed_loop_MPC_P.mpc.ts_in * ajj +
                      Closed_loop_MPC_P.mpc.N);

  /* '<S6>:1:19' */
  c_boffset = v->size[0] * v->size[1];
  v->size[0] = 1;
  coffset = (int32_T)ajj;
  v->size[1] = coffset;
  Closed_emxEnsureCapacity_real_T(v, c_boffset);
  ix = coffset - 1;
  for (c_boffset = 0; c_boffset <= ix; c_boffset++) {
    v->data[c_boffset] = Closed_loop_MPC_B.v;
  }

  Closed_loop_MPC_emxInit_real_T(&xref, 2);

  /* MATLAB Function: '<S2>/MATLAB Function' incorporates:
   *  Constant: '<S2>/Constant'
   *  UnitDelay: '<S2>/Unit Delay'
   *  UnitDelay: '<S2>/Unit Delay2'
   *  UnitDelay: '<S2>/Unit Delay4'
   */
  /* '<S6>:1:20' */
  c_boffset = xref->size[0] * xref->size[1];
  xref->size[0] = 4;
  coffset = (int32_T)(ajj + 1.0);
  xref->size[1] = coffset;
  Closed_emxEnsureCapacity_real_T(xref, c_boffset);
  iy = (coffset << 2) - 1;
  for (c_boffset = 0; c_boffset <= iy; c_boffset++) {
    xref->data[c_boffset] = 0.0;
  }

  /* '<S6>:1:21' */
  for (jmax = 0; jmax < 6; jmax++) {
    rtb_yref_[jmax] = Closed_loop_MPC_P.Constant_Value[jmax];
  }

  /* '<S6>:1:22' */
  xref->data[0] = Closed_loop_MPC_DW.UnitDelay_DSTATE[0];
  xref->data[1] = Closed_loop_MPC_DW.UnitDelay_DSTATE[1];
  xref->data[2] = Closed_loop_MPC_DW.UnitDelay_DSTATE[2];
  xref->data[3] = Closed_loop_MPC_DW.UnitDelay_DSTATE[3];

  /* '<S6>:1:23' */
  for (e_aoffset = 0; e_aoffset <= ix; e_aoffset++) {
    /* '<S6>:1:23' */
    /* '<S6>:1:24' */
    Y2_2 = v->data[e_aoffset];
    for (c_boffset = 0; c_boffset < 4; c_boffset++) {
      coffset = e_aoffset << 2;
      b_q = xref->data[coffset] * Closed_loop_MPC_P.mpc.Ad[c_boffset];
      b_q += xref->data[coffset + 1] * Closed_loop_MPC_P.mpc.Ad[c_boffset + 4];
      b_q += xref->data[coffset + 2] * Closed_loop_MPC_P.mpc.Ad[c_boffset + 8];
      b_q += xref->data[coffset + 3] * Closed_loop_MPC_P.mpc.Ad[c_boffset + 12];
      gain[c_boffset] = Closed_loop_MPC_P.mpc.Bd[c_boffset] * Y2_2 + b_q;
    }

    c_boffset = (e_aoffset + 1) << 2;
    xref->data[c_boffset] = gain[0];
    xref->data[1 + c_boffset] = gain[1];
    xref->data[2 + c_boffset] = gain[2];
    xref->data[3 + c_boffset] = gain[3];

    /* '<S6>:1:25' */
    b_q = xref->data[c_boffset] * Closed_loop_MPC_P.mpc.C[0];
    b_q += xref->data[c_boffset + 1] * Closed_loop_MPC_P.mpc.C[1];
    b_q += xref->data[c_boffset + 2] * Closed_loop_MPC_P.mpc.C[2];
    rtb_yref_[e_aoffset + 1] = xref->data[c_boffset + 3] *
      Closed_loop_MPC_P.mpc.C[3] + b_q;
  }

  /* '<S6>:1:27' */
  if ((tempY < Closed_loop_MPC_P.mpc.ts_out) && (Closed_loop_MPC_P.mpc.osd ==
       1.0)) {
    /* '<S6>:1:31' */
    /* '<S6>:1:32' */
    ajj = 0.0;

    /* '<S6>:1:33' */
  } else {
    /* '<S6>:1:38' */
    xaug[0] = Closed_loop_MPC_B.DataStoreRead[0] -
      Closed_loop_MPC_DW.UnitDelay2_DSTATE[0];
    xaug[1] = Closed_loop_MPC_B.DataStoreRead[1] -
      Closed_loop_MPC_DW.UnitDelay2_DSTATE[1];
    xaug[2] = Closed_loop_MPC_B.DataStoreRead[2] -
      Closed_loop_MPC_DW.UnitDelay2_DSTATE[2];
    b_q = ((Closed_loop_MPC_P.mpc.C[0] * Closed_loop_MPC_B.DataStoreRead[0] +
            Closed_loop_MPC_P.mpc.C[1] * Closed_loop_MPC_B.DataStoreRead[1]) +
           Closed_loop_MPC_P.mpc.C[2] * Closed_loop_MPC_B.DataStoreRead[2]) +
      Closed_loop_MPC_P.mpc.C[3] * Closed_loop_MPC_B.DataStoreRead[3];
    xaug[3] = Closed_loop_MPC_B.DataStoreRead[3] -
      Closed_loop_MPC_DW.UnitDelay2_DSTATE[3];

    /* '<S6>:1:39' */
    xaug[4] = b_q;

    /* '<S6>:1:40' */
    tempY = ((Closed_loop_MPC_P.mpc.C[0] * Closed_loop_MPC_DW.UnitDelay2_DSTATE
              [0] + Closed_loop_MPC_P.mpc.C[1] *
              Closed_loop_MPC_DW.UnitDelay2_DSTATE[1]) +
             Closed_loop_MPC_P.mpc.C[2] * Closed_loop_MPC_DW.UnitDelay2_DSTATE[2])
      + Closed_loop_MPC_P.mpc.C[3] * Closed_loop_MPC_DW.UnitDelay2_DSTATE[3];
    if (Closed_loop_MPC_P.mpc.osd == 1.0) {
      /* '<S6>:1:43' */
      /* '<S6>:1:44' */
      /* '<S6>:1:45' */
      if (Closed_loop_MPC_P.mpc.N == ajj) {
        /* '<S6>:1:46' */
        if ((6.0 - ajj) + 1.0 > 6.0) {
          jmax = 0;
          ix = -1;
        } else {
          jmax = (int32_T)((6.0 - ajj) + 1.0) - 1;
          ix = 5;
        }

        /* '<S6>:1:47' */
        j = ix - jmax;
        e_aoffset = j + 6;
        for (c_boffset = 0; c_boffset <= j; c_boffset++) {
          yrefnow_data[c_boffset] =
            Closed_loop_MPC_B.TmpRTBAtMATLABFunctionInport8[jmax + c_boffset];
        }

        for (c_boffset = 0; c_boffset < 5; c_boffset++) {
          yrefnow_data[((c_boffset + ix) - jmax) + 1] = rtb_yref_[1 + c_boffset];
        }
      } else {
        if ((6.0 - ajj) + 1.0 > 6.0) {
          iy = 0;
          jmax = -1;
        } else {
          iy = (int32_T)((6.0 - ajj) + 1.0) - 1;
          jmax = 5;
        }

        /* '<S6>:1:49' */
        j = jmax - iy;
        e_aoffset = j + 6;
        for (c_boffset = 0; c_boffset <= j; c_boffset++) {
          yrefnow_data[c_boffset] =
            Closed_loop_MPC_B.TmpRTBAtMATLABFunctionInport8[iy + c_boffset];
        }

        for (c_boffset = 0; c_boffset < 5; c_boffset++) {
          yrefnow_data[((c_boffset + jmax) - iy) + 1] =
            Closed_loop_MPC_DW.UnitDelay4_DSTATE[1 + c_boffset];
        }
      }

      /* '<S6>:1:51' */
      iy = e_aoffset;
      gprev_data[0] = b_q;
      if (0 <= e_aoffset - 2) {
        memcpy(&gprev_data[1], &yrefnow_data[0], (e_aoffset + -1) * sizeof
               (real_T));
      }

      Closed_loop_MPC_power(gprev_data, &e_aoffset, g_data, &g_size);

      /* '<S6>:1:52' */
      tempY_data[0] = tempY;
      tempY_data[1] = b_q;
      if (0 <= e_aoffset - 3) {
        memcpy(&tempY_data[2], &yrefnow_data[0], (e_aoffset + -2) * sizeof
               (real_T));
      }

      Closed_loop_MPC_power(tempY_data, &e_aoffset, gprev_data, &iy);

      /* '<S6>:1:53' */
      ajj += Closed_loop_MPC_P.mpc.N;
    } else {
      if (2.0 > 1.0 + ajj) {
        jmax = 0;
        ix = 0;
      } else {
        jmax = 1;
        ix = (int32_T)(1.0 + ajj);
      }

      /* '<S6>:1:55' */
      /* '<S6>:1:56' */
      ix -= jmax;
      for (c_boffset = 0; c_boffset < ix; c_boffset++) {
        yrefnow_data[c_boffset] = rtb_yref_[jmax + c_boffset];
      }

      if (ajj == 1.0) {
        /* '<S6>:1:57' */
        /* '<S6>:1:58' */
        g_size = 1;
        g_data[0] = rt_powd_snf(b_q, 3.0);

        /* '<S6>:1:59' */
        gprev_data[0] = rt_powd_snf(tempY, 3.0);
      } else if (ajj == 2.0) {
        /* '<S6>:1:60' */
        /* '<S6>:1:61' */
        g_size = 2;
        b_q = rt_powd_snf(b_q, 3.0);
        g_data[0] = b_q;
        g_data[1] = rt_powd_snf(rtb_yref_[jmax], 3.0);

        /* '<S6>:1:62' */
        gprev_data[0] = rt_powd_snf(tempY, 3.0);
        gprev_data[1] = b_q;
      } else {
        /* '<S6>:1:64' */
        if (1 > ix - 1) {
          iy = 1;
        } else {
          iy = ix;
        }

        b_q_data[0] = b_q;
        if (0 <= iy - 2) {
          memcpy(&b_q_data[1], &yrefnow_data[0], (iy + -1) * sizeof(real_T));
        }

        Closed_loop_MPC_power(b_q_data, &iy, g_data, &g_size);

        /* '<S6>:1:65' */
        if (1 > ix - 2) {
          ix = 2;
        }

        b_q_data[0] = tempY;
        b_q_data[1] = b_q;
        if (0 <= ix - 3) {
          memcpy(&b_q_data[2], &yrefnow_data[0], (ix + -2) * sizeof(real_T));
        }

        Closed_loop_MPC_power(b_q_data, &ix, gprev_data, &iy);
      }

      /* '<S6>:1:67' */
    }

    /* '<S6>:1:69' */
    for (c_boffset = 0; c_boffset < g_size; c_boffset++) {
      g_data[c_boffset] -= gprev_data[c_boffset];
    }

    if (1.0 > ajj) {
      ix = 0;
      d_m = 0;
      c_inner = 0;
    } else {
      ix = (int32_T)ajj;
      d_m = (int32_T)ajj;
      c_inner = (int32_T)ajj;
    }

    /* '<S6>:1:72' */
    /* '<S6>:1:73' */
    for (c_boffset = 0; c_boffset < c_inner; c_boffset++) {
      for (coffset = 0; coffset < d_m; coffset++) {
        Su_data[coffset + d_m * c_boffset] = Closed_loop_MPC_P.mpc.Su[5 *
          c_boffset + coffset];
      }
    }

    if (1.0 > ajj) {
      jmax = 0;
      j = 0;
      iy = 0;
      e_aoffset = 0;
    } else {
      jmax = (int32_T)ajj;
      j = (int32_T)ajj;
      iy = (int32_T)ajj;
      e_aoffset = (int32_T)ajj;
    }

    /* '<S6>:1:74' */
    /* '<S6>:1:75' */
    for (c_boffset = 0; c_boffset < e_aoffset; c_boffset++) {
      for (coffset = 0; coffset < iy; coffset++) {
        Omega_data[coffset + iy * c_boffset] = Closed_loop_MPC_P.mpc.Omega[5 *
          c_boffset + coffset];
      }
    }

    /* '<S6>:1:76' */
    for (c_boffset = 0; c_boffset < d_m; c_boffset++) {
      for (coffset = 0; coffset < c_inner; coffset++) {
        GinvF_data[coffset + c_inner * c_boffset] = Su_data[d_m * coffset +
          c_boffset];
      }
    }

    if ((d_m == 1) || (iy == 1)) {
      for (c_boffset = 0; c_boffset < c_inner; c_boffset++) {
        for (coffset = 0; coffset < e_aoffset; coffset++) {
          jj = c_inner * coffset;
          e_k = c_boffset + jj;
          c_y_data[e_k] = 0.0;
          for (boffset = 0; boffset < d_m; boffset++) {
            c_y_data[e_k] = GinvF_data[c_inner * boffset + c_boffset] *
              Omega_data[iy * coffset + boffset] + c_y_data[jj + c_boffset];
          }
        }
      }
    } else {
      for (c_boffset = 0; c_boffset < e_aoffset; c_boffset++) {
        coffset = c_boffset * c_inner;
        boffset = c_boffset * d_m;
        for (jj = 0; jj < c_inner; jj++) {
          c_y_data[coffset + jj] = 0.0;
        }

        for (e_k = 0; e_k < d_m; e_k++) {
          aoffset = e_k * c_inner;
          jj = boffset + e_k;
          tempY = Closed_loop_MPC_P.mpc.Omega[jj % iy + 5 * div_nzp_s32_floor(jj,
            iy)];
          for (b_n = 1; b_n - 1 < c_inner; b_n++) {
            jj = (coffset + b_n) - 1;
            c_y_data[jj] += GinvF_data[(aoffset + b_n) - 1] * tempY;
          }
        }
      }
    }

    if ((e_aoffset == 1) || (d_m == 1)) {
      GinvF_size[0] = c_inner;
      for (c_boffset = 0; c_boffset < c_inner; c_boffset++) {
        for (coffset = 0; coffset < c_inner; coffset++) {
          jj = c_inner * coffset;
          e_k = c_boffset + jj;
          GinvF_data[e_k] = 0.0;
          for (boffset = 0; boffset < e_aoffset; boffset++) {
            GinvF_data[e_k] = c_y_data[c_inner * boffset + c_boffset] *
              Su_data[d_m * coffset + boffset] + GinvF_data[jj + c_boffset];
          }
        }
      }
    } else {
      GinvF_size[0] = c_inner;
      for (c_boffset = 0; c_boffset < c_inner; c_boffset++) {
        coffset = c_boffset * c_inner;
        boffset = c_boffset * e_aoffset;
        for (jj = 0; jj < c_inner; jj++) {
          GinvF_data[coffset + jj] = 0.0;
        }

        for (e_k = 0; e_k < e_aoffset; e_k++) {
          aoffset = e_k * c_inner;
          jj = boffset + e_k;
          tempY = Closed_loop_MPC_P.mpc.Su[jj % d_m + 5 * div_nzp_s32_floor(jj,
            d_m)];
          for (b_n = 1; b_n - 1 < c_inner; b_n++) {
            jj = (coffset + b_n) - 1;
            GinvF_data[jj] += c_y_data[(aoffset + b_n) - 1] * tempY;
          }
        }
      }
    }

    /* '<S6>:1:78' */
    /* '<S6>:1:79' */
    for (c_boffset = 0; c_boffset < d_m; c_boffset++) {
      for (coffset = 0; coffset < c_inner; coffset++) {
        c_y_data[coffset + c_inner * c_boffset] = Su_data[d_m * coffset +
          c_boffset] * 2.0;
      }
    }

    if ((d_m == 1) || (iy == 1)) {
      Su_size[0] = c_inner;
      Su_size[1] = e_aoffset;
      for (c_boffset = 0; c_boffset < c_inner; c_boffset++) {
        for (coffset = 0; coffset < e_aoffset; coffset++) {
          jj = c_inner * coffset;
          e_k = c_boffset + jj;
          Su_data[e_k] = 0.0;
          for (boffset = 0; boffset < d_m; boffset++) {
            Su_data[e_k] = c_y_data[c_inner * boffset + c_boffset] *
              Omega_data[iy * coffset + boffset] + Su_data[jj + c_boffset];
          }
        }
      }
    } else {
      Su_size[0] = c_inner;
      Su_size[1] = e_aoffset;
      for (aoffset = 0; aoffset < e_aoffset; aoffset++) {
        b_n = aoffset * c_inner;
        c_boffset = aoffset * d_m;
        for (jj = 0; jj < c_inner; jj++) {
          Su_data[b_n + jj] = 0.0;
        }

        for (coffset = 0; coffset < d_m; coffset++) {
          boffset = coffset * c_inner;
          jj = c_boffset + coffset;
          tempY = Closed_loop_MPC_P.mpc.Omega[jj % iy + 5 * div_nzp_s32_floor(jj,
            iy)];
          for (e_k = 1; e_k - 1 < c_inner; e_k++) {
            jj = (b_n + e_k) - 1;
            Su_data[jj] += c_y_data[(boffset + e_k) - 1] * tempY;
          }
        }
      }
    }

    /* '<S6>:1:80' */
    if (1.0 > ajj) {
      iy = 0;
      d_m = 0;
    } else {
      iy = (int32_T)ajj;
      d_m = (int32_T)ajj;
    }

    tmp_size[0] = iy;
    tmp_size[1] = d_m;
    for (c_boffset = 0; c_boffset < d_m; c_boffset++) {
      for (coffset = 0; coffset < iy; coffset++) {
        Omega_data[coffset + iy * c_boffset] = (Closed_loop_MPC_P.mpc.Psi[5 *
          c_boffset + coffset] + GinvF_data[GinvF_size[0] * c_boffset + coffset])
          * 2.0;
      }
    }

    Closed_loop_MPC_mldivide(Omega_data, tmp_size, Su_data, Su_size, GinvF_data,
      GinvF_size);
    for (jj = 0; jj < ix; jj++) {
      uN_data[jj] = 0.0;
    }

    for (e_aoffset = 0; e_aoffset < 5; e_aoffset++) {
      c_boffset = e_aoffset * ix;
      for (d_m = 0; d_m < ix; d_m++) {
        jj = c_boffset + d_m;
        uN_data[d_m] += Closed_loop_MPC_P.mpc.Sx[jj % ix + 5 * div_nzp_s32_floor
          (jj, ix)] * xaug[e_aoffset];
      }
    }

    if ((j == 1) || (g_size == 1)) {
      if (1.0 > ajj) {
        iy = 0;
        d_m = 0;
      } else {
        iy = (int32_T)ajj;
        d_m = (int32_T)ajj;
      }

      for (c_boffset = 0; c_boffset < d_m; c_boffset++) {
        for (coffset = 0; coffset < iy; coffset++) {
          Omega_data[coffset + iy * c_boffset] = Closed_loop_MPC_P.mpc.Sg[5 *
            c_boffset + coffset];
        }
      }

      for (c_boffset = 0; c_boffset < iy; c_boffset++) {
        u_data[c_boffset] = 0.0;
        for (coffset = 0; coffset < d_m; coffset++) {
          u_data[c_boffset] += Omega_data[iy * coffset + c_boffset] *
            g_data[coffset];
        }
      }
    } else {
      for (jj = 0; jj < jmax; jj++) {
        u_data[jj] = 0.0;
      }

      for (iy = 0; iy < j; iy++) {
        e_aoffset = iy * jmax;
        for (c_boffset = 0; c_boffset < jmax; c_boffset++) {
          jj = e_aoffset + c_boffset;
          u_data[c_boffset] += Closed_loop_MPC_P.mpc.Sg[jj % jmax + 5 *
            div_nzp_s32_floor(jj, jmax)] * g_data[iy];
        }
      }
    }

    /* '<S6>:1:82' */
    iy = GinvF_size[0] * GinvF_size[1] - 1;
    for (c_boffset = 0; c_boffset <= iy; c_boffset++) {
      GinvF_data[c_boffset] = -GinvF_data[c_boffset];
    }

    for (c_boffset = 0; c_boffset < ix; c_boffset++) {
      yrefnow_data[c_boffset] = (uN_data[c_boffset] + u_data[c_boffset]) -
        yrefnow_data[c_boffset];
    }

    if ((GinvF_size[1] == 1) || (ix == 1)) {
      e_aoffset = GinvF_size[0];
      iy = GinvF_size[0];
      for (c_boffset = 0; c_boffset < iy; c_boffset++) {
        uN_data[c_boffset] = 0.0;
        d_m = GinvF_size[1];
        for (coffset = 0; coffset < d_m; coffset++) {
          uN_data[c_boffset] += GinvF_data[GinvF_size[0] * coffset + c_boffset] *
            yrefnow_data[coffset];
        }
      }
    } else {
      jmax = GinvF_size[0];
      e_aoffset = GinvF_size[0];
      for (j = 0; j < jmax; j++) {
        uN_data[j] = 0.0;
      }

      for (j = 0; j < GinvF_size[1]; j++) {
        ix = j * jmax;
        for (iy = 0; iy < jmax; iy++) {
          uN_data[iy] += GinvF_data[ix + iy] * yrefnow_data[j];
        }
      }
    }

    /* '<S6>:1:85' */
    c_boffset = v->size[0] * v->size[1];
    v->size[0] = 1;
    coffset = (int32_T)(ajj - 1.0);
    v->size[1] = coffset + 1;
    Closed_emxEnsureCapacity_real_T(v, c_boffset);
    iy = coffset - 1;
    v->data[0] = 1.0;
    for (c_boffset = 0; c_boffset <= iy; c_boffset++) {
      v->data[c_boffset + 1] = 0.0;
    }

    if ((v->size[1] == 1) || (e_aoffset == 1)) {
      ajj = 0.0;
      iy = v->size[1];
      for (c_boffset = 0; c_boffset < iy; c_boffset++) {
        ajj += v->data[c_boffset] * uN_data[c_boffset];
      }
    } else {
      ajj = 0.0;
      iy = v->size[1];
      for (c_boffset = 0; c_boffset < iy; c_boffset++) {
        ajj += v->data[c_boffset] * uN_data[c_boffset];
      }
    }
  }

  Closed_loop_MPC_emxFree_real_T(&v);

  /* MATLAB Function: '<S2>/MATLAB Function' */
  Closed_loop_MPC_B.xref1[0] = xref->data[4];
  Closed_loop_MPC_B.xref1[1] = xref->data[5];
  Closed_loop_MPC_B.xref1[2] = xref->data[6];
  Closed_loop_MPC_B.xref1[3] = xref->data[7];
  Closed_loop_MPC_emxFree_real_T(&xref);

  /* Sum: '<S2>/Sum' incorporates:
   *  MATLAB Function: '<S2>/MATLAB Function'
   *  UnitDelay: '<S2>/Unit Delay3'
   */
  Closed_loop_MPC_B.u = ajj + Closed_loop_MPC_DW.UnitDelay3_DSTATE;

  /* ToWorkspace: '<Root>/To Workspace3' */
  rt_UpdateLogVar((LogVar *)(LogVar*)
                  (Closed_loop_MPC_DW.ToWorkspace3_PWORK.LoggedData),
                  &Closed_loop_MPC_B.u, 0);

  /* ToWorkspace: '<Root>/To Workspace5' */
  rt_UpdateLogVar((LogVar *)(LogVar*)
                  (Closed_loop_MPC_DW.ToWorkspace5_PWORK.LoggedData),
                  &Closed_loop_MPC_B.TmpRTBAtToWorkspace5Inport1, 0);

  /* Delay: '<S2>/Delay' incorporates:
   *  Gain: '<S2>/Gain'
   *  UnitDelay: '<S2>/Unit Delay'
   */
  Closed_loop_MPC_B.y_refMPC = ((Closed_loop_MPC_P.Cc[0] *
    Closed_loop_MPC_DW.UnitDelay_DSTATE[0] + Closed_loop_MPC_P.Cc[1] *
    Closed_loop_MPC_DW.UnitDelay_DSTATE[1]) + Closed_loop_MPC_P.Cc[2] *
    Closed_loop_MPC_DW.UnitDelay_DSTATE[2]) + Closed_loop_MPC_P.Cc[3] *
    Closed_loop_MPC_DW.UnitDelay_DSTATE[3];

  /* Sum: '<S2>/Sum1' incorporates:
   *  Gain: '<S2>/Gain1'
   */
  Closed_loop_MPC_B.e = (((Closed_loop_MPC_P.Cc[0] *
    Closed_loop_MPC_B.DataStoreRead[0] + Closed_loop_MPC_P.Cc[1] *
    Closed_loop_MPC_B.DataStoreRead[1]) + Closed_loop_MPC_P.Cc[2] *
    Closed_loop_MPC_B.DataStoreRead[2]) + Closed_loop_MPC_P.Cc[3] *
    Closed_loop_MPC_B.DataStoreRead[3]) - Closed_loop_MPC_B.y_refMPC;

  /* RateTransition: '<S2>/e' */
  if (Closed_loop_MPC_M->Timing.RateInteraction.TID2_3) {
    Closed_loop_MPC_B.e_c = Closed_loop_MPC_B.e;
  }

  /* End of RateTransition: '<S2>/e' */

  /* ToWorkspace: '<S2>/To Workspace4' */
  rt_UpdateLogVar((LogVar *)(LogVar*)
                  (Closed_loop_MPC_DW.ToWorkspace4_PWORK_f.LoggedData),
                  &Closed_loop_MPC_B.y_refMPC, 0);

  /* RateTransition: '<S2>/TmpRTBAtMATLAB FunctionOutport4' */
  if (Closed_loop_MPC_M->Timing.RateInteraction.TID2_3) {
    /* RateTransition: '<S2>/TmpRTBAtUnit Delay4Inport1' */
    for (jmax = 0; jmax < 6; jmax++) {
      Closed_loop_MPC_B.TmpRTBAtMATLABFunctionOutport4[jmax] = rtb_yref_[jmax];
      Closed_loop_MPC_B.TmpRTBAtUnitDelay4Inport1[jmax] =
        Closed_loop_MPC_DW.TmpRTBAtUnitDelay4Inport1_Buffe[jmax];
    }

    /* End of RateTransition: '<S2>/TmpRTBAtUnit Delay4Inport1' */
  }

  /* End of RateTransition: '<S2>/TmpRTBAtMATLAB FunctionOutport4' */

  /* Outputs for Atomic SubSystem: '<S5>/Predict' */
  /* SignalConversion: '<S19>/TmpSignal ConversionAt SFunction Inport4' incorporates:
   *  MATLAB Function: '<S17>/Predict'
   */
  rtb_TmpSignalConversionAtSFunct[0] = Closed_loop_MPC_B.Gain1;

  /* DataStoreRead: '<S17>/Data Store ReadP' */
  memcpy(&sqrtP[0], &Closed_loop_MPC_DW.P[0], sizeof(real_T) << 4U);

  /* SignalConversion: '<S19>/TmpSignal ConversionAt SFunction Inport4' incorporates:
   *  Constant: '<S4>/Constant1'
   *  Constant: '<S4>/Constant3'
   *  Constant: '<S4>/Constant4'
   *  MATLAB Function: '<S17>/Predict'
   */
  memcpy(&rtb_TmpSignalConversionAtSFunct[1], &Closed_loop_MPC_P.Ad[0], sizeof
         (real_T) << 4U);
  rtb_TmpSignalConversionAtSFunct[17] = Closed_loop_MPC_P.Bd[0];
  rtb_TmpSignalConversionAtSFunct[21] = Closed_loop_MPC_P.Ed[0];
  rtb_TmpSignalConversionAtSFunct[18] = Closed_loop_MPC_P.Bd[1];
  rtb_TmpSignalConversionAtSFunct[22] = Closed_loop_MPC_P.Ed[1];
  rtb_TmpSignalConversionAtSFunct[19] = Closed_loop_MPC_P.Bd[2];
  rtb_TmpSignalConversionAtSFunct[23] = Closed_loop_MPC_P.Ed[2];
  rtb_TmpSignalConversionAtSFunct[20] = Closed_loop_MPC_P.Bd[3];
  rtb_TmpSignalConversionAtSFunct[24] = Closed_loop_MPC_P.Ed[3];
  rtb_TmpSignalConversionAtSFunct[25] = Closed_loop_MPC_B.u;

  /* MATLAB Function: '<S17>/Predict' incorporates:
   *  DataStoreRead: '<S17>/Data Store ReadX'
   *  SignalConversion: '<S19>/TmpSignal ConversionAt SFunction Inport4'
   */
  /* MATLAB Function 'Unscented Kalman Filter/Predict/Predict': '<S19>:1' */
  jmax = 0;
  j = 1;
  exitg1 = false;
  while ((!exitg1) && (j - 1 < 4)) {
    jj = (((j - 1) << 2) + j) - 1;
    ajj = 0.0;
    if (j - 1 >= 1) {
      ix = j;
      iy = j;
      for (e_aoffset = 0; e_aoffset <= j - 2; e_aoffset++) {
        ajj += sqrtP[ix - 1] * sqrtP[iy - 1];
        ix += 4;
        iy += 4;
      }
    }

    ajj = sqrtP[jj] - ajj;
    if (ajj > 0.0) {
      ajj = sqrt(ajj);
      sqrtP[jj] = ajj;
      if (j < 4) {
        if (j - 1 != 0) {
          e_aoffset = j;
          iy = (((j - 2) << 2) + j) + 1;
          for (c_boffset = j + 1; c_boffset <= iy; c_boffset += 4) {
            tempY = -sqrtP[e_aoffset - 1];
            d_m = jj + 1;
            ix = (c_boffset - j) + 3;
            for (c_inner = c_boffset; c_inner <= ix; c_inner++) {
              sqrtP[d_m] += sqrtP[c_inner - 1] * tempY;
              d_m++;
            }

            e_aoffset += 4;
          }
        }

        ajj = 1.0 / ajj;
        ix = (jj - j) + 5;
        for (jj++; jj < ix; jj++) {
          sqrtP[jj] *= ajj;
        }
      }

      j++;
    } else {
      sqrtP[jj] = ajj;
      jmax = j;
      exitg1 = true;
    }
  }

  if (jmax == 0) {
    jmax = 5;
  }

  jmax--;
  for (j = 1; j < jmax; j++) {
    for (jj = 0; jj < j; jj++) {
      sqrtP[jj + (j << 2)] = 0.0;
    }
  }

  for (c_boffset = 0; c_boffset < 16; c_boffset++) {
    ajj = 0.002 * sqrtP[c_boffset];
    X2[c_boffset] = ajj;
    X2[c_boffset + 16] = -ajj;
    sqrtP[c_boffset] = ajj;
  }

  ajj = rt_powd_snf(rtb_TmpSignalConversionAtSFunct[0], 3.0);
  for (jmax = 0; jmax < 8; jmax++) {
    ix = jmax << 2;
    X2[ix] += Closed_loop_MPC_DW.x[0];
    j = ix + 1;
    X2[1 + ix] = X2[j] + Closed_loop_MPC_DW.x[1];
    iy = ix + 2;
    X2[2 + ix] = X2[iy] + Closed_loop_MPC_DW.x[2];
    e_aoffset = ix + 3;
    X2[3 + ix] = X2[e_aoffset] + Closed_loop_MPC_DW.x[3];
    memcpy(&sqrtP[0], &rtb_TmpSignalConversionAtSFunct[1], sizeof(real_T) << 4U);
    for (c_boffset = 0; c_boffset < 4; c_boffset++) {
      Y2_0[c_boffset + ix] = ((((X2[j] * sqrtP[c_boffset + 4] + X2[ix] *
        sqrtP[c_boffset]) + X2[iy] * sqrtP[c_boffset + 8]) + X2[e_aoffset] *
        sqrtP[c_boffset + 12]) + rtb_TmpSignalConversionAtSFunct[17 + c_boffset]
        * Closed_loop_MPC_B.u) + rtb_TmpSignalConversionAtSFunct[21 + c_boffset]
        * ajj;
    }
  }

  memcpy(&sqrtP[0], &rtb_TmpSignalConversionAtSFunct[1], sizeof(real_T) << 4U);
  for (jmax = 0; jmax < 4; jmax++) {
    tempY = ((((sqrtP[jmax + 4] * Closed_loop_MPC_DW.x[1] + sqrtP[jmax] *
                Closed_loop_MPC_DW.x[0]) + sqrtP[jmax + 8] *
               Closed_loop_MPC_DW.x[2]) + sqrtP[jmax + 12] *
              Closed_loop_MPC_DW.x[3]) + rtb_TmpSignalConversionAtSFunct[17 +
             jmax] * Closed_loop_MPC_B.u) + rtb_TmpSignalConversionAtSFunct[21 +
      jmax] * ajj;
    rtb_xNew[jmax] = tempY;
    gain[jmax] = tempY;
  }

  for (jmax = 0; jmax < 8; jmax++) {
    rtb_xNew[0] += Y2_0[jmax << 2] * -0.125000125000125;
    rtb_xNew[1] += Y2_0[(jmax << 2) + 1] * -0.125000125000125;
    rtb_xNew[2] += Y2_0[(jmax << 2) + 2] * -0.125000125000125;
    rtb_xNew[3] += Y2_0[(jmax << 2) + 3] * -0.125000125000125;
  }

  ajj = rtb_xNew[0] * -999999.0;
  rtb_xNew[0] = ajj;
  gain[0] -= ajj;
  ajj = rtb_xNew[1] * -999999.0;
  rtb_xNew[1] = ajj;
  gain[1] -= ajj;
  ajj = rtb_xNew[2] * -999999.0;
  rtb_xNew[2] = ajj;
  gain[2] -= ajj;
  ajj = rtb_xNew[3] * -999999.0;
  gain[3] -= ajj;
  for (jmax = 0; jmax < 8; jmax++) {
    Y2_0[jmax << 2] -= rtb_xNew[0];
    Y2_0[1 + (jmax << 2)] -= rtb_xNew[1];
    Y2_0[2 + (jmax << 2)] -= rtb_xNew[2];
    Y2_0[3 + (jmax << 2)] -= ajj;
  }

  /* '<S19>:1:29' */
  for (c_boffset = 0; c_boffset < 4; c_boffset++) {
    for (coffset = 0; coffset < 4; coffset++) {
      jmax = coffset << 2;
      ix = c_boffset + jmax;
      sqrtP[ix] = gain[c_boffset] * gain[coffset];
      Y2_1[ix] = 0.0;
      for (boffset = 0; boffset < 8; boffset++) {
        j = boffset << 2;
        Y2_1[ix] = Y2_0[j + c_boffset] * Y2_0[j + coffset] + Y2_1[jmax +
          c_boffset];
      }
    }
  }

  /* DataStoreWrite: '<S17>/Data Store WriteP' incorporates:
   *  Constant: '<S5>/Q'
   *  MATLAB Function: '<S17>/Predict'
   */
  for (c_boffset = 0; c_boffset < 16; c_boffset++) {
    Closed_loop_MPC_DW.P[c_boffset] = (0.999996999998 * sqrtP[c_boffset] +
      -0.125000125000125 * Y2_1[c_boffset]) * -999999.0 +
      Closed_loop_MPC_P.Q_Value[c_boffset];
  }

  /* End of DataStoreWrite: '<S17>/Data Store WriteP' */

  /* DataStoreWrite: '<S17>/Data Store WriteX' */
  Closed_loop_MPC_DW.x[0] = rtb_xNew[0];
  Closed_loop_MPC_DW.x[1] = rtb_xNew[1];
  Closed_loop_MPC_DW.x[2] = rtb_xNew[2];
  Closed_loop_MPC_DW.x[3] = ajj;

  /* End of Outputs for SubSystem: '<S5>/Predict' */
}

/* Model update function for TID2 */
void Closed_loop_MPC_update2(void)     /* Sample time: [0.001953125s, 0.0s] */
{
  int32_T i;

  /* Update for UnitDelay: '<S2>/Unit Delay2' */
  Closed_loop_MPC_DW.UnitDelay2_DSTATE[0] = Closed_loop_MPC_B.DataStoreRead[0];

  /* Update for UnitDelay: '<S2>/Unit Delay' */
  Closed_loop_MPC_DW.UnitDelay_DSTATE[0] = Closed_loop_MPC_B.xref1[0];

  /* Update for UnitDelay: '<S2>/Unit Delay2' */
  Closed_loop_MPC_DW.UnitDelay2_DSTATE[1] = Closed_loop_MPC_B.DataStoreRead[1];

  /* Update for UnitDelay: '<S2>/Unit Delay' */
  Closed_loop_MPC_DW.UnitDelay_DSTATE[1] = Closed_loop_MPC_B.xref1[1];

  /* Update for UnitDelay: '<S2>/Unit Delay2' */
  Closed_loop_MPC_DW.UnitDelay2_DSTATE[2] = Closed_loop_MPC_B.DataStoreRead[2];

  /* Update for UnitDelay: '<S2>/Unit Delay' */
  Closed_loop_MPC_DW.UnitDelay_DSTATE[2] = Closed_loop_MPC_B.xref1[2];

  /* Update for UnitDelay: '<S2>/Unit Delay2' */
  Closed_loop_MPC_DW.UnitDelay2_DSTATE[3] = Closed_loop_MPC_B.DataStoreRead[3];

  /* Update for UnitDelay: '<S2>/Unit Delay' */
  Closed_loop_MPC_DW.UnitDelay_DSTATE[3] = Closed_loop_MPC_B.xref1[3];

  /* Update for UnitDelay: '<S2>/Unit Delay4' */
  for (i = 0; i < 6; i++) {
    Closed_loop_MPC_DW.UnitDelay4_DSTATE[i] =
      Closed_loop_MPC_B.TmpRTBAtUnitDelay4Inport1[i];
  }

  /* End of Update for UnitDelay: '<S2>/Unit Delay4' */

  /* Update for UnitDelay: '<S2>/Unit Delay3' */
  Closed_loop_MPC_DW.UnitDelay3_DSTATE = Closed_loop_MPC_B.u;

  /* Update for RateTransition: '<Root>/u' */
  Closed_loop_MPC_DW.u_Buffer0 = Closed_loop_MPC_B.u;

  /* Update absolute time */
  /* The "clockTick2" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick2"
   * and "Timing.stepSize2". Size of "clockTick2" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick2 and the high bits
   * Timing.clockTickH2. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++Closed_loop_MPC_M->Timing.clockTick2)) {
    ++Closed_loop_MPC_M->Timing.clockTickH2;
  }

  Closed_loop_MPC_M->Timing.t[2] = Closed_loop_MPC_M->Timing.clockTick2 *
    Closed_loop_MPC_M->Timing.stepSize2 + Closed_loop_MPC_M->Timing.clockTickH2 *
    Closed_loop_MPC_M->Timing.stepSize2 * 4294967296.0;
}

/* Model output function for TID3 */
void Closed_loop_MPC_output3(void)     /* Sample time: [0.009765625s, 0.0s] */
{
  int32_T i;

  /* FromWorkspace: '<Root>/From Workspace1' */
  {
    real_T *pDataValues = (real_T *)
      Closed_loop_MPC_DW.FromWorkspace1_PWORK.DataPtr;
    real_T *pTimeValues = (real_T *)
      Closed_loop_MPC_DW.FromWorkspace1_PWORK.TimePtr;
    int_T currTimeIndex = Closed_loop_MPC_DW.FromWorkspace1_IWORK.PrevIndex;
    real_T t = Closed_loop_MPC_M->Timing.t[3];

    /* Get index */
    if (t <= pTimeValues[0]) {
      currTimeIndex = 0;
    } else if (t >= pTimeValues[4099]) {
      currTimeIndex = 4098;
    } else {
      if (t < pTimeValues[currTimeIndex]) {
        while (t < pTimeValues[currTimeIndex]) {
          currTimeIndex--;
        }
      } else {
        while (t >= pTimeValues[currTimeIndex + 1]) {
          currTimeIndex++;
        }
      }
    }

    Closed_loop_MPC_DW.FromWorkspace1_IWORK.PrevIndex = currTimeIndex;

    /* Post output */
    {
      real_T t1 = pTimeValues[currTimeIndex];
      real_T t2 = pTimeValues[currTimeIndex + 1];
      if (t1 == t2) {
        if (t < t1) {
          Closed_loop_MPC_B.v_a = pDataValues[currTimeIndex];
        } else {
          Closed_loop_MPC_B.v_a = pDataValues[currTimeIndex + 1];
        }
      } else {
        real_T f1 = (t2 - t) / (t2 - t1);
        real_T f2 = 1.0 - f1;
        real_T d1;
        real_T d2;
        int_T TimeIndex= currTimeIndex;
        d1 = pDataValues[TimeIndex];
        d2 = pDataValues[TimeIndex + 1];
        Closed_loop_MPC_B.v_a = (real_T) rtInterpolate(d1, d2, f1, f2);
        pDataValues += 4100;
      }
    }
  }

  /* ToWorkspace: '<S2>/To Workspace3' */
  rt_UpdateLogVar((LogVar *)(LogVar*)
                  (Closed_loop_MPC_DW.ToWorkspace3_PWORK_o.LoggedData),
                  &Closed_loop_MPC_B.e_c, 0);

  /* UnitDelay: '<S2>/Unit Delay1' */
  for (i = 0; i < 6; i++) {
    Closed_loop_MPC_B.UnitDelay1[i] = Closed_loop_MPC_DW.UnitDelay1_DSTATE[i];
  }

  /* End of UnitDelay: '<S2>/Unit Delay1' */
}

/* Model update function for TID3 */
void Closed_loop_MPC_update3(void)     /* Sample time: [0.009765625s, 0.0s] */
{
  int32_T i;

  /* Update for RateTransition: '<Root>/v' */
  Closed_loop_MPC_DW.v_Buffer0 = Closed_loop_MPC_B.v_a;

  /* Update for RateTransition: '<S2>/TmpRTBAtMATLAB FunctionInport8' */
  for (i = 0; i < 6; i++) {
    Closed_loop_MPC_DW.TmpRTBAtMATLABFunctionInport8_B[i] =
      Closed_loop_MPC_B.UnitDelay1[i];
  }

  /* End of Update for RateTransition: '<S2>/TmpRTBAtMATLAB FunctionInport8' */

  /* Update for RateTransition: '<S2>/TmpRTBAtUnit Delay4Inport1' */
  for (i = 0; i < 6; i++) {
    Closed_loop_MPC_DW.TmpRTBAtUnitDelay4Inport1_Buffe[i] =
      Closed_loop_MPC_B.TmpRTBAtMATLABFunctionOutport4[i];
  }

  /* End of Update for RateTransition: '<S2>/TmpRTBAtUnit Delay4Inport1' */

  /* Update for UnitDelay: '<S2>/Unit Delay1' */
  for (i = 0; i < 6; i++) {
    Closed_loop_MPC_DW.UnitDelay1_DSTATE[i] =
      Closed_loop_MPC_B.TmpRTBAtMATLABFunctionOutport4[i];
  }

  /* End of Update for UnitDelay: '<S2>/Unit Delay1' */

  /* Update absolute time */
  /* The "clockTick3" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick3"
   * and "Timing.stepSize3". Size of "clockTick3" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick3 and the high bits
   * Timing.clockTickH3. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++Closed_loop_MPC_M->Timing.clockTick3)) {
    ++Closed_loop_MPC_M->Timing.clockTickH3;
  }

  Closed_loop_MPC_M->Timing.t[3] = Closed_loop_MPC_M->Timing.clockTick3 *
    Closed_loop_MPC_M->Timing.stepSize3 + Closed_loop_MPC_M->Timing.clockTickH3 *
    Closed_loop_MPC_M->Timing.stepSize3 * 4294967296.0;
}

/* Model output wrapper function for compatibility with a static main program */
void Closed_loop_MPC_output(int_T tid)
{
  switch (tid) {
   case 0 :
    Closed_loop_MPC_output0();
    break;

   case 2 :
    Closed_loop_MPC_output2();
    break;

   case 3 :
    Closed_loop_MPC_output3();
    break;

   default :
    break;
  }
}

/* Model update wrapper function for compatibility with a static main program */
void Closed_loop_MPC_update(int_T tid)
{
  switch (tid) {
   case 0 :
    Closed_loop_MPC_update0();
    break;

   case 2 :
    Closed_loop_MPC_update2();
    break;

   case 3 :
    Closed_loop_MPC_update3();
    break;

   default :
    break;
  }
}

/* Model initialize function */
void Closed_loop_MPC_initialize(void)
{
  {
    int32_T i;

    /* Start for ToWorkspace: '<Root>/To Workspace' */
    {
      int_T dimensions[1] = { 1 };

      Closed_loop_MPC_DW.ToWorkspace_PWORK.LoggedData = rt_CreateLogVar(
        Closed_loop_MPC_M->rtwLogInfo,
        0.0,
        rtmGetTFinal(Closed_loop_MPC_M),
        Closed_loop_MPC_M->Timing.stepSize0,
        (&rtmGetErrorStatus(Closed_loop_MPC_M)),
        "yfb",
        SS_DOUBLE,
        0,
        0,
        0,
        1,
        1,
        dimensions,
        NO_LOGVALDIMS,
        (NULL),
        (NULL),
        0,
        1,
        0.000244140625,
        1);
      if (Closed_loop_MPC_DW.ToWorkspace_PWORK.LoggedData == (NULL))
        return;
    }

    /* Start for ToWorkspace: '<Root>/To Workspace1' */
    {
      int_T dimensions[1] = { 4 };

      Closed_loop_MPC_DW.ToWorkspace1_PWORK.LoggedData = rt_CreateLogVar(
        Closed_loop_MPC_M->rtwLogInfo,
        0.0,
        rtmGetTFinal(Closed_loop_MPC_M),
        Closed_loop_MPC_M->Timing.stepSize0,
        (&rtmGetErrorStatus(Closed_loop_MPC_M)),
        "xhat",
        SS_DOUBLE,
        0,
        0,
        0,
        4,
        1,
        dimensions,
        NO_LOGVALDIMS,
        (NULL),
        (NULL),
        0,
        1,
        0.001953125,
        1);
      if (Closed_loop_MPC_DW.ToWorkspace1_PWORK.LoggedData == (NULL))
        return;
    }

    /* Start for ToWorkspace: '<Root>/To Workspace2' */
    {
      static int_T rt_ToWksWidths[] = { 1 };

      static int_T rt_ToWksNumDimensions[] = { 1 };

      static int_T rt_ToWksDimensions[] = { 1 };

      static boolean_T rt_ToWksIsVarDims[] = { 0 };

      static void *rt_ToWksCurrSigDims[] = { (NULL) };

      static int_T rt_ToWksCurrSigDimsSize[] = { 4 };

      static BuiltInDTypeId rt_ToWksDataTypeIds[] = { SS_DOUBLE };

      static int_T rt_ToWksComplexSignals[] = { 0 };

      static int_T rt_ToWksFrameData[] = { 0 };

      static RTWPreprocessingFcnPtr rt_ToWksLoggingPreprocessingFcnPtrs[] = {
        (NULL)
      };

      static const char_T *rt_ToWksLabels[] = { "" };

      static RTWLogSignalInfo rt_ToWksSignalInfo = {
        1,
        rt_ToWksWidths,
        rt_ToWksNumDimensions,
        rt_ToWksDimensions,
        rt_ToWksIsVarDims,
        rt_ToWksCurrSigDims,
        rt_ToWksCurrSigDimsSize,
        rt_ToWksDataTypeIds,
        rt_ToWksComplexSignals,
        rt_ToWksFrameData,
        rt_ToWksLoggingPreprocessingFcnPtrs,

        { rt_ToWksLabels },
        (NULL),
        (NULL),
        (NULL),

        { (NULL) },

        { (NULL) },
        (NULL),
        (NULL)
      };

      static const char_T rt_ToWksBlockName[] = "Closed_loop_MPC/To Workspace2";
      Closed_loop_MPC_DW.ToWorkspace2_PWORK.LoggedData = rt_CreateStructLogVar(
        Closed_loop_MPC_M->rtwLogInfo,
        0.0,
        rtmGetTFinal(Closed_loop_MPC_M),
        Closed_loop_MPC_M->Timing.stepSize0,
        (&rtmGetErrorStatus(Closed_loop_MPC_M)),
        "yhat",
        1,
        0,
        1,
        0.001953125,
        &rt_ToWksSignalInfo,
        rt_ToWksBlockName);
      if (Closed_loop_MPC_DW.ToWorkspace2_PWORK.LoggedData == (NULL))
        return;
    }

    /* Start for RateTransition: '<Root>/v' */
    Closed_loop_MPC_B.v = Closed_loop_MPC_P.v_InitialCondition;

    /* Start for RateTransition: '<S2>/TmpRTBAtMATLAB FunctionInport8' */
    for (i = 0; i < 6; i++) {
      Closed_loop_MPC_B.TmpRTBAtMATLABFunctionInport8[i] =
        Closed_loop_MPC_P.TmpRTBAtMATLABFunctionInport8_I;
    }

    /* End of Start for RateTransition: '<S2>/TmpRTBAtMATLAB FunctionInport8' */

    /* Start for ToWorkspace: '<Root>/To Workspace3' */
    {
      int_T dimensions[1] = { 1 };

      Closed_loop_MPC_DW.ToWorkspace3_PWORK.LoggedData = rt_CreateLogVar(
        Closed_loop_MPC_M->rtwLogInfo,
        0.0,
        rtmGetTFinal(Closed_loop_MPC_M),
        Closed_loop_MPC_M->Timing.stepSize0,
        (&rtmGetErrorStatus(Closed_loop_MPC_M)),
        "umpc",
        SS_DOUBLE,
        0,
        0,
        0,
        1,
        1,
        dimensions,
        NO_LOGVALDIMS,
        (NULL),
        (NULL),
        0,
        1,
        0.001953125,
        1);
      if (Closed_loop_MPC_DW.ToWorkspace3_PWORK.LoggedData == (NULL))
        return;
    }

    /* Start for RateTransition: '<Root>/u' */
    Closed_loop_MPC_B.u_l = Closed_loop_MPC_P.u_InitialCondition;

    /* Start for ToWorkspace: '<Root>/To Workspace4' */
    {
      int_T dimensions[1] = { 1 };

      Closed_loop_MPC_DW.ToWorkspace4_PWORK.LoggedData = rt_CreateLogVar(
        Closed_loop_MPC_M->rtwLogInfo,
        0.0,
        rtmGetTFinal(Closed_loop_MPC_M),
        Closed_loop_MPC_M->Timing.stepSize0,
        (&rtmGetErrorStatus(Closed_loop_MPC_M)),
        "utot",
        SS_DOUBLE,
        0,
        0,
        0,
        1,
        1,
        dimensions,
        NO_LOGVALDIMS,
        (NULL),
        (NULL),
        0,
        1,
        0.000244140625,
        1);
      if (Closed_loop_MPC_DW.ToWorkspace4_PWORK.LoggedData == (NULL))
        return;
    }

    /* Start for ToWorkspace: '<Root>/To Workspace5' */
    {
      int_T dimensions[1] = { 1 };

      Closed_loop_MPC_DW.ToWorkspace5_PWORK.LoggedData = rt_CreateLogVar(
        Closed_loop_MPC_M->rtwLogInfo,
        0.0,
        rtmGetTFinal(Closed_loop_MPC_M),
        Closed_loop_MPC_M->Timing.stepSize0,
        (&rtmGetErrorStatus(Closed_loop_MPC_M)),
        "yfb_sinspec",
        SS_DOUBLE,
        0,
        0,
        0,
        1,
        1,
        dimensions,
        NO_LOGVALDIMS,
        (NULL),
        (NULL),
        0,
        1,
        0.001953125,
        1);
      if (Closed_loop_MPC_DW.ToWorkspace5_PWORK.LoggedData == (NULL))
        return;
    }

    /* Start for Scope: '<Root>/input_sensor' */
    {
      int_T numCols = 6;
      Closed_loop_MPC_DW.input_sensor_PWORK.LoggedData = rt_CreateLogVar(
        Closed_loop_MPC_M->rtwLogInfo,
        0.0,
        rtmGetTFinal(Closed_loop_MPC_M),
        Closed_loop_MPC_M->Timing.stepSize0,
        (&rtmGetErrorStatus(Closed_loop_MPC_M)),
        "input_sensor",
        SS_DOUBLE,
        0,
        0,
        0,
        6,
        1,
        (int_T *)&numCols,
        NO_LOGVALDIMS,
        (NULL),
        (NULL),
        0,
        1,
        0.000244140625,
        1);
      if (Closed_loop_MPC_DW.input_sensor_PWORK.LoggedData == (NULL))
        return;
    }

    /* Start for Scope: '<Root>/output_sensor' */
    {
      int_T numCols = 6;
      Closed_loop_MPC_DW.output_sensor_PWORK.LoggedData = rt_CreateLogVar(
        Closed_loop_MPC_M->rtwLogInfo,
        0.0,
        rtmGetTFinal(Closed_loop_MPC_M),
        Closed_loop_MPC_M->Timing.stepSize0,
        (&rtmGetErrorStatus(Closed_loop_MPC_M)),
        "output_sensor",
        SS_DOUBLE,
        0,
        0,
        0,
        6,
        1,
        (int_T *)&numCols,
        NO_LOGVALDIMS,
        (NULL),
        (NULL),
        0,
        1,
        0.000244140625,
        1);
      if (Closed_loop_MPC_DW.output_sensor_PWORK.LoggedData == (NULL))
        return;
    }

    /* Start for Scope: '<Root>/y' */
    {
      int_T numCols = 2;
      Closed_loop_MPC_DW.y_PWORK.LoggedData = rt_CreateLogVar(
        Closed_loop_MPC_M->rtwLogInfo,
        0.0,
        rtmGetTFinal(Closed_loop_MPC_M),
        Closed_loop_MPC_M->Timing.stepSize0,
        (&rtmGetErrorStatus(Closed_loop_MPC_M)),
        "y",
        SS_DOUBLE,
        0,
        0,
        0,
        2,
        1,
        (int_T *)&numCols,
        NO_LOGVALDIMS,
        (NULL),
        (NULL),
        0,
        1,
        0.000244140625,
        1);
      if (Closed_loop_MPC_DW.y_PWORK.LoggedData == (NULL))
        return;
    }

    /* Start for FromWorkspace: '<Root>/From Workspace1' */
    {
      static real_T pTimeValues0[] = { 0.0, 0.009765625, 0.01953125, 0.029296875,
        0.0390625, 0.048828125, 0.05859375, 0.068359375, 0.078125, 0.087890625,
        0.09765625, 0.107421875, 0.1171875, 0.126953125, 0.13671875, 0.146484375,
        0.15625, 0.166015625, 0.17578125, 0.185546875, 0.1953125, 0.205078125,
        0.21484375, 0.224609375, 0.234375, 0.244140625, 0.25390625, 0.263671875,
        0.2734375, 0.283203125, 0.29296875, 0.302734375, 0.3125, 0.322265625,
        0.33203125, 0.341796875, 0.3515625, 0.361328125, 0.37109375, 0.380859375,
        0.390625, 0.400390625, 0.41015625, 0.419921875, 0.4296875, 0.439453125,
        0.44921875, 0.458984375, 0.46875, 0.478515625, 0.48828125, 0.498046875,
        0.5078125, 0.517578125, 0.52734375, 0.537109375, 0.546875, 0.556640625,
        0.56640625, 0.576171875, 0.5859375, 0.595703125, 0.60546875, 0.615234375,
        0.625, 0.634765625, 0.64453125, 0.654296875, 0.6640625, 0.673828125,
        0.68359375, 0.693359375, 0.703125, 0.712890625, 0.72265625, 0.732421875,
        0.7421875, 0.751953125, 0.76171875, 0.771484375, 0.78125, 0.791015625,
        0.80078125, 0.810546875, 0.8203125, 0.830078125, 0.83984375, 0.849609375,
        0.859375, 0.869140625, 0.87890625, 0.888671875, 0.8984375, 0.908203125,
        0.91796875, 0.927734375, 0.9375, 0.947265625, 0.95703125, 0.966796875,
        0.9765625, 0.986328125, 0.99609375, 1.005859375, 1.015625, 1.025390625,
        1.03515625, 1.044921875, 1.0546875, 1.064453125, 1.07421875, 1.083984375,
        1.09375, 1.103515625, 1.11328125, 1.123046875, 1.1328125, 1.142578125,
        1.15234375, 1.162109375, 1.171875, 1.181640625, 1.19140625, 1.201171875,
        1.2109375, 1.220703125, 1.23046875, 1.240234375, 1.25, 1.259765625,
        1.26953125, 1.279296875, 1.2890625, 1.298828125, 1.30859375, 1.318359375,
        1.328125, 1.337890625, 1.34765625, 1.357421875, 1.3671875, 1.376953125,
        1.38671875, 1.396484375, 1.40625, 1.416015625, 1.42578125, 1.435546875,
        1.4453125, 1.455078125, 1.46484375, 1.474609375, 1.484375, 1.494140625,
        1.50390625, 1.513671875, 1.5234375, 1.533203125, 1.54296875, 1.552734375,
        1.5625, 1.572265625, 1.58203125, 1.591796875, 1.6015625, 1.611328125,
        1.62109375, 1.630859375, 1.640625, 1.650390625, 1.66015625, 1.669921875,
        1.6796875, 1.689453125, 1.69921875, 1.708984375, 1.71875, 1.728515625,
        1.73828125, 1.748046875, 1.7578125, 1.767578125, 1.77734375, 1.787109375,
        1.796875, 1.806640625, 1.81640625, 1.826171875, 1.8359375, 1.845703125,
        1.85546875, 1.865234375, 1.875, 1.884765625, 1.89453125, 1.904296875,
        1.9140625, 1.923828125, 1.93359375, 1.943359375, 1.953125, 1.962890625,
        1.97265625, 1.982421875, 1.9921875, 2.001953125, 2.01171875, 2.021484375,
        2.03125, 2.041015625, 2.05078125, 2.060546875, 2.0703125, 2.080078125,
        2.08984375, 2.099609375, 2.109375, 2.119140625, 2.12890625, 2.138671875,
        2.1484375, 2.158203125, 2.16796875, 2.177734375, 2.1875, 2.197265625,
        2.20703125, 2.216796875, 2.2265625, 2.236328125, 2.24609375, 2.255859375,
        2.265625, 2.275390625, 2.28515625, 2.294921875, 2.3046875, 2.314453125,
        2.32421875, 2.333984375, 2.34375, 2.353515625, 2.36328125, 2.373046875,
        2.3828125, 2.392578125, 2.40234375, 2.412109375, 2.421875, 2.431640625,
        2.44140625, 2.451171875, 2.4609375, 2.470703125, 2.48046875, 2.490234375,
        2.5, 2.509765625, 2.51953125, 2.529296875, 2.5390625, 2.548828125,
        2.55859375, 2.568359375, 2.578125, 2.587890625, 2.59765625, 2.607421875,
        2.6171875, 2.626953125, 2.63671875, 2.646484375, 2.65625, 2.666015625,
        2.67578125, 2.685546875, 2.6953125, 2.705078125, 2.71484375, 2.724609375,
        2.734375, 2.744140625, 2.75390625, 2.763671875, 2.7734375, 2.783203125,
        2.79296875, 2.802734375, 2.8125, 2.822265625, 2.83203125, 2.841796875,
        2.8515625, 2.861328125, 2.87109375, 2.880859375, 2.890625, 2.900390625,
        2.91015625, 2.919921875, 2.9296875, 2.939453125, 2.94921875, 2.958984375,
        2.96875, 2.978515625, 2.98828125, 2.998046875, 3.0078125, 3.017578125,
        3.02734375, 3.037109375, 3.046875, 3.056640625, 3.06640625, 3.076171875,
        3.0859375, 3.095703125, 3.10546875, 3.115234375, 3.125, 3.134765625,
        3.14453125, 3.154296875, 3.1640625, 3.173828125, 3.18359375, 3.193359375,
        3.203125, 3.212890625, 3.22265625, 3.232421875, 3.2421875, 3.251953125,
        3.26171875, 3.271484375, 3.28125, 3.291015625, 3.30078125, 3.310546875,
        3.3203125, 3.330078125, 3.33984375, 3.349609375, 3.359375, 3.369140625,
        3.37890625, 3.388671875, 3.3984375, 3.408203125, 3.41796875, 3.427734375,
        3.4375, 3.447265625, 3.45703125, 3.466796875, 3.4765625, 3.486328125,
        3.49609375, 3.505859375, 3.515625, 3.525390625, 3.53515625, 3.544921875,
        3.5546875, 3.564453125, 3.57421875, 3.583984375, 3.59375, 3.603515625,
        3.61328125, 3.623046875, 3.6328125, 3.642578125, 3.65234375, 3.662109375,
        3.671875, 3.681640625, 3.69140625, 3.701171875, 3.7109375, 3.720703125,
        3.73046875, 3.740234375, 3.75, 3.759765625, 3.76953125, 3.779296875,
        3.7890625, 3.798828125, 3.80859375, 3.818359375, 3.828125, 3.837890625,
        3.84765625, 3.857421875, 3.8671875, 3.876953125, 3.88671875, 3.896484375,
        3.90625, 3.916015625, 3.92578125, 3.935546875, 3.9453125, 3.955078125,
        3.96484375, 3.974609375, 3.984375, 3.994140625, 4.00390625, 4.013671875,
        4.0234375, 4.033203125, 4.04296875, 4.052734375, 4.0625, 4.072265625,
        4.08203125, 4.091796875, 4.1015625, 4.111328125, 4.12109375, 4.130859375,
        4.140625, 4.150390625, 4.16015625, 4.169921875, 4.1796875, 4.189453125,
        4.19921875, 4.208984375, 4.21875, 4.228515625, 4.23828125, 4.248046875,
        4.2578125, 4.267578125, 4.27734375, 4.287109375, 4.296875, 4.306640625,
        4.31640625, 4.326171875, 4.3359375, 4.345703125, 4.35546875, 4.365234375,
        4.375, 4.384765625, 4.39453125, 4.404296875, 4.4140625, 4.423828125,
        4.43359375, 4.443359375, 4.453125, 4.462890625, 4.47265625, 4.482421875,
        4.4921875, 4.501953125, 4.51171875, 4.521484375, 4.53125, 4.541015625,
        4.55078125, 4.560546875, 4.5703125, 4.580078125, 4.58984375, 4.599609375,
        4.609375, 4.619140625, 4.62890625, 4.638671875, 4.6484375, 4.658203125,
        4.66796875, 4.677734375, 4.6875, 4.697265625, 4.70703125, 4.716796875,
        4.7265625, 4.736328125, 4.74609375, 4.755859375, 4.765625, 4.775390625,
        4.78515625, 4.794921875, 4.8046875, 4.814453125, 4.82421875, 4.833984375,
        4.84375, 4.853515625, 4.86328125, 4.873046875, 4.8828125, 4.892578125,
        4.90234375, 4.912109375, 4.921875, 4.931640625, 4.94140625, 4.951171875,
        4.9609375, 4.970703125, 4.98046875, 4.990234375, 5.0, 5.009765625,
        5.01953125, 5.029296875, 5.0390625, 5.048828125, 5.05859375, 5.068359375,
        5.078125, 5.087890625, 5.09765625, 5.107421875, 5.1171875, 5.126953125,
        5.13671875, 5.146484375, 5.15625, 5.166015625, 5.17578125, 5.185546875,
        5.1953125, 5.205078125, 5.21484375, 5.224609375, 5.234375, 5.244140625,
        5.25390625, 5.263671875, 5.2734375, 5.283203125, 5.29296875, 5.302734375,
        5.3125, 5.322265625, 5.33203125, 5.341796875, 5.3515625, 5.361328125,
        5.37109375, 5.380859375, 5.390625, 5.400390625, 5.41015625, 5.419921875,
        5.4296875, 5.439453125, 5.44921875, 5.458984375, 5.46875, 5.478515625,
        5.48828125, 5.498046875, 5.5078125, 5.517578125, 5.52734375, 5.537109375,
        5.546875, 5.556640625, 5.56640625, 5.576171875, 5.5859375, 5.595703125,
        5.60546875, 5.615234375, 5.625, 5.634765625, 5.64453125, 5.654296875,
        5.6640625, 5.673828125, 5.68359375, 5.693359375, 5.703125, 5.712890625,
        5.72265625, 5.732421875, 5.7421875, 5.751953125, 5.76171875, 5.771484375,
        5.78125, 5.791015625, 5.80078125, 5.810546875, 5.8203125, 5.830078125,
        5.83984375, 5.849609375, 5.859375, 5.869140625, 5.87890625, 5.888671875,
        5.8984375, 5.908203125, 5.91796875, 5.927734375, 5.9375, 5.947265625,
        5.95703125, 5.966796875, 5.9765625, 5.986328125, 5.99609375, 6.005859375,
        6.015625, 6.025390625, 6.03515625, 6.044921875, 6.0546875, 6.064453125,
        6.07421875, 6.083984375, 6.09375, 6.103515625, 6.11328125, 6.123046875,
        6.1328125, 6.142578125, 6.15234375, 6.162109375, 6.171875, 6.181640625,
        6.19140625, 6.201171875, 6.2109375, 6.220703125, 6.23046875, 6.240234375,
        6.25, 6.259765625, 6.26953125, 6.279296875, 6.2890625, 6.298828125,
        6.30859375, 6.318359375, 6.328125, 6.337890625, 6.34765625, 6.357421875,
        6.3671875, 6.376953125, 6.38671875, 6.396484375, 6.40625, 6.416015625,
        6.42578125, 6.435546875, 6.4453125, 6.455078125, 6.46484375, 6.474609375,
        6.484375, 6.494140625, 6.50390625, 6.513671875, 6.5234375, 6.533203125,
        6.54296875, 6.552734375, 6.5625, 6.572265625, 6.58203125, 6.591796875,
        6.6015625, 6.611328125, 6.62109375, 6.630859375, 6.640625, 6.650390625,
        6.66015625, 6.669921875, 6.6796875, 6.689453125, 6.69921875, 6.708984375,
        6.71875, 6.728515625, 6.73828125, 6.748046875, 6.7578125, 6.767578125,
        6.77734375, 6.787109375, 6.796875, 6.806640625, 6.81640625, 6.826171875,
        6.8359375, 6.845703125, 6.85546875, 6.865234375, 6.875, 6.884765625,
        6.89453125, 6.904296875, 6.9140625, 6.923828125, 6.93359375, 6.943359375,
        6.953125, 6.962890625, 6.97265625, 6.982421875, 6.9921875, 7.001953125,
        7.01171875, 7.021484375, 7.03125, 7.041015625, 7.05078125, 7.060546875,
        7.0703125, 7.080078125, 7.08984375, 7.099609375, 7.109375, 7.119140625,
        7.12890625, 7.138671875, 7.1484375, 7.158203125, 7.16796875, 7.177734375,
        7.1875, 7.197265625, 7.20703125, 7.216796875, 7.2265625, 7.236328125,
        7.24609375, 7.255859375, 7.265625, 7.275390625, 7.28515625, 7.294921875,
        7.3046875, 7.314453125, 7.32421875, 7.333984375, 7.34375, 7.353515625,
        7.36328125, 7.373046875, 7.3828125, 7.392578125, 7.40234375, 7.412109375,
        7.421875, 7.431640625, 7.44140625, 7.451171875, 7.4609375, 7.470703125,
        7.48046875, 7.490234375, 7.5, 7.509765625, 7.51953125, 7.529296875,
        7.5390625, 7.548828125, 7.55859375, 7.568359375, 7.578125, 7.587890625,
        7.59765625, 7.607421875, 7.6171875, 7.626953125, 7.63671875, 7.646484375,
        7.65625, 7.666015625, 7.67578125, 7.685546875, 7.6953125, 7.705078125,
        7.71484375, 7.724609375, 7.734375, 7.744140625, 7.75390625, 7.763671875,
        7.7734375, 7.783203125, 7.79296875, 7.802734375, 7.8125, 7.822265625,
        7.83203125, 7.841796875, 7.8515625, 7.861328125, 7.87109375, 7.880859375,
        7.890625, 7.900390625, 7.91015625, 7.919921875, 7.9296875, 7.939453125,
        7.94921875, 7.958984375, 7.96875, 7.978515625, 7.98828125, 7.998046875,
        8.0078125, 8.017578125, 8.02734375, 8.037109375, 8.046875, 8.056640625,
        8.06640625, 8.076171875, 8.0859375, 8.095703125, 8.10546875, 8.115234375,
        8.125, 8.134765625, 8.14453125, 8.154296875, 8.1640625, 8.173828125,
        8.18359375, 8.193359375, 8.203125, 8.212890625, 8.22265625, 8.232421875,
        8.2421875, 8.251953125, 8.26171875, 8.271484375, 8.28125, 8.291015625,
        8.30078125, 8.310546875, 8.3203125, 8.330078125, 8.33984375, 8.349609375,
        8.359375, 8.369140625, 8.37890625, 8.388671875, 8.3984375, 8.408203125,
        8.41796875, 8.427734375, 8.4375, 8.447265625, 8.45703125, 8.466796875,
        8.4765625, 8.486328125, 8.49609375, 8.505859375, 8.515625, 8.525390625,
        8.53515625, 8.544921875, 8.5546875, 8.564453125, 8.57421875, 8.583984375,
        8.59375, 8.603515625, 8.61328125, 8.623046875, 8.6328125, 8.642578125,
        8.65234375, 8.662109375, 8.671875, 8.681640625, 8.69140625, 8.701171875,
        8.7109375, 8.720703125, 8.73046875, 8.740234375, 8.75, 8.759765625,
        8.76953125, 8.779296875, 8.7890625, 8.798828125, 8.80859375, 8.818359375,
        8.828125, 8.837890625, 8.84765625, 8.857421875, 8.8671875, 8.876953125,
        8.88671875, 8.896484375, 8.90625, 8.916015625, 8.92578125, 8.935546875,
        8.9453125, 8.955078125, 8.96484375, 8.974609375, 8.984375, 8.994140625,
        9.00390625, 9.013671875, 9.0234375, 9.033203125, 9.04296875, 9.052734375,
        9.0625, 9.072265625, 9.08203125, 9.091796875, 9.1015625, 9.111328125,
        9.12109375, 9.130859375, 9.140625, 9.150390625, 9.16015625, 9.169921875,
        9.1796875, 9.189453125, 9.19921875, 9.208984375, 9.21875, 9.228515625,
        9.23828125, 9.248046875, 9.2578125, 9.267578125, 9.27734375, 9.287109375,
        9.296875, 9.306640625, 9.31640625, 9.326171875, 9.3359375, 9.345703125,
        9.35546875, 9.365234375, 9.375, 9.384765625, 9.39453125, 9.404296875,
        9.4140625, 9.423828125, 9.43359375, 9.443359375, 9.453125, 9.462890625,
        9.47265625, 9.482421875, 9.4921875, 9.501953125, 9.51171875, 9.521484375,
        9.53125, 9.541015625, 9.55078125, 9.560546875, 9.5703125, 9.580078125,
        9.58984375, 9.599609375, 9.609375, 9.619140625, 9.62890625, 9.638671875,
        9.6484375, 9.658203125, 9.66796875, 9.677734375, 9.6875, 9.697265625,
        9.70703125, 9.716796875, 9.7265625, 9.736328125, 9.74609375, 9.755859375,
        9.765625, 9.775390625, 9.78515625, 9.794921875, 9.8046875, 9.814453125,
        9.82421875, 9.833984375, 9.84375, 9.853515625, 9.86328125, 9.873046875,
        9.8828125, 9.892578125, 9.90234375, 9.912109375, 9.921875, 9.931640625,
        9.94140625, 9.951171875, 9.9609375, 9.970703125, 9.98046875, 9.990234375,
        10.0, 10.009765625, 10.01953125, 10.029296875, 10.0390625, 10.048828125,
        10.05859375, 10.068359375, 10.078125, 10.087890625, 10.09765625,
        10.107421875, 10.1171875, 10.126953125, 10.13671875, 10.146484375,
        10.15625, 10.166015625, 10.17578125, 10.185546875, 10.1953125,
        10.205078125, 10.21484375, 10.224609375, 10.234375, 10.244140625,
        10.25390625, 10.263671875, 10.2734375, 10.283203125, 10.29296875,
        10.302734375, 10.3125, 10.322265625, 10.33203125, 10.341796875,
        10.3515625, 10.361328125, 10.37109375, 10.380859375, 10.390625,
        10.400390625, 10.41015625, 10.419921875, 10.4296875, 10.439453125,
        10.44921875, 10.458984375, 10.46875, 10.478515625, 10.48828125,
        10.498046875, 10.5078125, 10.517578125, 10.52734375, 10.537109375,
        10.546875, 10.556640625, 10.56640625, 10.576171875, 10.5859375,
        10.595703125, 10.60546875, 10.615234375, 10.625, 10.634765625,
        10.64453125, 10.654296875, 10.6640625, 10.673828125, 10.68359375,
        10.693359375, 10.703125, 10.712890625, 10.72265625, 10.732421875,
        10.7421875, 10.751953125, 10.76171875, 10.771484375, 10.78125,
        10.791015625, 10.80078125, 10.810546875, 10.8203125, 10.830078125,
        10.83984375, 10.849609375, 10.859375, 10.869140625, 10.87890625,
        10.888671875, 10.8984375, 10.908203125, 10.91796875, 10.927734375,
        10.9375, 10.947265625, 10.95703125, 10.966796875, 10.9765625,
        10.986328125, 10.99609375, 11.005859375, 11.015625, 11.025390625,
        11.03515625, 11.044921875, 11.0546875, 11.064453125, 11.07421875,
        11.083984375, 11.09375, 11.103515625, 11.11328125, 11.123046875,
        11.1328125, 11.142578125, 11.15234375, 11.162109375, 11.171875,
        11.181640625, 11.19140625, 11.201171875, 11.2109375, 11.220703125,
        11.23046875, 11.240234375, 11.25, 11.259765625, 11.26953125,
        11.279296875, 11.2890625, 11.298828125, 11.30859375, 11.318359375,
        11.328125, 11.337890625, 11.34765625, 11.357421875, 11.3671875,
        11.376953125, 11.38671875, 11.396484375, 11.40625, 11.416015625,
        11.42578125, 11.435546875, 11.4453125, 11.455078125, 11.46484375,
        11.474609375, 11.484375, 11.494140625, 11.50390625, 11.513671875,
        11.5234375, 11.533203125, 11.54296875, 11.552734375, 11.5625,
        11.572265625, 11.58203125, 11.591796875, 11.6015625, 11.611328125,
        11.62109375, 11.630859375, 11.640625, 11.650390625, 11.66015625,
        11.669921875, 11.6796875, 11.689453125, 11.69921875, 11.708984375,
        11.71875, 11.728515625, 11.73828125, 11.748046875, 11.7578125,
        11.767578125, 11.77734375, 11.787109375, 11.796875, 11.806640625,
        11.81640625, 11.826171875, 11.8359375, 11.845703125, 11.85546875,
        11.865234375, 11.875, 11.884765625, 11.89453125, 11.904296875,
        11.9140625, 11.923828125, 11.93359375, 11.943359375, 11.953125,
        11.962890625, 11.97265625, 11.982421875, 11.9921875, 12.001953125,
        12.01171875, 12.021484375, 12.03125, 12.041015625, 12.05078125,
        12.060546875, 12.0703125, 12.080078125, 12.08984375, 12.099609375,
        12.109375, 12.119140625, 12.12890625, 12.138671875, 12.1484375,
        12.158203125, 12.16796875, 12.177734375, 12.1875, 12.197265625,
        12.20703125, 12.216796875, 12.2265625, 12.236328125, 12.24609375,
        12.255859375, 12.265625, 12.275390625, 12.28515625, 12.294921875,
        12.3046875, 12.314453125, 12.32421875, 12.333984375, 12.34375,
        12.353515625, 12.36328125, 12.373046875, 12.3828125, 12.392578125,
        12.40234375, 12.412109375, 12.421875, 12.431640625, 12.44140625,
        12.451171875, 12.4609375, 12.470703125, 12.48046875, 12.490234375, 12.5,
        12.509765625, 12.51953125, 12.529296875, 12.5390625, 12.548828125,
        12.55859375, 12.568359375, 12.578125, 12.587890625, 12.59765625,
        12.607421875, 12.6171875, 12.626953125, 12.63671875, 12.646484375,
        12.65625, 12.666015625, 12.67578125, 12.685546875, 12.6953125,
        12.705078125, 12.71484375, 12.724609375, 12.734375, 12.744140625,
        12.75390625, 12.763671875, 12.7734375, 12.783203125, 12.79296875,
        12.802734375, 12.8125, 12.822265625, 12.83203125, 12.841796875,
        12.8515625, 12.861328125, 12.87109375, 12.880859375, 12.890625,
        12.900390625, 12.91015625, 12.919921875, 12.9296875, 12.939453125,
        12.94921875, 12.958984375, 12.96875, 12.978515625, 12.98828125,
        12.998046875, 13.0078125, 13.017578125, 13.02734375, 13.037109375,
        13.046875, 13.056640625, 13.06640625, 13.076171875, 13.0859375,
        13.095703125, 13.10546875, 13.115234375, 13.125, 13.134765625,
        13.14453125, 13.154296875, 13.1640625, 13.173828125, 13.18359375,
        13.193359375, 13.203125, 13.212890625, 13.22265625, 13.232421875,
        13.2421875, 13.251953125, 13.26171875, 13.271484375, 13.28125,
        13.291015625, 13.30078125, 13.310546875, 13.3203125, 13.330078125,
        13.33984375, 13.349609375, 13.359375, 13.369140625, 13.37890625,
        13.388671875, 13.3984375, 13.408203125, 13.41796875, 13.427734375,
        13.4375, 13.447265625, 13.45703125, 13.466796875, 13.4765625,
        13.486328125, 13.49609375, 13.505859375, 13.515625, 13.525390625,
        13.53515625, 13.544921875, 13.5546875, 13.564453125, 13.57421875,
        13.583984375, 13.59375, 13.603515625, 13.61328125, 13.623046875,
        13.6328125, 13.642578125, 13.65234375, 13.662109375, 13.671875,
        13.681640625, 13.69140625, 13.701171875, 13.7109375, 13.720703125,
        13.73046875, 13.740234375, 13.75, 13.759765625, 13.76953125,
        13.779296875, 13.7890625, 13.798828125, 13.80859375, 13.818359375,
        13.828125, 13.837890625, 13.84765625, 13.857421875, 13.8671875,
        13.876953125, 13.88671875, 13.896484375, 13.90625, 13.916015625,
        13.92578125, 13.935546875, 13.9453125, 13.955078125, 13.96484375,
        13.974609375, 13.984375, 13.994140625, 14.00390625, 14.013671875,
        14.0234375, 14.033203125, 14.04296875, 14.052734375, 14.0625,
        14.072265625, 14.08203125, 14.091796875, 14.1015625, 14.111328125,
        14.12109375, 14.130859375, 14.140625, 14.150390625, 14.16015625,
        14.169921875, 14.1796875, 14.189453125, 14.19921875, 14.208984375,
        14.21875, 14.228515625, 14.23828125, 14.248046875, 14.2578125,
        14.267578125, 14.27734375, 14.287109375, 14.296875, 14.306640625,
        14.31640625, 14.326171875, 14.3359375, 14.345703125, 14.35546875,
        14.365234375, 14.375, 14.384765625, 14.39453125, 14.404296875,
        14.4140625, 14.423828125, 14.43359375, 14.443359375, 14.453125,
        14.462890625, 14.47265625, 14.482421875, 14.4921875, 14.501953125,
        14.51171875, 14.521484375, 14.53125, 14.541015625, 14.55078125,
        14.560546875, 14.5703125, 14.580078125, 14.58984375, 14.599609375,
        14.609375, 14.619140625, 14.62890625, 14.638671875, 14.6484375,
        14.658203125, 14.66796875, 14.677734375, 14.6875, 14.697265625,
        14.70703125, 14.716796875, 14.7265625, 14.736328125, 14.74609375,
        14.755859375, 14.765625, 14.775390625, 14.78515625, 14.794921875,
        14.8046875, 14.814453125, 14.82421875, 14.833984375, 14.84375,
        14.853515625, 14.86328125, 14.873046875, 14.8828125, 14.892578125,
        14.90234375, 14.912109375, 14.921875, 14.931640625, 14.94140625,
        14.951171875, 14.9609375, 14.970703125, 14.98046875, 14.990234375, 15.0,
        15.009765625, 15.01953125, 15.029296875, 15.0390625, 15.048828125,
        15.05859375, 15.068359375, 15.078125, 15.087890625, 15.09765625,
        15.107421875, 15.1171875, 15.126953125, 15.13671875, 15.146484375,
        15.15625, 15.166015625, 15.17578125, 15.185546875, 15.1953125,
        15.205078125, 15.21484375, 15.224609375, 15.234375, 15.244140625,
        15.25390625, 15.263671875, 15.2734375, 15.283203125, 15.29296875,
        15.302734375, 15.3125, 15.322265625, 15.33203125, 15.341796875,
        15.3515625, 15.361328125, 15.37109375, 15.380859375, 15.390625,
        15.400390625, 15.41015625, 15.419921875, 15.4296875, 15.439453125,
        15.44921875, 15.458984375, 15.46875, 15.478515625, 15.48828125,
        15.498046875, 15.5078125, 15.517578125, 15.52734375, 15.537109375,
        15.546875, 15.556640625, 15.56640625, 15.576171875, 15.5859375,
        15.595703125, 15.60546875, 15.615234375, 15.625, 15.634765625,
        15.64453125, 15.654296875, 15.6640625, 15.673828125, 15.68359375,
        15.693359375, 15.703125, 15.712890625, 15.72265625, 15.732421875,
        15.7421875, 15.751953125, 15.76171875, 15.771484375, 15.78125,
        15.791015625, 15.80078125, 15.810546875, 15.8203125, 15.830078125,
        15.83984375, 15.849609375, 15.859375, 15.869140625, 15.87890625,
        15.888671875, 15.8984375, 15.908203125, 15.91796875, 15.927734375,
        15.9375, 15.947265625, 15.95703125, 15.966796875, 15.9765625,
        15.986328125, 15.99609375, 16.005859375, 16.015625, 16.025390625,
        16.03515625, 16.044921875, 16.0546875, 16.064453125, 16.07421875,
        16.083984375, 16.09375, 16.103515625, 16.11328125, 16.123046875,
        16.1328125, 16.142578125, 16.15234375, 16.162109375, 16.171875,
        16.181640625, 16.19140625, 16.201171875, 16.2109375, 16.220703125,
        16.23046875, 16.240234375, 16.25, 16.259765625, 16.26953125,
        16.279296875, 16.2890625, 16.298828125, 16.30859375, 16.318359375,
        16.328125, 16.337890625, 16.34765625, 16.357421875, 16.3671875,
        16.376953125, 16.38671875, 16.396484375, 16.40625, 16.416015625,
        16.42578125, 16.435546875, 16.4453125, 16.455078125, 16.46484375,
        16.474609375, 16.484375, 16.494140625, 16.50390625, 16.513671875,
        16.5234375, 16.533203125, 16.54296875, 16.552734375, 16.5625,
        16.572265625, 16.58203125, 16.591796875, 16.6015625, 16.611328125,
        16.62109375, 16.630859375, 16.640625, 16.650390625, 16.66015625,
        16.669921875, 16.6796875, 16.689453125, 16.69921875, 16.708984375,
        16.71875, 16.728515625, 16.73828125, 16.748046875, 16.7578125,
        16.767578125, 16.77734375, 16.787109375, 16.796875, 16.806640625,
        16.81640625, 16.826171875, 16.8359375, 16.845703125, 16.85546875,
        16.865234375, 16.875, 16.884765625, 16.89453125, 16.904296875,
        16.9140625, 16.923828125, 16.93359375, 16.943359375, 16.953125,
        16.962890625, 16.97265625, 16.982421875, 16.9921875, 17.001953125,
        17.01171875, 17.021484375, 17.03125, 17.041015625, 17.05078125,
        17.060546875, 17.0703125, 17.080078125, 17.08984375, 17.099609375,
        17.109375, 17.119140625, 17.12890625, 17.138671875, 17.1484375,
        17.158203125, 17.16796875, 17.177734375, 17.1875, 17.197265625,
        17.20703125, 17.216796875, 17.2265625, 17.236328125, 17.24609375,
        17.255859375, 17.265625, 17.275390625, 17.28515625, 17.294921875,
        17.3046875, 17.314453125, 17.32421875, 17.333984375, 17.34375,
        17.353515625, 17.36328125, 17.373046875, 17.3828125, 17.392578125,
        17.40234375, 17.412109375, 17.421875, 17.431640625, 17.44140625,
        17.451171875, 17.4609375, 17.470703125, 17.48046875, 17.490234375, 17.5,
        17.509765625, 17.51953125, 17.529296875, 17.5390625, 17.548828125,
        17.55859375, 17.568359375, 17.578125, 17.587890625, 17.59765625,
        17.607421875, 17.6171875, 17.626953125, 17.63671875, 17.646484375,
        17.65625, 17.666015625, 17.67578125, 17.685546875, 17.6953125,
        17.705078125, 17.71484375, 17.724609375, 17.734375, 17.744140625,
        17.75390625, 17.763671875, 17.7734375, 17.783203125, 17.79296875,
        17.802734375, 17.8125, 17.822265625, 17.83203125, 17.841796875,
        17.8515625, 17.861328125, 17.87109375, 17.880859375, 17.890625,
        17.900390625, 17.91015625, 17.919921875, 17.9296875, 17.939453125,
        17.94921875, 17.958984375, 17.96875, 17.978515625, 17.98828125,
        17.998046875, 18.0078125, 18.017578125, 18.02734375, 18.037109375,
        18.046875, 18.056640625, 18.06640625, 18.076171875, 18.0859375,
        18.095703125, 18.10546875, 18.115234375, 18.125, 18.134765625,
        18.14453125, 18.154296875, 18.1640625, 18.173828125, 18.18359375,
        18.193359375, 18.203125, 18.212890625, 18.22265625, 18.232421875,
        18.2421875, 18.251953125, 18.26171875, 18.271484375, 18.28125,
        18.291015625, 18.30078125, 18.310546875, 18.3203125, 18.330078125,
        18.33984375, 18.349609375, 18.359375, 18.369140625, 18.37890625,
        18.388671875, 18.3984375, 18.408203125, 18.41796875, 18.427734375,
        18.4375, 18.447265625, 18.45703125, 18.466796875, 18.4765625,
        18.486328125, 18.49609375, 18.505859375, 18.515625, 18.525390625,
        18.53515625, 18.544921875, 18.5546875, 18.564453125, 18.57421875,
        18.583984375, 18.59375, 18.603515625, 18.61328125, 18.623046875,
        18.6328125, 18.642578125, 18.65234375, 18.662109375, 18.671875,
        18.681640625, 18.69140625, 18.701171875, 18.7109375, 18.720703125,
        18.73046875, 18.740234375, 18.75, 18.759765625, 18.76953125,
        18.779296875, 18.7890625, 18.798828125, 18.80859375, 18.818359375,
        18.828125, 18.837890625, 18.84765625, 18.857421875, 18.8671875,
        18.876953125, 18.88671875, 18.896484375, 18.90625, 18.916015625,
        18.92578125, 18.935546875, 18.9453125, 18.955078125, 18.96484375,
        18.974609375, 18.984375, 18.994140625, 19.00390625, 19.013671875,
        19.0234375, 19.033203125, 19.04296875, 19.052734375, 19.0625,
        19.072265625, 19.08203125, 19.091796875, 19.1015625, 19.111328125,
        19.12109375, 19.130859375, 19.140625, 19.150390625, 19.16015625,
        19.169921875, 19.1796875, 19.189453125, 19.19921875, 19.208984375,
        19.21875, 19.228515625, 19.23828125, 19.248046875, 19.2578125,
        19.267578125, 19.27734375, 19.287109375, 19.296875, 19.306640625,
        19.31640625, 19.326171875, 19.3359375, 19.345703125, 19.35546875,
        19.365234375, 19.375, 19.384765625, 19.39453125, 19.404296875,
        19.4140625, 19.423828125, 19.43359375, 19.443359375, 19.453125,
        19.462890625, 19.47265625, 19.482421875, 19.4921875, 19.501953125,
        19.51171875, 19.521484375, 19.53125, 19.541015625, 19.55078125,
        19.560546875, 19.5703125, 19.580078125, 19.58984375, 19.599609375,
        19.609375, 19.619140625, 19.62890625, 19.638671875, 19.6484375,
        19.658203125, 19.66796875, 19.677734375, 19.6875, 19.697265625,
        19.70703125, 19.716796875, 19.7265625, 19.736328125, 19.74609375,
        19.755859375, 19.765625, 19.775390625, 19.78515625, 19.794921875,
        19.8046875, 19.814453125, 19.82421875, 19.833984375, 19.84375,
        19.853515625, 19.86328125, 19.873046875, 19.8828125, 19.892578125,
        19.90234375, 19.912109375, 19.921875, 19.931640625, 19.94140625,
        19.951171875, 19.9609375, 19.970703125, 19.98046875, 19.990234375, 20.0,
        20.009765625, 20.01953125, 20.029296875, 20.0390625, 20.048828125,
        20.05859375, 20.068359375, 20.078125, 20.087890625, 20.09765625,
        20.107421875, 20.1171875, 20.126953125, 20.13671875, 20.146484375,
        20.15625, 20.166015625, 20.17578125, 20.185546875, 20.1953125,
        20.205078125, 20.21484375, 20.224609375, 20.234375, 20.244140625,
        20.25390625, 20.263671875, 20.2734375, 20.283203125, 20.29296875,
        20.302734375, 20.3125, 20.322265625, 20.33203125, 20.341796875,
        20.3515625, 20.361328125, 20.37109375, 20.380859375, 20.390625,
        20.400390625, 20.41015625, 20.419921875, 20.4296875, 20.439453125,
        20.44921875, 20.458984375, 20.46875, 20.478515625, 20.48828125,
        20.498046875, 20.5078125, 20.517578125, 20.52734375, 20.537109375,
        20.546875, 20.556640625, 20.56640625, 20.576171875, 20.5859375,
        20.595703125, 20.60546875, 20.615234375, 20.625, 20.634765625,
        20.64453125, 20.654296875, 20.6640625, 20.673828125, 20.68359375,
        20.693359375, 20.703125, 20.712890625, 20.72265625, 20.732421875,
        20.7421875, 20.751953125, 20.76171875, 20.771484375, 20.78125,
        20.791015625, 20.80078125, 20.810546875, 20.8203125, 20.830078125,
        20.83984375, 20.849609375, 20.859375, 20.869140625, 20.87890625,
        20.888671875, 20.8984375, 20.908203125, 20.91796875, 20.927734375,
        20.9375, 20.947265625, 20.95703125, 20.966796875, 20.9765625,
        20.986328125, 20.99609375, 21.005859375, 21.015625, 21.025390625,
        21.03515625, 21.044921875, 21.0546875, 21.064453125, 21.07421875,
        21.083984375, 21.09375, 21.103515625, 21.11328125, 21.123046875,
        21.1328125, 21.142578125, 21.15234375, 21.162109375, 21.171875,
        21.181640625, 21.19140625, 21.201171875, 21.2109375, 21.220703125,
        21.23046875, 21.240234375, 21.25, 21.259765625, 21.26953125,
        21.279296875, 21.2890625, 21.298828125, 21.30859375, 21.318359375,
        21.328125, 21.337890625, 21.34765625, 21.357421875, 21.3671875,
        21.376953125, 21.38671875, 21.396484375, 21.40625, 21.416015625,
        21.42578125, 21.435546875, 21.4453125, 21.455078125, 21.46484375,
        21.474609375, 21.484375, 21.494140625, 21.50390625, 21.513671875,
        21.5234375, 21.533203125, 21.54296875, 21.552734375, 21.5625,
        21.572265625, 21.58203125, 21.591796875, 21.6015625, 21.611328125,
        21.62109375, 21.630859375, 21.640625, 21.650390625, 21.66015625,
        21.669921875, 21.6796875, 21.689453125, 21.69921875, 21.708984375,
        21.71875, 21.728515625, 21.73828125, 21.748046875, 21.7578125,
        21.767578125, 21.77734375, 21.787109375, 21.796875, 21.806640625,
        21.81640625, 21.826171875, 21.8359375, 21.845703125, 21.85546875,
        21.865234375, 21.875, 21.884765625, 21.89453125, 21.904296875,
        21.9140625, 21.923828125, 21.93359375, 21.943359375, 21.953125,
        21.962890625, 21.97265625, 21.982421875, 21.9921875, 22.001953125,
        22.01171875, 22.021484375, 22.03125, 22.041015625, 22.05078125,
        22.060546875, 22.0703125, 22.080078125, 22.08984375, 22.099609375,
        22.109375, 22.119140625, 22.12890625, 22.138671875, 22.1484375,
        22.158203125, 22.16796875, 22.177734375, 22.1875, 22.197265625,
        22.20703125, 22.216796875, 22.2265625, 22.236328125, 22.24609375,
        22.255859375, 22.265625, 22.275390625, 22.28515625, 22.294921875,
        22.3046875, 22.314453125, 22.32421875, 22.333984375, 22.34375,
        22.353515625, 22.36328125, 22.373046875, 22.3828125, 22.392578125,
        22.40234375, 22.412109375, 22.421875, 22.431640625, 22.44140625,
        22.451171875, 22.4609375, 22.470703125, 22.48046875, 22.490234375, 22.5,
        22.509765625, 22.51953125, 22.529296875, 22.5390625, 22.548828125,
        22.55859375, 22.568359375, 22.578125, 22.587890625, 22.59765625,
        22.607421875, 22.6171875, 22.626953125, 22.63671875, 22.646484375,
        22.65625, 22.666015625, 22.67578125, 22.685546875, 22.6953125,
        22.705078125, 22.71484375, 22.724609375, 22.734375, 22.744140625,
        22.75390625, 22.763671875, 22.7734375, 22.783203125, 22.79296875,
        22.802734375, 22.8125, 22.822265625, 22.83203125, 22.841796875,
        22.8515625, 22.861328125, 22.87109375, 22.880859375, 22.890625,
        22.900390625, 22.91015625, 22.919921875, 22.9296875, 22.939453125,
        22.94921875, 22.958984375, 22.96875, 22.978515625, 22.98828125,
        22.998046875, 23.0078125, 23.017578125, 23.02734375, 23.037109375,
        23.046875, 23.056640625, 23.06640625, 23.076171875, 23.0859375,
        23.095703125, 23.10546875, 23.115234375, 23.125, 23.134765625,
        23.14453125, 23.154296875, 23.1640625, 23.173828125, 23.18359375,
        23.193359375, 23.203125, 23.212890625, 23.22265625, 23.232421875,
        23.2421875, 23.251953125, 23.26171875, 23.271484375, 23.28125,
        23.291015625, 23.30078125, 23.310546875, 23.3203125, 23.330078125,
        23.33984375, 23.349609375, 23.359375, 23.369140625, 23.37890625,
        23.388671875, 23.3984375, 23.408203125, 23.41796875, 23.427734375,
        23.4375, 23.447265625, 23.45703125, 23.466796875, 23.4765625,
        23.486328125, 23.49609375, 23.505859375, 23.515625, 23.525390625,
        23.53515625, 23.544921875, 23.5546875, 23.564453125, 23.57421875,
        23.583984375, 23.59375, 23.603515625, 23.61328125, 23.623046875,
        23.6328125, 23.642578125, 23.65234375, 23.662109375, 23.671875,
        23.681640625, 23.69140625, 23.701171875, 23.7109375, 23.720703125,
        23.73046875, 23.740234375, 23.75, 23.759765625, 23.76953125,
        23.779296875, 23.7890625, 23.798828125, 23.80859375, 23.818359375,
        23.828125, 23.837890625, 23.84765625, 23.857421875, 23.8671875,
        23.876953125, 23.88671875, 23.896484375, 23.90625, 23.916015625,
        23.92578125, 23.935546875, 23.9453125, 23.955078125, 23.96484375,
        23.974609375, 23.984375, 23.994140625, 24.00390625, 24.013671875,
        24.0234375, 24.033203125, 24.04296875, 24.052734375, 24.0625,
        24.072265625, 24.08203125, 24.091796875, 24.1015625, 24.111328125,
        24.12109375, 24.130859375, 24.140625, 24.150390625, 24.16015625,
        24.169921875, 24.1796875, 24.189453125, 24.19921875, 24.208984375,
        24.21875, 24.228515625, 24.23828125, 24.248046875, 24.2578125,
        24.267578125, 24.27734375, 24.287109375, 24.296875, 24.306640625,
        24.31640625, 24.326171875, 24.3359375, 24.345703125, 24.35546875,
        24.365234375, 24.375, 24.384765625, 24.39453125, 24.404296875,
        24.4140625, 24.423828125, 24.43359375, 24.443359375, 24.453125,
        24.462890625, 24.47265625, 24.482421875, 24.4921875, 24.501953125,
        24.51171875, 24.521484375, 24.53125, 24.541015625, 24.55078125,
        24.560546875, 24.5703125, 24.580078125, 24.58984375, 24.599609375,
        24.609375, 24.619140625, 24.62890625, 24.638671875, 24.6484375,
        24.658203125, 24.66796875, 24.677734375, 24.6875, 24.697265625,
        24.70703125, 24.716796875, 24.7265625, 24.736328125, 24.74609375,
        24.755859375, 24.765625, 24.775390625, 24.78515625, 24.794921875,
        24.8046875, 24.814453125, 24.82421875, 24.833984375, 24.84375,
        24.853515625, 24.86328125, 24.873046875, 24.8828125, 24.892578125,
        24.90234375, 24.912109375, 24.921875, 24.931640625, 24.94140625,
        24.951171875, 24.9609375, 24.970703125, 24.98046875, 24.990234375, 25.0,
        25.009765625, 25.01953125, 25.029296875, 25.0390625, 25.048828125,
        25.05859375, 25.068359375, 25.078125, 25.087890625, 25.09765625,
        25.107421875, 25.1171875, 25.126953125, 25.13671875, 25.146484375,
        25.15625, 25.166015625, 25.17578125, 25.185546875, 25.1953125,
        25.205078125, 25.21484375, 25.224609375, 25.234375, 25.244140625,
        25.25390625, 25.263671875, 25.2734375, 25.283203125, 25.29296875,
        25.302734375, 25.3125, 25.322265625, 25.33203125, 25.341796875,
        25.3515625, 25.361328125, 25.37109375, 25.380859375, 25.390625,
        25.400390625, 25.41015625, 25.419921875, 25.4296875, 25.439453125,
        25.44921875, 25.458984375, 25.46875, 25.478515625, 25.48828125,
        25.498046875, 25.5078125, 25.517578125, 25.52734375, 25.537109375,
        25.546875, 25.556640625, 25.56640625, 25.576171875, 25.5859375,
        25.595703125, 25.60546875, 25.615234375, 25.625, 25.634765625,
        25.64453125, 25.654296875, 25.6640625, 25.673828125, 25.68359375,
        25.693359375, 25.703125, 25.712890625, 25.72265625, 25.732421875,
        25.7421875, 25.751953125, 25.76171875, 25.771484375, 25.78125,
        25.791015625, 25.80078125, 25.810546875, 25.8203125, 25.830078125,
        25.83984375, 25.849609375, 25.859375, 25.869140625, 25.87890625,
        25.888671875, 25.8984375, 25.908203125, 25.91796875, 25.927734375,
        25.9375, 25.947265625, 25.95703125, 25.966796875, 25.9765625,
        25.986328125, 25.99609375, 26.005859375, 26.015625, 26.025390625,
        26.03515625, 26.044921875, 26.0546875, 26.064453125, 26.07421875,
        26.083984375, 26.09375, 26.103515625, 26.11328125, 26.123046875,
        26.1328125, 26.142578125, 26.15234375, 26.162109375, 26.171875,
        26.181640625, 26.19140625, 26.201171875, 26.2109375, 26.220703125,
        26.23046875, 26.240234375, 26.25, 26.259765625, 26.26953125,
        26.279296875, 26.2890625, 26.298828125, 26.30859375, 26.318359375,
        26.328125, 26.337890625, 26.34765625, 26.357421875, 26.3671875,
        26.376953125, 26.38671875, 26.396484375, 26.40625, 26.416015625,
        26.42578125, 26.435546875, 26.4453125, 26.455078125, 26.46484375,
        26.474609375, 26.484375, 26.494140625, 26.50390625, 26.513671875,
        26.5234375, 26.533203125, 26.54296875, 26.552734375, 26.5625,
        26.572265625, 26.58203125, 26.591796875, 26.6015625, 26.611328125,
        26.62109375, 26.630859375, 26.640625, 26.650390625, 26.66015625,
        26.669921875, 26.6796875, 26.689453125, 26.69921875, 26.708984375,
        26.71875, 26.728515625, 26.73828125, 26.748046875, 26.7578125,
        26.767578125, 26.77734375, 26.787109375, 26.796875, 26.806640625,
        26.81640625, 26.826171875, 26.8359375, 26.845703125, 26.85546875,
        26.865234375, 26.875, 26.884765625, 26.89453125, 26.904296875,
        26.9140625, 26.923828125, 26.93359375, 26.943359375, 26.953125,
        26.962890625, 26.97265625, 26.982421875, 26.9921875, 27.001953125,
        27.01171875, 27.021484375, 27.03125, 27.041015625, 27.05078125,
        27.060546875, 27.0703125, 27.080078125, 27.08984375, 27.099609375,
        27.109375, 27.119140625, 27.12890625, 27.138671875, 27.1484375,
        27.158203125, 27.16796875, 27.177734375, 27.1875, 27.197265625,
        27.20703125, 27.216796875, 27.2265625, 27.236328125, 27.24609375,
        27.255859375, 27.265625, 27.275390625, 27.28515625, 27.294921875,
        27.3046875, 27.314453125, 27.32421875, 27.333984375, 27.34375,
        27.353515625, 27.36328125, 27.373046875, 27.3828125, 27.392578125,
        27.40234375, 27.412109375, 27.421875, 27.431640625, 27.44140625,
        27.451171875, 27.4609375, 27.470703125, 27.48046875, 27.490234375, 27.5,
        27.509765625, 27.51953125, 27.529296875, 27.5390625, 27.548828125,
        27.55859375, 27.568359375, 27.578125, 27.587890625, 27.59765625,
        27.607421875, 27.6171875, 27.626953125, 27.63671875, 27.646484375,
        27.65625, 27.666015625, 27.67578125, 27.685546875, 27.6953125,
        27.705078125, 27.71484375, 27.724609375, 27.734375, 27.744140625,
        27.75390625, 27.763671875, 27.7734375, 27.783203125, 27.79296875,
        27.802734375, 27.8125, 27.822265625, 27.83203125, 27.841796875,
        27.8515625, 27.861328125, 27.87109375, 27.880859375, 27.890625,
        27.900390625, 27.91015625, 27.919921875, 27.9296875, 27.939453125,
        27.94921875, 27.958984375, 27.96875, 27.978515625, 27.98828125,
        27.998046875, 28.0078125, 28.017578125, 28.02734375, 28.037109375,
        28.046875, 28.056640625, 28.06640625, 28.076171875, 28.0859375,
        28.095703125, 28.10546875, 28.115234375, 28.125, 28.134765625,
        28.14453125, 28.154296875, 28.1640625, 28.173828125, 28.18359375,
        28.193359375, 28.203125, 28.212890625, 28.22265625, 28.232421875,
        28.2421875, 28.251953125, 28.26171875, 28.271484375, 28.28125,
        28.291015625, 28.30078125, 28.310546875, 28.3203125, 28.330078125,
        28.33984375, 28.349609375, 28.359375, 28.369140625, 28.37890625,
        28.388671875, 28.3984375, 28.408203125, 28.41796875, 28.427734375,
        28.4375, 28.447265625, 28.45703125, 28.466796875, 28.4765625,
        28.486328125, 28.49609375, 28.505859375, 28.515625, 28.525390625,
        28.53515625, 28.544921875, 28.5546875, 28.564453125, 28.57421875,
        28.583984375, 28.59375, 28.603515625, 28.61328125, 28.623046875,
        28.6328125, 28.642578125, 28.65234375, 28.662109375, 28.671875,
        28.681640625, 28.69140625, 28.701171875, 28.7109375, 28.720703125,
        28.73046875, 28.740234375, 28.75, 28.759765625, 28.76953125,
        28.779296875, 28.7890625, 28.798828125, 28.80859375, 28.818359375,
        28.828125, 28.837890625, 28.84765625, 28.857421875, 28.8671875,
        28.876953125, 28.88671875, 28.896484375, 28.90625, 28.916015625,
        28.92578125, 28.935546875, 28.9453125, 28.955078125, 28.96484375,
        28.974609375, 28.984375, 28.994140625, 29.00390625, 29.013671875,
        29.0234375, 29.033203125, 29.04296875, 29.052734375, 29.0625,
        29.072265625, 29.08203125, 29.091796875, 29.1015625, 29.111328125,
        29.12109375, 29.130859375, 29.140625, 29.150390625, 29.16015625,
        29.169921875, 29.1796875, 29.189453125, 29.19921875, 29.208984375,
        29.21875, 29.228515625, 29.23828125, 29.248046875, 29.2578125,
        29.267578125, 29.27734375, 29.287109375, 29.296875, 29.306640625,
        29.31640625, 29.326171875, 29.3359375, 29.345703125, 29.35546875,
        29.365234375, 29.375, 29.384765625, 29.39453125, 29.404296875,
        29.4140625, 29.423828125, 29.43359375, 29.443359375, 29.453125,
        29.462890625, 29.47265625, 29.482421875, 29.4921875, 29.501953125,
        29.51171875, 29.521484375, 29.53125, 29.541015625, 29.55078125,
        29.560546875, 29.5703125, 29.580078125, 29.58984375, 29.599609375,
        29.609375, 29.619140625, 29.62890625, 29.638671875, 29.6484375,
        29.658203125, 29.66796875, 29.677734375, 29.6875, 29.697265625,
        29.70703125, 29.716796875, 29.7265625, 29.736328125, 29.74609375,
        29.755859375, 29.765625, 29.775390625, 29.78515625, 29.794921875,
        29.8046875, 29.814453125, 29.82421875, 29.833984375, 29.84375,
        29.853515625, 29.86328125, 29.873046875, 29.8828125, 29.892578125,
        29.90234375, 29.912109375, 29.921875, 29.931640625, 29.94140625,
        29.951171875, 29.9609375, 29.970703125, 29.98046875, 29.990234375, 30.0,
        30.009765625, 30.01953125, 30.029296875, 30.0390625, 30.048828125,
        30.05859375, 30.068359375, 30.078125, 30.087890625, 30.09765625,
        30.107421875, 30.1171875, 30.126953125, 30.13671875, 30.146484375,
        30.15625, 30.166015625, 30.17578125, 30.185546875, 30.1953125,
        30.205078125, 30.21484375, 30.224609375, 30.234375, 30.244140625,
        30.25390625, 30.263671875, 30.2734375, 30.283203125, 30.29296875,
        30.302734375, 30.3125, 30.322265625, 30.33203125, 30.341796875,
        30.3515625, 30.361328125, 30.37109375, 30.380859375, 30.390625,
        30.400390625, 30.41015625, 30.419921875, 30.4296875, 30.439453125,
        30.44921875, 30.458984375, 30.46875, 30.478515625, 30.48828125,
        30.498046875, 30.5078125, 30.517578125, 30.52734375, 30.537109375,
        30.546875, 30.556640625, 30.56640625, 30.576171875, 30.5859375,
        30.595703125, 30.60546875, 30.615234375, 30.625, 30.634765625,
        30.64453125, 30.654296875, 30.6640625, 30.673828125, 30.68359375,
        30.693359375, 30.703125, 30.712890625, 30.72265625, 30.732421875,
        30.7421875, 30.751953125, 30.76171875, 30.771484375, 30.78125,
        30.791015625, 30.80078125, 30.810546875, 30.8203125, 30.830078125,
        30.83984375, 30.849609375, 30.859375, 30.869140625, 30.87890625,
        30.888671875, 30.8984375, 30.908203125, 30.91796875, 30.927734375,
        30.9375, 30.947265625, 30.95703125, 30.966796875, 30.9765625,
        30.986328125, 30.99609375, 31.005859375, 31.015625, 31.025390625,
        31.03515625, 31.044921875, 31.0546875, 31.064453125, 31.07421875,
        31.083984375, 31.09375, 31.103515625, 31.11328125, 31.123046875,
        31.1328125, 31.142578125, 31.15234375, 31.162109375, 31.171875,
        31.181640625, 31.19140625, 31.201171875, 31.2109375, 31.220703125,
        31.23046875, 31.240234375, 31.25, 31.259765625, 31.26953125,
        31.279296875, 31.2890625, 31.298828125, 31.30859375, 31.318359375,
        31.328125, 31.337890625, 31.34765625, 31.357421875, 31.3671875,
        31.376953125, 31.38671875, 31.396484375, 31.40625, 31.416015625,
        31.42578125, 31.435546875, 31.4453125, 31.455078125, 31.46484375,
        31.474609375, 31.484375, 31.494140625, 31.50390625, 31.513671875,
        31.5234375, 31.533203125, 31.54296875, 31.552734375, 31.5625,
        31.572265625, 31.58203125, 31.591796875, 31.6015625, 31.611328125,
        31.62109375, 31.630859375, 31.640625, 31.650390625, 31.66015625,
        31.669921875, 31.6796875, 31.689453125, 31.69921875, 31.708984375,
        31.71875, 31.728515625, 31.73828125, 31.748046875, 31.7578125,
        31.767578125, 31.77734375, 31.787109375, 31.796875, 31.806640625,
        31.81640625, 31.826171875, 31.8359375, 31.845703125, 31.85546875,
        31.865234375, 31.875, 31.884765625, 31.89453125, 31.904296875,
        31.9140625, 31.923828125, 31.93359375, 31.943359375, 31.953125,
        31.962890625, 31.97265625, 31.982421875, 31.9921875, 32.001953125,
        32.01171875, 32.021484375, 32.03125, 32.041015625, 32.05078125,
        32.060546875, 32.0703125, 32.080078125, 32.08984375, 32.099609375,
        32.109375, 32.119140625, 32.12890625, 32.138671875, 32.1484375,
        32.158203125, 32.16796875, 32.177734375, 32.1875, 32.197265625,
        32.20703125, 32.216796875, 32.2265625, 32.236328125, 32.24609375,
        32.255859375, 32.265625, 32.275390625, 32.28515625, 32.294921875,
        32.3046875, 32.314453125, 32.32421875, 32.333984375, 32.34375,
        32.353515625, 32.36328125, 32.373046875, 32.3828125, 32.392578125,
        32.40234375, 32.412109375, 32.421875, 32.431640625, 32.44140625,
        32.451171875, 32.4609375, 32.470703125, 32.48046875, 32.490234375, 32.5,
        32.509765625, 32.51953125, 32.529296875, 32.5390625, 32.548828125,
        32.55859375, 32.568359375, 32.578125, 32.587890625, 32.59765625,
        32.607421875, 32.6171875, 32.626953125, 32.63671875, 32.646484375,
        32.65625, 32.666015625, 32.67578125, 32.685546875, 32.6953125,
        32.705078125, 32.71484375, 32.724609375, 32.734375, 32.744140625,
        32.75390625, 32.763671875, 32.7734375, 32.783203125, 32.79296875,
        32.802734375, 32.8125, 32.822265625, 32.83203125, 32.841796875,
        32.8515625, 32.861328125, 32.87109375, 32.880859375, 32.890625,
        32.900390625, 32.91015625, 32.919921875, 32.9296875, 32.939453125,
        32.94921875, 32.958984375, 32.96875, 32.978515625, 32.98828125,
        32.998046875, 33.0078125, 33.017578125, 33.02734375, 33.037109375,
        33.046875, 33.056640625, 33.06640625, 33.076171875, 33.0859375,
        33.095703125, 33.10546875, 33.115234375, 33.125, 33.134765625,
        33.14453125, 33.154296875, 33.1640625, 33.173828125, 33.18359375,
        33.193359375, 33.203125, 33.212890625, 33.22265625, 33.232421875,
        33.2421875, 33.251953125, 33.26171875, 33.271484375, 33.28125,
        33.291015625, 33.30078125, 33.310546875, 33.3203125, 33.330078125,
        33.33984375, 33.349609375, 33.359375, 33.369140625, 33.37890625,
        33.388671875, 33.3984375, 33.408203125, 33.41796875, 33.427734375,
        33.4375, 33.447265625, 33.45703125, 33.466796875, 33.4765625,
        33.486328125, 33.49609375, 33.505859375, 33.515625, 33.525390625,
        33.53515625, 33.544921875, 33.5546875, 33.564453125, 33.57421875,
        33.583984375, 33.59375, 33.603515625, 33.61328125, 33.623046875,
        33.6328125, 33.642578125, 33.65234375, 33.662109375, 33.671875,
        33.681640625, 33.69140625, 33.701171875, 33.7109375, 33.720703125,
        33.73046875, 33.740234375, 33.75, 33.759765625, 33.76953125,
        33.779296875, 33.7890625, 33.798828125, 33.80859375, 33.818359375,
        33.828125, 33.837890625, 33.84765625, 33.857421875, 33.8671875,
        33.876953125, 33.88671875, 33.896484375, 33.90625, 33.916015625,
        33.92578125, 33.935546875, 33.9453125, 33.955078125, 33.96484375,
        33.974609375, 33.984375, 33.994140625, 34.00390625, 34.013671875,
        34.0234375, 34.033203125, 34.04296875, 34.052734375, 34.0625,
        34.072265625, 34.08203125, 34.091796875, 34.1015625, 34.111328125,
        34.12109375, 34.130859375, 34.140625, 34.150390625, 34.16015625,
        34.169921875, 34.1796875, 34.189453125, 34.19921875, 34.208984375,
        34.21875, 34.228515625, 34.23828125, 34.248046875, 34.2578125,
        34.267578125, 34.27734375, 34.287109375, 34.296875, 34.306640625,
        34.31640625, 34.326171875, 34.3359375, 34.345703125, 34.35546875,
        34.365234375, 34.375, 34.384765625, 34.39453125, 34.404296875,
        34.4140625, 34.423828125, 34.43359375, 34.443359375, 34.453125,
        34.462890625, 34.47265625, 34.482421875, 34.4921875, 34.501953125,
        34.51171875, 34.521484375, 34.53125, 34.541015625, 34.55078125,
        34.560546875, 34.5703125, 34.580078125, 34.58984375, 34.599609375,
        34.609375, 34.619140625, 34.62890625, 34.638671875, 34.6484375,
        34.658203125, 34.66796875, 34.677734375, 34.6875, 34.697265625,
        34.70703125, 34.716796875, 34.7265625, 34.736328125, 34.74609375,
        34.755859375, 34.765625, 34.775390625, 34.78515625, 34.794921875,
        34.8046875, 34.814453125, 34.82421875, 34.833984375, 34.84375,
        34.853515625, 34.86328125, 34.873046875, 34.8828125, 34.892578125,
        34.90234375, 34.912109375, 34.921875, 34.931640625, 34.94140625,
        34.951171875, 34.9609375, 34.970703125, 34.98046875, 34.990234375, 35.0,
        35.009765625, 35.01953125, 35.029296875, 35.0390625, 35.048828125,
        35.05859375, 35.068359375, 35.078125, 35.087890625, 35.09765625,
        35.107421875, 35.1171875, 35.126953125, 35.13671875, 35.146484375,
        35.15625, 35.166015625, 35.17578125, 35.185546875, 35.1953125,
        35.205078125, 35.21484375, 35.224609375, 35.234375, 35.244140625,
        35.25390625, 35.263671875, 35.2734375, 35.283203125, 35.29296875,
        35.302734375, 35.3125, 35.322265625, 35.33203125, 35.341796875,
        35.3515625, 35.361328125, 35.37109375, 35.380859375, 35.390625,
        35.400390625, 35.41015625, 35.419921875, 35.4296875, 35.439453125,
        35.44921875, 35.458984375, 35.46875, 35.478515625, 35.48828125,
        35.498046875, 35.5078125, 35.517578125, 35.52734375, 35.537109375,
        35.546875, 35.556640625, 35.56640625, 35.576171875, 35.5859375,
        35.595703125, 35.60546875, 35.615234375, 35.625, 35.634765625,
        35.64453125, 35.654296875, 35.6640625, 35.673828125, 35.68359375,
        35.693359375, 35.703125, 35.712890625, 35.72265625, 35.732421875,
        35.7421875, 35.751953125, 35.76171875, 35.771484375, 35.78125,
        35.791015625, 35.80078125, 35.810546875, 35.8203125, 35.830078125,
        35.83984375, 35.849609375, 35.859375, 35.869140625, 35.87890625,
        35.888671875, 35.8984375, 35.908203125, 35.91796875, 35.927734375,
        35.9375, 35.947265625, 35.95703125, 35.966796875, 35.9765625,
        35.986328125, 35.99609375, 36.005859375, 36.015625, 36.025390625,
        36.03515625, 36.044921875, 36.0546875, 36.064453125, 36.07421875,
        36.083984375, 36.09375, 36.103515625, 36.11328125, 36.123046875,
        36.1328125, 36.142578125, 36.15234375, 36.162109375, 36.171875,
        36.181640625, 36.19140625, 36.201171875, 36.2109375, 36.220703125,
        36.23046875, 36.240234375, 36.25, 36.259765625, 36.26953125,
        36.279296875, 36.2890625, 36.298828125, 36.30859375, 36.318359375,
        36.328125, 36.337890625, 36.34765625, 36.357421875, 36.3671875,
        36.376953125, 36.38671875, 36.396484375, 36.40625, 36.416015625,
        36.42578125, 36.435546875, 36.4453125, 36.455078125, 36.46484375,
        36.474609375, 36.484375, 36.494140625, 36.50390625, 36.513671875,
        36.5234375, 36.533203125, 36.54296875, 36.552734375, 36.5625,
        36.572265625, 36.58203125, 36.591796875, 36.6015625, 36.611328125,
        36.62109375, 36.630859375, 36.640625, 36.650390625, 36.66015625,
        36.669921875, 36.6796875, 36.689453125, 36.69921875, 36.708984375,
        36.71875, 36.728515625, 36.73828125, 36.748046875, 36.7578125,
        36.767578125, 36.77734375, 36.787109375, 36.796875, 36.806640625,
        36.81640625, 36.826171875, 36.8359375, 36.845703125, 36.85546875,
        36.865234375, 36.875, 36.884765625, 36.89453125, 36.904296875,
        36.9140625, 36.923828125, 36.93359375, 36.943359375, 36.953125,
        36.962890625, 36.97265625, 36.982421875, 36.9921875, 37.001953125,
        37.01171875, 37.021484375, 37.03125, 37.041015625, 37.05078125,
        37.060546875, 37.0703125, 37.080078125, 37.08984375, 37.099609375,
        37.109375, 37.119140625, 37.12890625, 37.138671875, 37.1484375,
        37.158203125, 37.16796875, 37.177734375, 37.1875, 37.197265625,
        37.20703125, 37.216796875, 37.2265625, 37.236328125, 37.24609375,
        37.255859375, 37.265625, 37.275390625, 37.28515625, 37.294921875,
        37.3046875, 37.314453125, 37.32421875, 37.333984375, 37.34375,
        37.353515625, 37.36328125, 37.373046875, 37.3828125, 37.392578125,
        37.40234375, 37.412109375, 37.421875, 37.431640625, 37.44140625,
        37.451171875, 37.4609375, 37.470703125, 37.48046875, 37.490234375, 37.5,
        37.509765625, 37.51953125, 37.529296875, 37.5390625, 37.548828125,
        37.55859375, 37.568359375, 37.578125, 37.587890625, 37.59765625,
        37.607421875, 37.6171875, 37.626953125, 37.63671875, 37.646484375,
        37.65625, 37.666015625, 37.67578125, 37.685546875, 37.6953125,
        37.705078125, 37.71484375, 37.724609375, 37.734375, 37.744140625,
        37.75390625, 37.763671875, 37.7734375, 37.783203125, 37.79296875,
        37.802734375, 37.8125, 37.822265625, 37.83203125, 37.841796875,
        37.8515625, 37.861328125, 37.87109375, 37.880859375, 37.890625,
        37.900390625, 37.91015625, 37.919921875, 37.9296875, 37.939453125,
        37.94921875, 37.958984375, 37.96875, 37.978515625, 37.98828125,
        37.998046875, 38.0078125, 38.017578125, 38.02734375, 38.037109375,
        38.046875, 38.056640625, 38.06640625, 38.076171875, 38.0859375,
        38.095703125, 38.10546875, 38.115234375, 38.125, 38.134765625,
        38.14453125, 38.154296875, 38.1640625, 38.173828125, 38.18359375,
        38.193359375, 38.203125, 38.212890625, 38.22265625, 38.232421875,
        38.2421875, 38.251953125, 38.26171875, 38.271484375, 38.28125,
        38.291015625, 38.30078125, 38.310546875, 38.3203125, 38.330078125,
        38.33984375, 38.349609375, 38.359375, 38.369140625, 38.37890625,
        38.388671875, 38.3984375, 38.408203125, 38.41796875, 38.427734375,
        38.4375, 38.447265625, 38.45703125, 38.466796875, 38.4765625,
        38.486328125, 38.49609375, 38.505859375, 38.515625, 38.525390625,
        38.53515625, 38.544921875, 38.5546875, 38.564453125, 38.57421875,
        38.583984375, 38.59375, 38.603515625, 38.61328125, 38.623046875,
        38.6328125, 38.642578125, 38.65234375, 38.662109375, 38.671875,
        38.681640625, 38.69140625, 38.701171875, 38.7109375, 38.720703125,
        38.73046875, 38.740234375, 38.75, 38.759765625, 38.76953125,
        38.779296875, 38.7890625, 38.798828125, 38.80859375, 38.818359375,
        38.828125, 38.837890625, 38.84765625, 38.857421875, 38.8671875,
        38.876953125, 38.88671875, 38.896484375, 38.90625, 38.916015625,
        38.92578125, 38.935546875, 38.9453125, 38.955078125, 38.96484375,
        38.974609375, 38.984375, 38.994140625, 39.00390625, 39.013671875,
        39.0234375, 39.033203125, 39.04296875, 39.052734375, 39.0625,
        39.072265625, 39.08203125, 39.091796875, 39.1015625, 39.111328125,
        39.12109375, 39.130859375, 39.140625, 39.150390625, 39.16015625,
        39.169921875, 39.1796875, 39.189453125, 39.19921875, 39.208984375,
        39.21875, 39.228515625, 39.23828125, 39.248046875, 39.2578125,
        39.267578125, 39.27734375, 39.287109375, 39.296875, 39.306640625,
        39.31640625, 39.326171875, 39.3359375, 39.345703125, 39.35546875,
        39.365234375, 39.375, 39.384765625, 39.39453125, 39.404296875,
        39.4140625, 39.423828125, 39.43359375, 39.443359375, 39.453125,
        39.462890625, 39.47265625, 39.482421875, 39.4921875, 39.501953125,
        39.51171875, 39.521484375, 39.53125, 39.541015625, 39.55078125,
        39.560546875, 39.5703125, 39.580078125, 39.58984375, 39.599609375,
        39.609375, 39.619140625, 39.62890625, 39.638671875, 39.6484375,
        39.658203125, 39.66796875, 39.677734375, 39.6875, 39.697265625,
        39.70703125, 39.716796875, 39.7265625, 39.736328125, 39.74609375,
        39.755859375, 39.765625, 39.775390625, 39.78515625, 39.794921875,
        39.8046875, 39.814453125, 39.82421875, 39.833984375, 39.84375,
        39.853515625, 39.86328125, 39.873046875, 39.8828125, 39.892578125,
        39.90234375, 39.912109375, 39.921875, 39.931640625, 39.94140625,
        39.951171875, 39.9609375, 39.970703125, 39.98046875, 39.990234375, 40.0,
        40.009765625, 40.01953125, 40.029296875 } ;

      static real_T pDataValues0[] = { 0.0049236040804607256,
        0.0020032842971943765, -0.010925444129072332, -0.0054961049166662047,
        0.0088158408135867727, -0.0087539925161988462, 0.01300384584270378,
        0.013750681974357241, -0.026417942821240634, -0.0081266442587447554,
        0.020910479108107258, 0.0098168108728565063, 0.01764161752812244,
        -0.027626978631403558, 0.025233695603163339, 0.010542193718773045,
        0.018464955723030148, -0.0088771005876942376, -0.0078197398828802264,
        0.008676081481760748, -0.014778982212576603, -0.0099216342999255136,
        -0.014578018656252661, -0.00077658714536532863, -0.012987083927544588,
        -0.0090609834519429222, 0.018946642862263007, 0.015045157065683578,
        0.006708955495805813, -0.00028310507157100804, -0.026868607494067113,
        -0.005148152977278061, 0.00397677173933013, 0.022065529202473247,
        -0.010942753006805252, 0.026368303207209478, -0.018624685483749133,
        0.026103464924784658, 0.0056407823290818004, -0.00343380422761762,
        -0.018799855892486585, -0.010379486000253233, 0.0084626604614132673,
        -0.010996078977180969, 0.023331145495973194, 0.021173176490147619,
        -0.012621099751947964, 0.0059666069414387388, -0.0095551466874497087,
        0.01763049682847018, 0.010552065936043117, -0.0235417003104494,
        0.021027674535218924, 0.011227475628336739, -0.014325270846793773,
        0.0064743089203085991, -0.0021113235790818012, -0.023947181421117326,
        0.004366820879600275, 0.00027015795217459485, 0.002928147143792529,
        0.0040119410416391789, 0.011995633089772275, 0.0095749095502177788,
        0.0026711527621116919, 0.026968279318860644, -0.017340029164722735,
        0.016107031952301287, 0.021484374634796546, 0.011107005940754857,
        -0.0038387692687362213, 0.013346087574324653, 0.0050152194694508693,
        -0.00070286148200660113, 0.0065410905186553568, 0.013551728193680333,
        -0.031463161842818277, -0.002110052375679356, -0.006056030488751093,
        0.010901626520437193, -0.0040180202919192134, 0.00139063077213079,
        0.0016082106577239631, 0.0040733006295044913, -0.015109673952605096,
        0.017318680377902424, -0.012378860685477245, -0.013014801428912381,
        -0.025499076864863943, -0.012420422819569087, 0.00030263865313142078,
        -0.0019691900616251655, 0.0060079994935423008, -0.002611435060640399,
        0.030088779710346191, 0.011032616059908081, -0.0080118760788806358,
        0.030316702378155532, 0.00039940075457293794, -0.00062199231715660906,
        0.013902232398568188, 0.015365759258540331, 0.019234763839184012,
        0.00955593285013652, -0.027122752855659227, 0.013816104117962422,
        -0.0077266967692022339, -0.010055423397056583, 0.0075890470326120205,
        0.0030718592407111738, -0.014525417622050537, 0.023989189854599132,
        -0.025426244762906992, 0.0049107930699610839, 0.034167991056854592,
        -0.020292061026623013, 0.007931045052180544, -0.0098201000738324749,
        0.0053120494846653366, -0.0054531474425964892, -0.032684991012887576,
        0.0016576777024524406, 0.0042867000048820757, 0.0084514957111480066,
        -0.0033564663822261706, 0.014886320335569357, 0.027907586703399035,
        0.0060427601901836686, -0.020732900002552995, -0.028364085358253192,
        -0.0073589236047119566, -0.0063247825572223821, 0.013902088787738812,
        -0.010149899462971059, 0.0089484392443958, -0.011637354780539252,
        0.023110073721109386, 0.014101398298792464, -0.0061543160019334334,
        0.0089333438524918148, 0.013703435846692761, 0.010195124635655162,
        0.015326067399257955, 0.0055545682398188941, -0.034806515719448164,
        -0.0041655120378532853, -0.006071922631655664, -0.016990639436043575,
        0.00960071796618779, -0.0014932841242445974, 0.012403645218437958,
        -0.022100315930147996, 0.01170728470701575, 0.006053043326788193,
        -0.0028965731128382127, -0.015295570203066901, 0.0027111013548173106,
        -0.009317607503347097, -0.0044275077996890448, -0.00013819389241728506,
        -0.016027698071705475, 0.0015703656308963105, 0.0061521956029135759,
        0.0024652990419707075, 0.0054272139308849067, 0.022785525212254052,
        -0.014889598450359412, -0.01252901969428321, -0.00029986472187008676,
        -0.033006598408008736, 0.015452469486149355, 0.03140973827615702,
        -0.0067830258378828523, 0.0012766711399865298, -0.00813744710530078,
        0.00809165333454218, 0.016391625927173907, -0.015510423358502346,
        -0.004895042274954969, 0.0012440063744654554, -0.0011142298498259258,
        0.0053543217657067614, -0.0015075798777473683, 0.018012801453393991,
        -0.017057939529644055, 0.010294658318733722, -0.0019717253461941694,
        0.031465427156287175, 0.0053636403447456325, 0.018700403757107634,
        -0.040215110423038158, 0.0075923880036712693, -0.008546251829529913,
        -0.014408769111399513, 0.0089849357652853623, 0.0064581519232847929,
        -0.016416745527083748, 0.012505244609778102, -0.020993821982514829,
        -0.0101199838202945, -0.016430608182581553, -0.0014444637689372097,
        0.011138240723347986, -0.0072471296147392193, 0.0023879030864215412,
        -0.00086417635209278172, -0.02099687886444113, -0.00077414829374111813,
        0.0089806512814890431, 0.0013761550060400805, 0.0017882830217159471,
        0.013512044076921569, 0.00055633966496365021, 0.0010599323887105357,
        -0.0064797149222610793, 0.0035873837237929891, 0.016551428888803343,
        0.011332614618193721, -0.0047825420545592589, 0.0037818195274386167,
        -0.031578335216407939, -0.025870917638113163, 0.015902671761643474,
        0.00057669959501837015, 0.0064831192295961623, -0.024642699697047715,
        0.0049361436627967138, 0.012339234714400406, -0.0057458600032989342,
        0.024744892758821413, -0.0060347399400733914, -0.0017727719543939558,
        0.019778763845118039, -0.0063841870124767448, 0.0035168176112569203,
        0.021745978040826067, 0.036469723249254384, 0.03020396886499345,
        -0.022693872263818759, 0.0059529714426103377, -0.027834331440092289,
        0.028955883845445823, 0.011481974886327444, -0.0022797971196413924,
        0.014990783925671226, 0.02084657241059492, 0.009666741865220348,
        -0.017504266663738267, 0.0055325006161188219, -0.0071196271391368538,
        0.0051653005714752467, 0.017542340603087042, 0.008319177152008474,
        -0.0018628582748523401, 0.025652390504981509, 0.0035321104022140184,
        0.024094647200102154, 0.03605782290583371, 0.00741713252605771,
        0.015118642573661438, 0.029340584889462909, -0.016263429833632558,
        -0.011436932341232772, 0.0036576609251943244, -0.012167466469851236,
        0.0018450284304378037, -0.0061840662591815835, -0.017280142226316051,
        -0.0048428229871760086, -0.00757778731357165, 0.029895280180059755,
        0.01460768542244208, 0.0070190548045756321, -0.001095608871848253,
        -0.001021979909506292, -0.017229599694573414, -0.026931523577029028,
        0.010563422876323699, -0.0036670633203375628, 0.0086935726879527712,
        -0.0035367826162642723, 0.013630733601280363, 0.013294274383844685,
        0.027252156728203764, 0.031680295099834964, -0.0056875839796279104,
        -0.036383455113412511, -0.016641396816860398, 0.026659681010452123,
        0.0065317708488546681, -0.0078963296142955629, 0.0054835007197571,
        0.019849320824055845, 0.0015511309950194732, -0.00801718977481245,
        -0.0060643843228890635, 0.018040397807473449, 0.0049885734800994147,
        0.005399867711815714, -0.00028680612312387412, 0.0038586998652956235,
        0.020406747891271643, -0.014574406872819438, 0.030500764634416214,
        0.0054077092477865189, -0.0046372854998416608, -0.042769944008921069,
        0.0016580120923716921, 0.00929551084621051, 0.0068855515292257936,
        -0.01576262722128886, -0.010517551133159803, -0.0084528776836444355,
        -0.019041333987724913, 0.0016123140883564911, -0.011980293010116378,
        0.00986333240075282, 0.0029697589328645927, 0.00994369105908122,
        0.0059793190732206018, 0.012605276835608293, -0.012592035031809685,
        -0.0193251970852042, -0.0077760774532812989, 0.015392653585137505,
        -0.018961355429928297, 0.028300809077052, 0.022460157844348544,
        -0.011192561360428843, 0.0016653178308302288, 0.012388857690229817,
        -0.01263328622643423, 0.0048951717107396254, 0.042910847150704375,
        0.021232459818053915, 0.014504638928902795, 0.0062305327144025072,
        0.012878341916246459, 0.011473360705187037, -0.0065734687815719979,
        0.0030936413719386611, -0.0041099275580307312, -0.010280378539881358,
        -0.030474368065192541, 0.00065196823422589709, -0.00395291710758381,
        -0.0065350956061044933, -0.017590376083896866, 0.022931941063869671,
        -0.019128423777239348, 0.0095129665445948253, 0.013245438750061875,
        -0.0067916666614841366, -0.010972211454391327, 0.025273142934224814,
        0.014471561538933716, -0.015417083505133858, 0.00083743935290770278,
        0.011527734820277157, 0.0029012466476496203, -0.029193929925598029,
        -0.0084349210852920718, 0.0038520338122005251, -0.0020119858846404941,
        -0.0056602651562688705, -0.0089773913409118521, -0.033578299062070945,
        0.00028822465334923014, -0.00060328479216208131, 0.019204590974891928,
        -0.016152639294939434, -0.0071178306349516359, -0.017961278343287576,
        -0.0096899705065884422, -0.020327942159082693, -0.0038501359129164319,
        0.0070909914573790726, 0.00029716644713644513, -0.023716782310077403,
        -0.019528925379039816, -0.00079844493918787736, -0.0070988027829033649,
        0.0084180765434620948, -0.016083506631342576, 0.0045924216366215534,
        0.011142612111522147, 0.002888176816865008, 0.00802537064633478,
        -0.012766805851510637, 0.020198639394994649, 0.0097083720639130951,
        0.0091676464508220964, -0.00435884056013626, -0.013915611244386256,
        0.013481596250711488, -0.014337918372558649, 0.019404586463669288,
        -0.0098214668758865552, 0.021056718189873844, 6.7614524033604955E-5,
        -0.013920410191938721, 0.0012444533110068793, 0.0040703287925533327,
        -0.0066164411107134608, -0.014974333383922839, -0.0020554198413561338,
        -0.0028486968111954818, 0.011394150631827239, 0.027818461693824466,
        0.0077734577488767654, -0.0049236040804607256, -0.0020032842971943765,
        0.010925444129072332, 0.0054961049166662047, -0.0088158408135867727,
        0.0087539925161988462, -0.01300384584270378, -0.013750681974357241,
        0.026417942821240634, 0.0081266442587447554, -0.020910479108107258,
        -0.0098168108728565063, -0.01764161752812244, 0.027626978631403558,
        -0.025233695603163339, -0.010542193718773045, -0.018464955723030148,
        0.0088771005876942376, 0.0078197398828802264, -0.008676081481760748,
        0.014778982212576603, 0.0099216342999255136, 0.014578018656252661,
        0.00077658714536532863, 0.012987083927544588, 0.0090609834519429222,
        -0.018946642862263007, -0.015045157065683578, -0.006708955495805813,
        0.00028310507157100804, 0.026868607494067113, 0.005148152977278061,
        -0.00397677173933013, -0.022065529202473247, 0.010942753006805252,
        -0.026368303207209478, 0.018624685483749133, -0.026103464924784658,
        -0.0056407823290818004, 0.00343380422761762, 0.018799855892486585,
        0.010379486000253233, -0.0084626604614132673, 0.010996078977180969,
        -0.023331145495973194, -0.021173176490147619, 0.012621099751947964,
        -0.0059666069414387388, 0.0095551466874497087, -0.01763049682847018,
        -0.010552065936043117, 0.0235417003104494, -0.021027674535218924,
        -0.011227475628336739, 0.014325270846793773, -0.0064743089203085991,
        0.0021113235790818012, 0.023947181421117326, -0.004366820879600275,
        -0.00027015795217459485, -0.002928147143792529, -0.0040119410416391789,
        -0.011995633089772275, -0.0095749095502177788, -0.0026711527621116919,
        -0.026968279318860644, 0.017340029164722735, -0.016107031952301287,
        -0.021484374634796546, -0.011107005940754857, 0.0038387692687362213,
        -0.013346087574324653, -0.0050152194694508693, 0.00070286148200660113,
        -0.0065410905186553568, -0.013551728193680333, 0.031463161842818277,
        0.002110052375679356, 0.006056030488751093, -0.010901626520437193,
        0.0040180202919192134, -0.00139063077213079, -0.0016082106577239631,
        -0.0040733006295044913, 0.015109673952605096, -0.017318680377902424,
        0.012378860685477245, 0.013014801428912381, 0.025499076864863943,
        0.012420422819569087, -0.00030263865313142078, 0.0019691900616251655,
        -0.0060079994935423008, 0.002611435060640399, -0.030088779710346191,
        -0.011032616059908081, 0.0080118760788806358, -0.030316702378155532,
        -0.00039940075457293794, 0.00062199231715660906, -0.013902232398568188,
        -0.015365759258540331, -0.019234763839184012, -0.00955593285013652,
        0.027122752855659227, -0.013816104117962422, 0.0077266967692022339,
        0.010055423397056583, -0.0075890470326120205, -0.0030718592407111738,
        0.014525417622050537, -0.023989189854599132, 0.025426244762906992,
        -0.0049107930699610839, -0.034167991056854592, 0.020292061026623013,
        -0.007931045052180544, 0.0098201000738324749, -0.0053120494846653366,
        0.0054531474425964892, 0.032684991012887576, -0.0016576777024524406,
        -0.0042867000048820757, -0.0084514957111480066, 0.0033564663822261706,
        -0.014886320335569357, -0.027907586703399035, -0.0060427601901836686,
        0.020732900002552995, 0.028364085358253192, 0.0073589236047119566,
        0.0063247825572223821, -0.013902088787738812, 0.010149899462971059,
        -0.0089484392443958, 0.011637354780539252, -0.023110073721109386,
        -0.014101398298792464, 0.0061543160019334334, -0.0089333438524918148,
        -0.013703435846692761, -0.010195124635655162, -0.015326067399257955,
        -0.0055545682398188941, 0.034806515719448164, 0.0041655120378532853,
        0.006071922631655664, 0.016990639436043575, -0.00960071796618779,
        0.0014932841242445974, -0.012403645218437958, 0.022100315930147996,
        -0.01170728470701575, -0.006053043326788193, 0.0028965731128382127,
        0.015295570203066901, -0.0027111013548173106, 0.009317607503347097,
        0.0044275077996890448, 0.00013819389241728506, 0.016027698071705475,
        -0.0015703656308963105, -0.0061521956029135759, -0.0024652990419707075,
        -0.0054272139308849067, -0.022785525212254052, 0.014889598450359412,
        0.01252901969428321, 0.00029986472187008676, 0.033006598408008736,
        -0.015452469486149355, -0.03140973827615702, 0.0067830258378828523,
        -0.0012766711399865298, 0.00813744710530078, -0.00809165333454218,
        -0.016391625927173907, 0.015510423358502346, 0.004895042274954969,
        -0.0012440063744654554, 0.0011142298498259258, -0.0053543217657067614,
        0.0015075798777473683, -0.018012801453393991, 0.017057939529644055,
        -0.010294658318733722, 0.0019717253461941694, -0.031465427156287175,
        -0.0053636403447456325, -0.018700403757107634, 0.040215110423038158,
        -0.0075923880036712693, 0.008546251829529913, 0.014408769111399513,
        -0.0089849357652853623, -0.0064581519232847929, 0.016416745527083748,
        -0.012505244609778102, 0.020993821982514829, 0.0101199838202945,
        0.016430608182581553, 0.0014444637689372097, -0.011138240723347986,
        0.0072471296147392193, -0.0023879030864215412, 0.00086417635209278172,
        0.02099687886444113, 0.00077414829374111813, -0.0089806512814890431,
        -0.0013761550060400805, -0.0017882830217159471, -0.013512044076921569,
        -0.00055633966496365021, -0.0010599323887105357, 0.0064797149222610793,
        -0.0035873837237929891, -0.016551428888803343, -0.011332614618193721,
        0.0047825420545592589, -0.0037818195274386167, 0.031578335216407939,
        0.025870917638113163, -0.015902671761643474, -0.00057669959501837015,
        -0.0064831192295961623, 0.024642699697047715, -0.0049361436627967138,
        -0.012339234714400406, 0.0057458600032989342, -0.024744892758821413,
        0.0060347399400733914, 0.0017727719543939558, -0.019778763845118039,
        0.0063841870124767448, -0.0035168176112569203, -0.021745978040826067,
        -0.036469723249254384, -0.03020396886499345, 0.022693872263818759,
        -0.0059529714426103377, 0.027834331440092289, -0.028955883845445823,
        -0.011481974886327444, 0.0022797971196413924, -0.014990783925671226,
        -0.02084657241059492, -0.009666741865220348, 0.017504266663738267,
        -0.0055325006161188219, 0.0071196271391368538, -0.0051653005714752467,
        -0.017542340603087042, -0.008319177152008474, 0.0018628582748523401,
        -0.025652390504981509, -0.0035321104022140184, -0.024094647200102154,
        -0.03605782290583371, -0.00741713252605771, -0.015118642573661438,
        -0.029340584889462909, 0.016263429833632558, 0.011436932341232772,
        -0.0036576609251943244, 0.012167466469851236, -0.0018450284304378037,
        0.0061840662591815835, 0.017280142226316051, 0.0048428229871760086,
        0.00757778731357165, -0.029895280180059755, -0.01460768542244208,
        -0.0070190548045756321, 0.001095608871848253, 0.001021979909506292,
        0.017229599694573414, 0.026931523577029028, -0.010563422876323699,
        0.0036670633203375628, -0.0086935726879527712, 0.0035367826162642723,
        -0.013630733601280363, -0.013294274383844685, -0.027252156728203764,
        -0.031680295099834964, 0.0056875839796279104, 0.036383455113412511,
        0.016641396816860398, -0.026659681010452123, -0.0065317708488546681,
        0.0078963296142955629, -0.0054835007197571, -0.019849320824055845,
        -0.0015511309950194732, 0.00801718977481245, 0.0060643843228890635,
        -0.018040397807473449, -0.0049885734800994147, -0.005399867711815714,
        0.00028680612312387412, -0.0038586998652956235, -0.020406747891271643,
        0.014574406872819438, -0.030500764634416214, -0.0054077092477865189,
        0.0046372854998416608, 0.042769944008921069, -0.0016580120923716921,
        -0.00929551084621051, -0.0068855515292257936, 0.01576262722128886,
        0.010517551133159803, 0.0084528776836444355, 0.019041333987724913,
        -0.0016123140883564911, 0.011980293010116378, -0.00986333240075282,
        -0.0029697589328645927, -0.00994369105908122, -0.0059793190732206018,
        -0.012605276835608293, 0.012592035031809685, 0.0193251970852042,
        0.0077760774532812989, -0.015392653585137505, 0.018961355429928297,
        -0.028300809077052, -0.022460157844348544, 0.011192561360428843,
        -0.0016653178308302288, -0.012388857690229817, 0.01263328622643423,
        -0.0048951717107396254, -0.042910847150704375, -0.021232459818053915,
        -0.014504638928902795, -0.0062305327144025072, -0.012878341916246459,
        -0.011473360705187037, 0.0065734687815719979, -0.0030936413719386611,
        0.0041099275580307312, 0.010280378539881358, 0.030474368065192541,
        -0.00065196823422589709, 0.00395291710758381, 0.0065350956061044933,
        0.017590376083896866, -0.022931941063869671, 0.019128423777239348,
        -0.0095129665445948253, -0.013245438750061875, 0.0067916666614841366,
        0.010972211454391327, -0.025273142934224814, -0.014471561538933716,
        0.015417083505133858, -0.00083743935290770278, -0.011527734820277157,
        -0.0029012466476496203, 0.029193929925598029, 0.0084349210852920718,
        -0.0038520338122005251, 0.0020119858846404941, 0.0056602651562688705,
        0.0089773913409118521, 0.033578299062070945, -0.00028822465334923014,
        0.00060328479216208131, -0.019204590974891928, 0.016152639294939434,
        0.0071178306349516359, 0.017961278343287576, 0.0096899705065884422,
        0.020327942159082693, 0.0038501359129164319, -0.0070909914573790726,
        -0.00029716644713644513, 0.023716782310077403, 0.019528925379039816,
        0.00079844493918787736, 0.0070988027829033649, -0.0084180765434620948,
        0.016083506631342576, -0.0045924216366215534, -0.011142612111522147,
        -0.002888176816865008, -0.00802537064633478, 0.012766805851510637,
        -0.020198639394994649, -0.0097083720639130951, -0.0091676464508220964,
        0.00435884056013626, 0.013915611244386256, -0.013481596250711488,
        0.014337918372558649, -0.019404586463669288, 0.0098214668758865552,
        -0.021056718189873844, -6.7614524033604955E-5, 0.013920410191938721,
        -0.0012444533110068793, -0.0040703287925533327, 0.0066164411107134608,
        0.014974333383922839, 0.0020554198413561338, 0.0028486968111954818,
        -0.011394150631827239, -0.027818461693824466, -0.0077734577488767654,
        0.0049236040804607256, 0.0020032842971943765, -0.010925444129072332,
        -0.0054961049166662047, 0.0088158408135867727, -0.0087539925161988462,
        0.01300384584270378, 0.013750681974357241, -0.026417942821240634,
        -0.0081266442587447554, 0.020910479108107258, 0.0098168108728565063,
        0.01764161752812244, -0.027626978631403558, 0.025233695603163339,
        0.010542193718773045, 0.018464955723030148, -0.0088771005876942376,
        -0.0078197398828802264, 0.008676081481760748, -0.014778982212576603,
        -0.0099216342999255136, -0.014578018656252661, -0.00077658714536532863,
        -0.012987083927544588, -0.0090609834519429222, 0.018946642862263007,
        0.015045157065683578, 0.006708955495805813, -0.00028310507157100804,
        -0.026868607494067113, -0.005148152977278061, 0.00397677173933013,
        0.022065529202473247, -0.010942753006805252, 0.026368303207209478,
        -0.018624685483749133, 0.026103464924784658, 0.0056407823290818004,
        -0.00343380422761762, -0.018799855892486585, -0.010379486000253233,
        0.0084626604614132673, -0.010996078977180969, 0.023331145495973194,
        0.021173176490147619, -0.012621099751947964, 0.0059666069414387388,
        -0.0095551466874497087, 0.01763049682847018, 0.010552065936043117,
        -0.0235417003104494, 0.021027674535218924, 0.011227475628336739,
        -0.014325270846793773, 0.0064743089203085991, -0.0021113235790818012,
        -0.023947181421117326, 0.004366820879600275, 0.00027015795217459485,
        0.002928147143792529, 0.0040119410416391789, 0.011995633089772275,
        0.0095749095502177788, 0.0026711527621116919, 0.026968279318860644,
        -0.017340029164722735, 0.016107031952301287, 0.021484374634796546,
        0.011107005940754857, -0.0038387692687362213, 0.013346087574324653,
        0.0050152194694508693, -0.00070286148200660113, 0.0065410905186553568,
        0.013551728193680333, -0.031463161842818277, -0.002110052375679356,
        -0.006056030488751093, 0.010901626520437193, -0.0040180202919192134,
        0.00139063077213079, 0.0016082106577239631, 0.0040733006295044913,
        -0.015109673952605096, 0.017318680377902424, -0.012378860685477245,
        -0.013014801428912381, -0.025499076864863943, -0.012420422819569087,
        0.00030263865313142078, -0.0019691900616251655, 0.0060079994935423008,
        -0.002611435060640399, 0.030088779710346191, 0.011032616059908081,
        -0.0080118760788806358, 0.030316702378155532, 0.00039940075457293794,
        -0.00062199231715660906, 0.013902232398568188, 0.015365759258540331,
        0.019234763839184012, 0.00955593285013652, -0.027122752855659227,
        0.013816104117962422, -0.0077266967692022339, -0.010055423397056583,
        0.0075890470326120205, 0.0030718592407111738, -0.014525417622050537,
        0.023989189854599132, -0.025426244762906992, 0.0049107930699610839,
        0.034167991056854592, -0.020292061026623013, 0.007931045052180544,
        -0.0098201000738324749, 0.0053120494846653366, -0.0054531474425964892,
        -0.032684991012887576, 0.0016576777024524406, 0.0042867000048820757,
        0.0084514957111480066, -0.0033564663822261706, 0.014886320335569357,
        0.027907586703399035, 0.0060427601901836686, -0.020732900002552995,
        -0.028364085358253192, -0.0073589236047119566, -0.0063247825572223821,
        0.013902088787738812, -0.010149899462971059, 0.0089484392443958,
        -0.011637354780539252, 0.023110073721109386, 0.014101398298792464,
        -0.0061543160019334334, 0.0089333438524918148, 0.013703435846692761,
        0.010195124635655162, 0.015326067399257955, 0.0055545682398188941,
        -0.034806515719448164, -0.0041655120378532853, -0.006071922631655664,
        -0.016990639436043575, 0.00960071796618779, -0.0014932841242445974,
        0.012403645218437958, -0.022100315930147996, 0.01170728470701575,
        0.006053043326788193, -0.0028965731128382127, -0.015295570203066901,
        0.0027111013548173106, -0.009317607503347097, -0.0044275077996890448,
        -0.00013819389241728506, -0.016027698071705475, 0.0015703656308963105,
        0.0061521956029135759, 0.0024652990419707075, 0.0054272139308849067,
        0.022785525212254052, -0.014889598450359412, -0.01252901969428321,
        -0.00029986472187008676, -0.033006598408008736, 0.015452469486149355,
        0.03140973827615702, -0.0067830258378828523, 0.0012766711399865298,
        -0.00813744710530078, 0.00809165333454218, 0.016391625927173907,
        -0.015510423358502346, -0.004895042274954969, 0.0012440063744654554,
        -0.0011142298498259258, 0.0053543217657067614, -0.0015075798777473683,
        0.018012801453393991, -0.017057939529644055, 0.010294658318733722,
        -0.0019717253461941694, 0.031465427156287175, 0.0053636403447456325,
        0.018700403757107634, -0.040215110423038158, 0.0075923880036712693,
        -0.008546251829529913, -0.014408769111399513, 0.0089849357652853623,
        0.0064581519232847929, -0.016416745527083748, 0.012505244609778102,
        -0.020993821982514829, -0.0101199838202945, -0.016430608182581553,
        -0.0014444637689372097, 0.011138240723347986, -0.0072471296147392193,
        0.0023879030864215412, -0.00086417635209278172, -0.02099687886444113,
        -0.00077414829374111813, 0.0089806512814890431, 0.0013761550060400805,
        0.0017882830217159471, 0.013512044076921569, 0.00055633966496365021,
        0.0010599323887105357, -0.0064797149222610793, 0.0035873837237929891,
        0.016551428888803343, 0.011332614618193721, -0.0047825420545592589,
        0.0037818195274386167, -0.031578335216407939, -0.025870917638113163,
        0.015902671761643474, 0.00057669959501837015, 0.0064831192295961623,
        -0.024642699697047715, 0.0049361436627967138, 0.012339234714400406,
        -0.0057458600032989342, 0.024744892758821413, -0.0060347399400733914,
        -0.0017727719543939558, 0.019778763845118039, -0.0063841870124767448,
        0.0035168176112569203, 0.021745978040826067, 0.036469723249254384,
        0.03020396886499345, -0.022693872263818759, 0.0059529714426103377,
        -0.027834331440092289, 0.028955883845445823, 0.011481974886327444,
        -0.0022797971196413924, 0.014990783925671226, 0.02084657241059492,
        0.009666741865220348, -0.017504266663738267, 0.0055325006161188219,
        -0.0071196271391368538, 0.0051653005714752467, 0.017542340603087042,
        0.008319177152008474, -0.0018628582748523401, 0.025652390504981509,
        0.0035321104022140184, 0.024094647200102154, 0.03605782290583371,
        0.00741713252605771, 0.015118642573661438, 0.029340584889462909,
        -0.016263429833632558, -0.011436932341232772, 0.0036576609251943244,
        -0.012167466469851236, 0.0018450284304378037, -0.0061840662591815835,
        -0.017280142226316051, -0.0048428229871760086, -0.00757778731357165,
        0.029895280180059755, 0.01460768542244208, 0.0070190548045756321,
        -0.001095608871848253, -0.001021979909506292, -0.017229599694573414,
        -0.026931523577029028, 0.010563422876323699, -0.0036670633203375628,
        0.0086935726879527712, -0.0035367826162642723, 0.013630733601280363,
        0.013294274383844685, 0.027252156728203764, 0.031680295099834964,
        -0.0056875839796279104, -0.036383455113412511, -0.016641396816860398,
        0.026659681010452123, 0.0065317708488546681, -0.0078963296142955629,
        0.0054835007197571, 0.019849320824055845, 0.0015511309950194732,
        -0.00801718977481245, -0.0060643843228890635, 0.018040397807473449,
        0.0049885734800994147, 0.005399867711815714, -0.00028680612312387412,
        0.0038586998652956235, 0.020406747891271643, -0.014574406872819438,
        0.030500764634416214, 0.0054077092477865189, -0.0046372854998416608,
        -0.042769944008921069, 0.0016580120923716921, 0.00929551084621051,
        0.0068855515292257936, -0.01576262722128886, -0.010517551133159803,
        -0.0084528776836444355, -0.019041333987724913, 0.0016123140883564911,
        -0.011980293010116378, 0.00986333240075282, 0.0029697589328645927,
        0.00994369105908122, 0.0059793190732206018, 0.012605276835608293,
        -0.012592035031809685, -0.0193251970852042, -0.0077760774532812989,
        0.015392653585137505, -0.018961355429928297, 0.028300809077052,
        0.022460157844348544, -0.011192561360428843, 0.0016653178308302288,
        0.012388857690229817, -0.01263328622643423, 0.0048951717107396254,
        0.042910847150704375, 0.021232459818053915, 0.014504638928902795,
        0.0062305327144025072, 0.012878341916246459, 0.011473360705187037,
        -0.0065734687815719979, 0.0030936413719386611, -0.0041099275580307312,
        -0.010280378539881358, -0.030474368065192541, 0.00065196823422589709,
        -0.00395291710758381, -0.0065350956061044933, -0.017590376083896866,
        0.022931941063869671, -0.019128423777239348, 0.0095129665445948253,
        0.013245438750061875, -0.0067916666614841366, -0.010972211454391327,
        0.025273142934224814, 0.014471561538933716, -0.015417083505133858,
        0.00083743935290770278, 0.011527734820277157, 0.0029012466476496203,
        -0.029193929925598029, -0.0084349210852920718, 0.0038520338122005251,
        -0.0020119858846404941, -0.0056602651562688705, -0.0089773913409118521,
        -0.033578299062070945, 0.00028822465334923014, -0.00060328479216208131,
        0.019204590974891928, -0.016152639294939434, -0.0071178306349516359,
        -0.017961278343287576, -0.0096899705065884422, -0.020327942159082693,
        -0.0038501359129164319, 0.0070909914573790726, 0.00029716644713644513,
        -0.023716782310077403, -0.019528925379039816, -0.00079844493918787736,
        -0.0070988027829033649, 0.0084180765434620948, -0.016083506631342576,
        0.0045924216366215534, 0.011142612111522147, 0.002888176816865008,
        0.00802537064633478, -0.012766805851510637, 0.020198639394994649,
        0.0097083720639130951, 0.0091676464508220964, -0.00435884056013626,
        -0.013915611244386256, 0.013481596250711488, -0.014337918372558649,
        0.019404586463669288, -0.0098214668758865552, 0.021056718189873844,
        6.7614524033604955E-5, -0.013920410191938721, 0.0012444533110068793,
        0.0040703287925533327, -0.0066164411107134608, -0.014974333383922839,
        -0.0020554198413561338, -0.0028486968111954818, 0.011394150631827239,
        0.027818461693824466, 0.0077734577488767654, -0.0049236040804607256,
        -0.0020032842971943765, 0.010925444129072332, 0.0054961049166662047,
        -0.0088158408135867727, 0.0087539925161988462, -0.01300384584270378,
        -0.013750681974357241, 0.026417942821240634, 0.0081266442587447554,
        -0.020910479108107258, -0.0098168108728565063, -0.01764161752812244,
        0.027626978631403558, -0.025233695603163339, -0.010542193718773045,
        -0.018464955723030148, 0.0088771005876942376, 0.0078197398828802264,
        -0.008676081481760748, 0.014778982212576603, 0.0099216342999255136,
        0.014578018656252661, 0.00077658714536532863, 0.012987083927544588,
        0.0090609834519429222, -0.018946642862263007, -0.015045157065683578,
        -0.006708955495805813, 0.00028310507157100804, 0.026868607494067113,
        0.005148152977278061, -0.00397677173933013, -0.022065529202473247,
        0.010942753006805252, -0.026368303207209478, 0.018624685483749133,
        -0.026103464924784658, -0.0056407823290818004, 0.00343380422761762,
        0.018799855892486585, 0.010379486000253233, -0.0084626604614132673,
        0.010996078977180969, -0.023331145495973194, -0.021173176490147619,
        0.012621099751947964, -0.0059666069414387388, 0.0095551466874497087,
        -0.01763049682847018, -0.010552065936043117, 0.0235417003104494,
        -0.021027674535218924, -0.011227475628336739, 0.014325270846793773,
        -0.0064743089203085991, 0.0021113235790818012, 0.023947181421117326,
        -0.004366820879600275, -0.00027015795217459485, -0.002928147143792529,
        -0.0040119410416391789, -0.011995633089772275, -0.0095749095502177788,
        -0.0026711527621116919, -0.026968279318860644, 0.017340029164722735,
        -0.016107031952301287, -0.021484374634796546, -0.011107005940754857,
        0.0038387692687362213, -0.013346087574324653, -0.0050152194694508693,
        0.00070286148200660113, -0.0065410905186553568, -0.013551728193680333,
        0.031463161842818277, 0.002110052375679356, 0.006056030488751093,
        -0.010901626520437193, 0.0040180202919192134, -0.00139063077213079,
        -0.0016082106577239631, -0.0040733006295044913, 0.015109673952605096,
        -0.017318680377902424, 0.012378860685477245, 0.013014801428912381,
        0.025499076864863943, 0.012420422819569087, -0.00030263865313142078,
        0.0019691900616251655, -0.0060079994935423008, 0.002611435060640399,
        -0.030088779710346191, -0.011032616059908081, 0.0080118760788806358,
        -0.030316702378155532, -0.00039940075457293794, 0.00062199231715660906,
        -0.013902232398568188, -0.015365759258540331, -0.019234763839184012,
        -0.00955593285013652, 0.027122752855659227, -0.013816104117962422,
        0.0077266967692022339, 0.010055423397056583, -0.0075890470326120205,
        -0.0030718592407111738, 0.014525417622050537, -0.023989189854599132,
        0.025426244762906992, -0.0049107930699610839, -0.034167991056854592,
        0.020292061026623013, -0.007931045052180544, 0.0098201000738324749,
        -0.0053120494846653366, 0.0054531474425964892, 0.032684991012887576,
        -0.0016576777024524406, -0.0042867000048820757, -0.0084514957111480066,
        0.0033564663822261706, -0.014886320335569357, -0.027907586703399035,
        -0.0060427601901836686, 0.020732900002552995, 0.028364085358253192,
        0.0073589236047119566, 0.0063247825572223821, -0.013902088787738812,
        0.010149899462971059, -0.0089484392443958, 0.011637354780539252,
        -0.023110073721109386, -0.014101398298792464, 0.0061543160019334334,
        -0.0089333438524918148, -0.013703435846692761, -0.010195124635655162,
        -0.015326067399257955, -0.0055545682398188941, 0.034806515719448164,
        0.0041655120378532853, 0.006071922631655664, 0.016990639436043575,
        -0.00960071796618779, 0.0014932841242445974, -0.012403645218437958,
        0.022100315930147996, -0.01170728470701575, -0.006053043326788193,
        0.0028965731128382127, 0.015295570203066901, -0.0027111013548173106,
        0.009317607503347097, 0.0044275077996890448, 0.00013819389241728506,
        0.016027698071705475, -0.0015703656308963105, -0.0061521956029135759,
        -0.0024652990419707075, -0.0054272139308849067, -0.022785525212254052,
        0.014889598450359412, 0.01252901969428321, 0.00029986472187008676,
        0.033006598408008736, -0.015452469486149355, -0.03140973827615702,
        0.0067830258378828523, -0.0012766711399865298, 0.00813744710530078,
        -0.00809165333454218, -0.016391625927173907, 0.015510423358502346,
        0.004895042274954969, -0.0012440063744654554, 0.0011142298498259258,
        -0.0053543217657067614, 0.0015075798777473683, -0.018012801453393991,
        0.017057939529644055, -0.010294658318733722, 0.0019717253461941694,
        -0.031465427156287175, -0.0053636403447456325, -0.018700403757107634,
        0.040215110423038158, -0.0075923880036712693, 0.008546251829529913,
        0.014408769111399513, -0.0089849357652853623, -0.0064581519232847929,
        0.016416745527083748, -0.012505244609778102, 0.020993821982514829,
        0.0101199838202945, 0.016430608182581553, 0.0014444637689372097,
        -0.011138240723347986, 0.0072471296147392193, -0.0023879030864215412,
        0.00086417635209278172, 0.02099687886444113, 0.00077414829374111813,
        -0.0089806512814890431, -0.0013761550060400805, -0.0017882830217159471,
        -0.013512044076921569, -0.00055633966496365021, -0.0010599323887105357,
        0.0064797149222610793, -0.0035873837237929891, -0.016551428888803343,
        -0.011332614618193721, 0.0047825420545592589, -0.0037818195274386167,
        0.031578335216407939, 0.025870917638113163, -0.015902671761643474,
        -0.00057669959501837015, -0.0064831192295961623, 0.024642699697047715,
        -0.0049361436627967138, -0.012339234714400406, 0.0057458600032989342,
        -0.024744892758821413, 0.0060347399400733914, 0.0017727719543939558,
        -0.019778763845118039, 0.0063841870124767448, -0.0035168176112569203,
        -0.021745978040826067, -0.036469723249254384, -0.03020396886499345,
        0.022693872263818759, -0.0059529714426103377, 0.027834331440092289,
        -0.028955883845445823, -0.011481974886327444, 0.0022797971196413924,
        -0.014990783925671226, -0.02084657241059492, -0.009666741865220348,
        0.017504266663738267, -0.0055325006161188219, 0.0071196271391368538,
        -0.0051653005714752467, -0.017542340603087042, -0.008319177152008474,
        0.0018628582748523401, -0.025652390504981509, -0.0035321104022140184,
        -0.024094647200102154, -0.03605782290583371, -0.00741713252605771,
        -0.015118642573661438, -0.029340584889462909, 0.016263429833632558,
        0.011436932341232772, -0.0036576609251943244, 0.012167466469851236,
        -0.0018450284304378037, 0.0061840662591815835, 0.017280142226316051,
        0.0048428229871760086, 0.00757778731357165, -0.029895280180059755,
        -0.01460768542244208, -0.0070190548045756321, 0.001095608871848253,
        0.001021979909506292, 0.017229599694573414, 0.026931523577029028,
        -0.010563422876323699, 0.0036670633203375628, -0.0086935726879527712,
        0.0035367826162642723, -0.013630733601280363, -0.013294274383844685,
        -0.027252156728203764, -0.031680295099834964, 0.0056875839796279104,
        0.036383455113412511, 0.016641396816860398, -0.026659681010452123,
        -0.0065317708488546681, 0.0078963296142955629, -0.0054835007197571,
        -0.019849320824055845, -0.0015511309950194732, 0.00801718977481245,
        0.0060643843228890635, -0.018040397807473449, -0.0049885734800994147,
        -0.005399867711815714, 0.00028680612312387412, -0.0038586998652956235,
        -0.020406747891271643, 0.014574406872819438, -0.030500764634416214,
        -0.0054077092477865189, 0.0046372854998416608, 0.042769944008921069,
        -0.0016580120923716921, -0.00929551084621051, -0.0068855515292257936,
        0.01576262722128886, 0.010517551133159803, 0.0084528776836444355,
        0.019041333987724913, -0.0016123140883564911, 0.011980293010116378,
        -0.00986333240075282, -0.0029697589328645927, -0.00994369105908122,
        -0.0059793190732206018, -0.012605276835608293, 0.012592035031809685,
        0.0193251970852042, 0.0077760774532812989, -0.015392653585137505,
        0.018961355429928297, -0.028300809077052, -0.022460157844348544,
        0.011192561360428843, -0.0016653178308302288, -0.012388857690229817,
        0.01263328622643423, -0.0048951717107396254, -0.042910847150704375,
        -0.021232459818053915, -0.014504638928902795, -0.0062305327144025072,
        -0.012878341916246459, -0.011473360705187037, 0.0065734687815719979,
        -0.0030936413719386611, 0.0041099275580307312, 0.010280378539881358,
        0.030474368065192541, -0.00065196823422589709, 0.00395291710758381,
        0.0065350956061044933, 0.017590376083896866, -0.022931941063869671,
        0.019128423777239348, -0.0095129665445948253, -0.013245438750061875,
        0.0067916666614841366, 0.010972211454391327, -0.025273142934224814,
        -0.014471561538933716, 0.015417083505133858, -0.00083743935290770278,
        -0.011527734820277157, -0.0029012466476496203, 0.029193929925598029,
        0.0084349210852920718, -0.0038520338122005251, 0.0020119858846404941,
        0.0056602651562688705, 0.0089773913409118521, 0.033578299062070945,
        -0.00028822465334923014, 0.00060328479216208131, -0.019204590974891928,
        0.016152639294939434, 0.0071178306349516359, 0.017961278343287576,
        0.0096899705065884422, 0.020327942159082693, 0.0038501359129164319,
        -0.0070909914573790726, -0.00029716644713644513, 0.023716782310077403,
        0.019528925379039816, 0.00079844493918787736, 0.0070988027829033649,
        -0.0084180765434620948, 0.016083506631342576, -0.0045924216366215534,
        -0.011142612111522147, -0.002888176816865008, -0.00802537064633478,
        0.012766805851510637, -0.020198639394994649, -0.0097083720639130951,
        -0.0091676464508220964, 0.00435884056013626, 0.013915611244386256,
        -0.013481596250711488, 0.014337918372558649, -0.019404586463669288,
        0.0098214668758865552, -0.021056718189873844, -6.7614524033604955E-5,
        0.013920410191938721, -0.0012444533110068793, -0.0040703287925533327,
        0.0066164411107134608, 0.014974333383922839, 0.0020554198413561338,
        0.0028486968111954818, -0.011394150631827239, -0.027818461693824466,
        -0.0077734577488767654, 0.0049236040804607256, 0.0020032842971943765,
        -0.010925444129072332, -0.0054961049166662047, 0.0088158408135867727,
        -0.0087539925161988462, 0.01300384584270378, 0.013750681974357241,
        -0.026417942821240634, -0.0081266442587447554, 0.020910479108107258,
        0.0098168108728565063, 0.01764161752812244, -0.027626978631403558,
        0.025233695603163339, 0.010542193718773045, 0.018464955723030148,
        -0.0088771005876942376, -0.0078197398828802264, 0.008676081481760748,
        -0.014778982212576603, -0.0099216342999255136, -0.014578018656252661,
        -0.00077658714536532863, -0.012987083927544588, -0.0090609834519429222,
        0.018946642862263007, 0.015045157065683578, 0.006708955495805813,
        -0.00028310507157100804, -0.026868607494067113, -0.005148152977278061,
        0.00397677173933013, 0.022065529202473247, -0.010942753006805252,
        0.026368303207209478, -0.018624685483749133, 0.026103464924784658,
        0.0056407823290818004, -0.00343380422761762, -0.018799855892486585,
        -0.010379486000253233, 0.0084626604614132673, -0.010996078977180969,
        0.023331145495973194, 0.021173176490147619, -0.012621099751947964,
        0.0059666069414387388, -0.0095551466874497087, 0.01763049682847018,
        0.010552065936043117, -0.0235417003104494, 0.021027674535218924,
        0.011227475628336739, -0.014325270846793773, 0.0064743089203085991,
        -0.0021113235790818012, -0.023947181421117326, 0.004366820879600275,
        0.00027015795217459485, 0.002928147143792529, 0.0040119410416391789,
        0.011995633089772275, 0.0095749095502177788, 0.0026711527621116919,
        0.026968279318860644, -0.017340029164722735, 0.016107031952301287,
        0.021484374634796546, 0.011107005940754857, -0.0038387692687362213,
        0.013346087574324653, 0.0050152194694508693, -0.00070286148200660113,
        0.0065410905186553568, 0.013551728193680333, -0.031463161842818277,
        -0.002110052375679356, -0.006056030488751093, 0.010901626520437193,
        -0.0040180202919192134, 0.00139063077213079, 0.0016082106577239631,
        0.0040733006295044913, -0.015109673952605096, 0.017318680377902424,
        -0.012378860685477245, -0.013014801428912381, -0.025499076864863943,
        -0.012420422819569087, 0.00030263865313142078, -0.0019691900616251655,
        0.0060079994935423008, -0.002611435060640399, 0.030088779710346191,
        0.011032616059908081, -0.0080118760788806358, 0.030316702378155532,
        0.00039940075457293794, -0.00062199231715660906, 0.013902232398568188,
        0.015365759258540331, 0.019234763839184012, 0.00955593285013652,
        -0.027122752855659227, 0.013816104117962422, -0.0077266967692022339,
        -0.010055423397056583, 0.0075890470326120205, 0.0030718592407111738,
        -0.014525417622050537, 0.023989189854599132, -0.025426244762906992,
        0.0049107930699610839, 0.034167991056854592, -0.020292061026623013,
        0.007931045052180544, -0.0098201000738324749, 0.0053120494846653366,
        -0.0054531474425964892, -0.032684991012887576, 0.0016576777024524406,
        0.0042867000048820757, 0.0084514957111480066, -0.0033564663822261706,
        0.014886320335569357, 0.027907586703399035, 0.0060427601901836686,
        -0.020732900002552995, -0.028364085358253192, -0.0073589236047119566,
        -0.0063247825572223821, 0.013902088787738812, -0.010149899462971059,
        0.0089484392443958, -0.011637354780539252, 0.023110073721109386,
        0.014101398298792464, -0.0061543160019334334, 0.0089333438524918148,
        0.013703435846692761, 0.010195124635655162, 0.015326067399257955,
        0.0055545682398188941, -0.034806515719448164, -0.0041655120378532853,
        -0.006071922631655664, -0.016990639436043575, 0.00960071796618779,
        -0.0014932841242445974, 0.012403645218437958, -0.022100315930147996,
        0.01170728470701575, 0.006053043326788193, -0.0028965731128382127,
        -0.015295570203066901, 0.0027111013548173106, -0.009317607503347097,
        -0.0044275077996890448, -0.00013819389241728506, -0.016027698071705475,
        0.0015703656308963105, 0.0061521956029135759, 0.0024652990419707075,
        0.0054272139308849067, 0.022785525212254052, -0.014889598450359412,
        -0.01252901969428321, -0.00029986472187008676, -0.033006598408008736,
        0.015452469486149355, 0.03140973827615702, -0.0067830258378828523,
        0.0012766711399865298, -0.00813744710530078, 0.00809165333454218,
        0.016391625927173907, -0.015510423358502346, -0.004895042274954969,
        0.0012440063744654554, -0.0011142298498259258, 0.0053543217657067614,
        -0.0015075798777473683, 0.018012801453393991, -0.017057939529644055,
        0.010294658318733722, -0.0019717253461941694, 0.031465427156287175,
        0.0053636403447456325, 0.018700403757107634, -0.040215110423038158,
        0.0075923880036712693, -0.008546251829529913, -0.014408769111399513,
        0.0089849357652853623, 0.0064581519232847929, -0.016416745527083748,
        0.012505244609778102, -0.020993821982514829, -0.0101199838202945,
        -0.016430608182581553, -0.0014444637689372097, 0.011138240723347986,
        -0.0072471296147392193, 0.0023879030864215412, -0.00086417635209278172,
        -0.02099687886444113, -0.00077414829374111813, 0.0089806512814890431,
        0.0013761550060400805, 0.0017882830217159471, 0.013512044076921569,
        0.00055633966496365021, 0.0010599323887105357, -0.0064797149222610793,
        0.0035873837237929891, 0.016551428888803343, 0.011332614618193721,
        -0.0047825420545592589, 0.0037818195274386167, -0.031578335216407939,
        -0.025870917638113163, 0.015902671761643474, 0.00057669959501837015,
        0.0064831192295961623, -0.024642699697047715, 0.0049361436627967138,
        0.012339234714400406, -0.0057458600032989342, 0.024744892758821413,
        -0.0060347399400733914, -0.0017727719543939558, 0.019778763845118039,
        -0.0063841870124767448, 0.0035168176112569203, 0.021745978040826067,
        0.036469723249254384, 0.03020396886499345, -0.022693872263818759,
        0.0059529714426103377, -0.027834331440092289, 0.028955883845445823,
        0.011481974886327444, -0.0022797971196413924, 0.014990783925671226,
        0.02084657241059492, 0.009666741865220348, -0.017504266663738267,
        0.0055325006161188219, -0.0071196271391368538, 0.0051653005714752467,
        0.017542340603087042, 0.008319177152008474, -0.0018628582748523401,
        0.025652390504981509, 0.0035321104022140184, 0.024094647200102154,
        0.03605782290583371, 0.00741713252605771, 0.015118642573661438,
        0.029340584889462909, -0.016263429833632558, -0.011436932341232772,
        0.0036576609251943244, -0.012167466469851236, 0.0018450284304378037,
        -0.0061840662591815835, -0.017280142226316051, -0.0048428229871760086,
        -0.00757778731357165, 0.029895280180059755, 0.01460768542244208,
        0.0070190548045756321, -0.001095608871848253, -0.001021979909506292,
        -0.017229599694573414, -0.026931523577029028, 0.010563422876323699,
        -0.0036670633203375628, 0.0086935726879527712, -0.0035367826162642723,
        0.013630733601280363, 0.013294274383844685, 0.027252156728203764,
        0.031680295099834964, -0.0056875839796279104, -0.036383455113412511,
        -0.016641396816860398, 0.026659681010452123, 0.0065317708488546681,
        -0.0078963296142955629, 0.0054835007197571, 0.019849320824055845,
        0.0015511309950194732, -0.00801718977481245, -0.0060643843228890635,
        0.018040397807473449, 0.0049885734800994147, 0.005399867711815714,
        -0.00028680612312387412, 0.0038586998652956235, 0.020406747891271643,
        -0.014574406872819438, 0.030500764634416214, 0.0054077092477865189,
        -0.0046372854998416608, -0.042769944008921069, 0.0016580120923716921,
        0.00929551084621051, 0.0068855515292257936, -0.01576262722128886,
        -0.010517551133159803, -0.0084528776836444355, -0.019041333987724913,
        0.0016123140883564911, -0.011980293010116378, 0.00986333240075282,
        0.0029697589328645927, 0.00994369105908122, 0.0059793190732206018,
        0.012605276835608293, -0.012592035031809685, -0.0193251970852042,
        -0.0077760774532812989, 0.015392653585137505, -0.018961355429928297,
        0.028300809077052, 0.022460157844348544, -0.011192561360428843,
        0.0016653178308302288, 0.012388857690229817, -0.01263328622643423,
        0.0048951717107396254, 0.042910847150704375, 0.021232459818053915,
        0.014504638928902795, 0.0062305327144025072, 0.012878341916246459,
        0.011473360705187037, -0.0065734687815719979, 0.0030936413719386611,
        -0.0041099275580307312, -0.010280378539881358, -0.030474368065192541,
        0.00065196823422589709, -0.00395291710758381, -0.0065350956061044933,
        -0.017590376083896866, 0.022931941063869671, -0.019128423777239348,
        0.0095129665445948253, 0.013245438750061875, -0.0067916666614841366,
        -0.010972211454391327, 0.025273142934224814, 0.014471561538933716,
        -0.015417083505133858, 0.00083743935290770278, 0.011527734820277157,
        0.0029012466476496203, -0.029193929925598029, -0.0084349210852920718,
        0.0038520338122005251, -0.0020119858846404941, -0.0056602651562688705,
        -0.0089773913409118521, -0.033578299062070945, 0.00028822465334923014,
        -0.00060328479216208131, 0.019204590974891928, -0.016152639294939434,
        -0.0071178306349516359, -0.017961278343287576, -0.0096899705065884422,
        -0.020327942159082693, -0.0038501359129164319, 0.0070909914573790726,
        0.00029716644713644513, -0.023716782310077403, -0.019528925379039816,
        -0.00079844493918787736, -0.0070988027829033649, 0.0084180765434620948,
        -0.016083506631342576, 0.0045924216366215534, 0.011142612111522147,
        0.002888176816865008, 0.00802537064633478, -0.012766805851510637,
        0.020198639394994649, 0.0097083720639130951, 0.0091676464508220964,
        -0.00435884056013626, -0.013915611244386256, 0.013481596250711488,
        -0.014337918372558649, 0.019404586463669288, -0.0098214668758865552,
        0.021056718189873844, 6.7614524033604955E-5, -0.013920410191938721,
        0.0012444533110068793, 0.0040703287925533327, -0.0066164411107134608,
        -0.014974333383922839, -0.0020554198413561338, -0.0028486968111954818,
        0.011394150631827239, 0.027818461693824466, 0.0077734577488767654,
        -0.0049236040804607256, -0.0020032842971943765, 0.010925444129072332,
        0.0054961049166662047, -0.0088158408135867727, 0.0087539925161988462,
        -0.01300384584270378, -0.013750681974357241, 0.026417942821240634,
        0.0081266442587447554, -0.020910479108107258, -0.0098168108728565063,
        -0.01764161752812244, 0.027626978631403558, -0.025233695603163339,
        -0.010542193718773045, -0.018464955723030148, 0.0088771005876942376,
        0.0078197398828802264, -0.008676081481760748, 0.014778982212576603,
        0.0099216342999255136, 0.014578018656252661, 0.00077658714536532863,
        0.012987083927544588, 0.0090609834519429222, -0.018946642862263007,
        -0.015045157065683578, -0.006708955495805813, 0.00028310507157100804,
        0.026868607494067113, 0.005148152977278061, -0.00397677173933013,
        -0.022065529202473247, 0.010942753006805252, -0.026368303207209478,
        0.018624685483749133, -0.026103464924784658, -0.0056407823290818004,
        0.00343380422761762, 0.018799855892486585, 0.010379486000253233,
        -0.0084626604614132673, 0.010996078977180969, -0.023331145495973194,
        -0.021173176490147619, 0.012621099751947964, -0.0059666069414387388,
        0.0095551466874497087, -0.01763049682847018, -0.010552065936043117,
        0.0235417003104494, -0.021027674535218924, -0.011227475628336739,
        0.014325270846793773, -0.0064743089203085991, 0.0021113235790818012,
        0.023947181421117326, -0.004366820879600275, -0.00027015795217459485,
        -0.002928147143792529, -0.0040119410416391789, -0.011995633089772275,
        -0.0095749095502177788, -0.0026711527621116919, -0.026968279318860644,
        0.017340029164722735, -0.016107031952301287, -0.021484374634796546,
        -0.011107005940754857, 0.0038387692687362213, -0.013346087574324653,
        -0.0050152194694508693, 0.00070286148200660113, -0.0065410905186553568,
        -0.013551728193680333, 0.031463161842818277, 0.002110052375679356,
        0.006056030488751093, -0.010901626520437193, 0.0040180202919192134,
        -0.00139063077213079, -0.0016082106577239631, -0.0040733006295044913,
        0.015109673952605096, -0.017318680377902424, 0.012378860685477245,
        0.013014801428912381, 0.025499076864863943, 0.012420422819569087,
        -0.00030263865313142078, 0.0019691900616251655, -0.0060079994935423008,
        0.002611435060640399, -0.030088779710346191, -0.011032616059908081,
        0.0080118760788806358, -0.030316702378155532, -0.00039940075457293794,
        0.00062199231715660906, -0.013902232398568188, -0.015365759258540331,
        -0.019234763839184012, -0.00955593285013652, 0.027122752855659227,
        -0.013816104117962422, 0.0077266967692022339, 0.010055423397056583,
        -0.0075890470326120205, -0.0030718592407111738, 0.014525417622050537,
        -0.023989189854599132, 0.025426244762906992, -0.0049107930699610839,
        -0.034167991056854592, 0.020292061026623013, -0.007931045052180544,
        0.0098201000738324749, -0.0053120494846653366, 0.0054531474425964892,
        0.032684991012887576, -0.0016576777024524406, -0.0042867000048820757,
        -0.0084514957111480066, 0.0033564663822261706, -0.014886320335569357,
        -0.027907586703399035, -0.0060427601901836686, 0.020732900002552995,
        0.028364085358253192, 0.0073589236047119566, 0.0063247825572223821,
        -0.013902088787738812, 0.010149899462971059, -0.0089484392443958,
        0.011637354780539252, -0.023110073721109386, -0.014101398298792464,
        0.0061543160019334334, -0.0089333438524918148, -0.013703435846692761,
        -0.010195124635655162, -0.015326067399257955, -0.0055545682398188941,
        0.034806515719448164, 0.0041655120378532853, 0.006071922631655664,
        0.016990639436043575, -0.00960071796618779, 0.0014932841242445974,
        -0.012403645218437958, 0.022100315930147996, -0.01170728470701575,
        -0.006053043326788193, 0.0028965731128382127, 0.015295570203066901,
        -0.0027111013548173106, 0.009317607503347097, 0.0044275077996890448,
        0.00013819389241728506, 0.016027698071705475, -0.0015703656308963105,
        -0.0061521956029135759, -0.0024652990419707075, -0.0054272139308849067,
        -0.022785525212254052, 0.014889598450359412, 0.01252901969428321,
        0.00029986472187008676, 0.033006598408008736, -0.015452469486149355,
        -0.03140973827615702, 0.0067830258378828523, -0.0012766711399865298,
        0.00813744710530078, -0.00809165333454218, -0.016391625927173907,
        0.015510423358502346, 0.004895042274954969, -0.0012440063744654554,
        0.0011142298498259258, -0.0053543217657067614, 0.0015075798777473683,
        -0.018012801453393991, 0.017057939529644055, -0.010294658318733722,
        0.0019717253461941694, -0.031465427156287175, -0.0053636403447456325,
        -0.018700403757107634, 0.040215110423038158, -0.0075923880036712693,
        0.008546251829529913, 0.014408769111399513, -0.0089849357652853623,
        -0.0064581519232847929, 0.016416745527083748, -0.012505244609778102,
        0.020993821982514829, 0.0101199838202945, 0.016430608182581553,
        0.0014444637689372097, -0.011138240723347986, 0.0072471296147392193,
        -0.0023879030864215412, 0.00086417635209278172, 0.02099687886444113,
        0.00077414829374111813, -0.0089806512814890431, -0.0013761550060400805,
        -0.0017882830217159471, -0.013512044076921569, -0.00055633966496365021,
        -0.0010599323887105357, 0.0064797149222610793, -0.0035873837237929891,
        -0.016551428888803343, -0.011332614618193721, 0.0047825420545592589,
        -0.0037818195274386167, 0.031578335216407939, 0.025870917638113163,
        -0.015902671761643474, -0.00057669959501837015, -0.0064831192295961623,
        0.024642699697047715, -0.0049361436627967138, -0.012339234714400406,
        0.0057458600032989342, -0.024744892758821413, 0.0060347399400733914,
        0.0017727719543939558, -0.019778763845118039, 0.0063841870124767448,
        -0.0035168176112569203, -0.021745978040826067, -0.036469723249254384,
        -0.03020396886499345, 0.022693872263818759, -0.0059529714426103377,
        0.027834331440092289, -0.028955883845445823, -0.011481974886327444,
        0.0022797971196413924, -0.014990783925671226, -0.02084657241059492,
        -0.009666741865220348, 0.017504266663738267, -0.0055325006161188219,
        0.0071196271391368538, -0.0051653005714752467, -0.017542340603087042,
        -0.008319177152008474, 0.0018628582748523401, -0.025652390504981509,
        -0.0035321104022140184, -0.024094647200102154, -0.03605782290583371,
        -0.00741713252605771, -0.015118642573661438, -0.029340584889462909,
        0.016263429833632558, 0.011436932341232772, -0.0036576609251943244,
        0.012167466469851236, -0.0018450284304378037, 0.0061840662591815835,
        0.017280142226316051, 0.0048428229871760086, 0.00757778731357165,
        -0.029895280180059755, -0.01460768542244208, -0.0070190548045756321,
        0.001095608871848253, 0.001021979909506292, 0.017229599694573414,
        0.026931523577029028, -0.010563422876323699, 0.0036670633203375628,
        -0.0086935726879527712, 0.0035367826162642723, -0.013630733601280363,
        -0.013294274383844685, -0.027252156728203764, -0.031680295099834964,
        0.0056875839796279104, 0.036383455113412511, 0.016641396816860398,
        -0.026659681010452123, -0.0065317708488546681, 0.0078963296142955629,
        -0.0054835007197571, -0.019849320824055845, -0.0015511309950194732,
        0.00801718977481245, 0.0060643843228890635, -0.018040397807473449,
        -0.0049885734800994147, -0.005399867711815714, 0.00028680612312387412,
        -0.0038586998652956235, -0.020406747891271643, 0.014574406872819438,
        -0.030500764634416214, -0.0054077092477865189, 0.0046372854998416608,
        0.042769944008921069, -0.0016580120923716921, -0.00929551084621051,
        -0.0068855515292257936, 0.01576262722128886, 0.010517551133159803,
        0.0084528776836444355, 0.019041333987724913, -0.0016123140883564911,
        0.011980293010116378, -0.00986333240075282, -0.0029697589328645927,
        -0.00994369105908122, -0.0059793190732206018, -0.012605276835608293,
        0.012592035031809685, 0.0193251970852042, 0.0077760774532812989,
        -0.015392653585137505, 0.018961355429928297, -0.028300809077052,
        -0.022460157844348544, 0.011192561360428843, -0.0016653178308302288,
        -0.012388857690229817, 0.01263328622643423, -0.0048951717107396254,
        -0.042910847150704375, -0.021232459818053915, -0.014504638928902795,
        -0.0062305327144025072, -0.012878341916246459, -0.011473360705187037,
        0.0065734687815719979, -0.0030936413719386611, 0.0041099275580307312,
        0.010280378539881358, 0.030474368065192541, -0.00065196823422589709,
        0.00395291710758381, 0.0065350956061044933, 0.017590376083896866,
        -0.022931941063869671, 0.019128423777239348, -0.0095129665445948253,
        -0.013245438750061875, 0.0067916666614841366, 0.010972211454391327,
        -0.025273142934224814, -0.014471561538933716, 0.015417083505133858,
        -0.00083743935290770278, -0.011527734820277157, -0.0029012466476496203,
        0.029193929925598029, 0.0084349210852920718, -0.0038520338122005251,
        0.0020119858846404941, 0.0056602651562688705, 0.0089773913409118521,
        0.033578299062070945, -0.00028822465334923014, 0.00060328479216208131,
        -0.019204590974891928, 0.016152639294939434, 0.0071178306349516359,
        0.017961278343287576, 0.0096899705065884422, 0.020327942159082693,
        0.0038501359129164319, -0.0070909914573790726, -0.00029716644713644513,
        0.023716782310077403, 0.019528925379039816, 0.00079844493918787736,
        0.0070988027829033649, -0.0084180765434620948, 0.016083506631342576,
        -0.0045924216366215534, -0.011142612111522147, -0.002888176816865008,
        -0.00802537064633478, 0.012766805851510637, -0.020198639394994649,
        -0.0097083720639130951, -0.0091676464508220964, 0.00435884056013626,
        0.013915611244386256, -0.013481596250711488, 0.014337918372558649,
        -0.019404586463669288, 0.0098214668758865552, -0.021056718189873844,
        -6.7614524033604955E-5, 0.013920410191938721, -0.0012444533110068793,
        -0.0040703287925533327, 0.0066164411107134608, 0.014974333383922839,
        0.0020554198413561338, 0.0028486968111954818, -0.011394150631827239,
        -0.027818461693824466, -0.0077734577488767654, 0.0049236040804607256,
        0.0020032842971943765, -0.010925444129072332, -0.0054961049166662047,
        0.0088158408135867727, -0.0087539925161988462, 0.01300384584270378,
        0.013750681974357241, -0.026417942821240634, -0.0081266442587447554,
        0.020910479108107258, 0.0098168108728565063, 0.01764161752812244,
        -0.027626978631403558, 0.025233695603163339, 0.010542193718773045,
        0.018464955723030148, -0.0088771005876942376, -0.0078197398828802264,
        0.008676081481760748, -0.014778982212576603, -0.0099216342999255136,
        -0.014578018656252661, -0.00077658714536532863, -0.012987083927544588,
        -0.0090609834519429222, 0.018946642862263007, 0.015045157065683578,
        0.006708955495805813, -0.00028310507157100804, -0.026868607494067113,
        -0.005148152977278061, 0.00397677173933013, 0.022065529202473247,
        -0.010942753006805252, 0.026368303207209478, -0.018624685483749133,
        0.026103464924784658, 0.0056407823290818004, -0.00343380422761762,
        -0.018799855892486585, -0.010379486000253233, 0.0084626604614132673,
        -0.010996078977180969, 0.023331145495973194, 0.021173176490147619,
        -0.012621099751947964, 0.0059666069414387388, -0.0095551466874497087,
        0.01763049682847018, 0.010552065936043117, -0.0235417003104494,
        0.021027674535218924, 0.011227475628336739, -0.014325270846793773,
        0.0064743089203085991, -0.0021113235790818012, -0.023947181421117326,
        0.004366820879600275, 0.00027015795217459485, 0.002928147143792529,
        0.0040119410416391789, 0.011995633089772275, 0.0095749095502177788,
        0.0026711527621116919, 0.026968279318860644, -0.017340029164722735,
        0.016107031952301287, 0.021484374634796546, 0.011107005940754857,
        -0.0038387692687362213, 0.013346087574324653, 0.0050152194694508693,
        -0.00070286148200660113, 0.0065410905186553568, 0.013551728193680333,
        -0.031463161842818277, -0.002110052375679356, -0.006056030488751093,
        0.010901626520437193, -0.0040180202919192134, 0.00139063077213079,
        0.0016082106577239631, 0.0040733006295044913, -0.015109673952605096,
        0.017318680377902424, -0.012378860685477245, -0.013014801428912381,
        -0.025499076864863943, -0.012420422819569087, 0.00030263865313142078,
        -0.0019691900616251655, 0.0060079994935423008, -0.002611435060640399,
        0.030088779710346191, 0.011032616059908081, -0.0080118760788806358,
        0.030316702378155532, 0.00039940075457293794, -0.00062199231715660906,
        0.013902232398568188, 0.015365759258540331, 0.019234763839184012,
        0.00955593285013652, -0.027122752855659227, 0.013816104117962422,
        -0.0077266967692022339, -0.010055423397056583, 0.0075890470326120205,
        0.0030718592407111738, -0.014525417622050537, 0.023989189854599132,
        -0.025426244762906992, 0.0049107930699610839, 0.034167991056854592,
        -0.020292061026623013, 0.007931045052180544, -0.0098201000738324749,
        0.0053120494846653366, -0.0054531474425964892, -0.032684991012887576,
        0.0016576777024524406, 0.0042867000048820757, 0.0084514957111480066,
        -0.0033564663822261706, 0.014886320335569357, 0.027907586703399035,
        0.0060427601901836686, -0.020732900002552995, -0.028364085358253192,
        -0.0073589236047119566, -0.0063247825572223821, 0.013902088787738812,
        -0.010149899462971059, 0.0089484392443958, -0.011637354780539252,
        0.023110073721109386, 0.014101398298792464, -0.0061543160019334334,
        0.0089333438524918148, 0.013703435846692761, 0.010195124635655162,
        0.015326067399257955, 0.0055545682398188941, -0.034806515719448164,
        -0.0041655120378532853, -0.006071922631655664, -0.016990639436043575,
        0.00960071796618779, -0.0014932841242445974, 0.012403645218437958,
        -0.022100315930147996, 0.01170728470701575, 0.006053043326788193,
        -0.0028965731128382127, -0.015295570203066901, 0.0027111013548173106,
        -0.009317607503347097, -0.0044275077996890448, -0.00013819389241728506,
        -0.016027698071705475, 0.0015703656308963105, 0.0061521956029135759,
        0.0024652990419707075, 0.0054272139308849067, 0.022785525212254052,
        -0.014889598450359412, -0.01252901969428321, -0.00029986472187008676,
        -0.033006598408008736, 0.015452469486149355, 0.03140973827615702,
        -0.0067830258378828523, 0.0012766711399865298, -0.00813744710530078,
        0.00809165333454218, 0.016391625927173907, -0.015510423358502346,
        -0.004895042274954969, 0.0012440063744654554, -0.0011142298498259258,
        0.0053543217657067614, -0.0015075798777473683, 0.018012801453393991,
        -0.017057939529644055, 0.010294658318733722, -0.0019717253461941694,
        0.031465427156287175, 0.0053636403447456325, 0.018700403757107634,
        -0.040215110423038158, 0.0075923880036712693, -0.008546251829529913,
        -0.014408769111399513, 0.0089849357652853623, 0.0064581519232847929,
        -0.016416745527083748, 0.012505244609778102, -0.020993821982514829,
        -0.0101199838202945, -0.016430608182581553, -0.0014444637689372097,
        0.011138240723347986, -0.0072471296147392193, 0.0023879030864215412,
        -0.00086417635209278172, -0.02099687886444113, -0.00077414829374111813,
        0.0089806512814890431, 0.0013761550060400805, 0.0017882830217159471,
        0.013512044076921569, 0.00055633966496365021, 0.0010599323887105357,
        -0.0064797149222610793, 0.0035873837237929891, 0.016551428888803343,
        0.011332614618193721, -0.0047825420545592589, 0.0037818195274386167,
        -0.031578335216407939, -0.025870917638113163, 0.015902671761643474,
        0.00057669959501837015, 0.0064831192295961623, -0.024642699697047715,
        0.0049361436627967138, 0.012339234714400406, -0.0057458600032989342,
        0.024744892758821413, -0.0060347399400733914, -0.0017727719543939558,
        0.019778763845118039, -0.0063841870124767448, 0.0035168176112569203,
        0.021745978040826067, 0.036469723249254384, 0.03020396886499345,
        -0.022693872263818759, 0.0059529714426103377, -0.027834331440092289,
        0.028955883845445823, 0.011481974886327444, -0.0022797971196413924,
        0.014990783925671226, 0.02084657241059492, 0.009666741865220348,
        -0.017504266663738267, 0.0055325006161188219, -0.0071196271391368538,
        0.0051653005714752467, 0.017542340603087042, 0.008319177152008474,
        -0.0018628582748523401, 0.025652390504981509, 0.0035321104022140184,
        0.024094647200102154, 0.03605782290583371, 0.00741713252605771,
        0.015118642573661438, 0.029340584889462909, -0.016263429833632558,
        -0.011436932341232772, 0.0036576609251943244, -0.012167466469851236,
        0.0018450284304378037, -0.0061840662591815835, -0.017280142226316051,
        -0.0048428229871760086, -0.00757778731357165, 0.029895280180059755,
        0.01460768542244208, 0.0070190548045756321, -0.001095608871848253,
        -0.001021979909506292, -0.017229599694573414, -0.026931523577029028,
        0.010563422876323699, -0.0036670633203375628, 0.0086935726879527712,
        -0.0035367826162642723, 0.013630733601280363, 0.013294274383844685,
        0.027252156728203764, 0.031680295099834964, -0.0056875839796279104,
        -0.036383455113412511, -0.016641396816860398, 0.026659681010452123,
        0.0065317708488546681, -0.0078963296142955629, 0.0054835007197571,
        0.019849320824055845, 0.0015511309950194732, -0.00801718977481245,
        -0.0060643843228890635, 0.018040397807473449, 0.0049885734800994147,
        0.005399867711815714, -0.00028680612312387412, 0.0038586998652956235,
        0.020406747891271643, -0.014574406872819438, 0.030500764634416214,
        0.0054077092477865189, -0.0046372854998416608, -0.042769944008921069,
        0.0016580120923716921, 0.00929551084621051, 0.0068855515292257936,
        -0.01576262722128886, -0.010517551133159803, -0.0084528776836444355,
        -0.019041333987724913, 0.0016123140883564911, -0.011980293010116378,
        0.00986333240075282, 0.0029697589328645927, 0.00994369105908122,
        0.0059793190732206018, 0.012605276835608293, -0.012592035031809685,
        -0.0193251970852042, -0.0077760774532812989, 0.015392653585137505,
        -0.018961355429928297, 0.028300809077052, 0.022460157844348544,
        -0.011192561360428843, 0.0016653178308302288, 0.012388857690229817,
        -0.01263328622643423, 0.0048951717107396254, 0.042910847150704375,
        0.021232459818053915, 0.014504638928902795, 0.0062305327144025072,
        0.012878341916246459, 0.011473360705187037, -0.0065734687815719979,
        0.0030936413719386611, -0.0041099275580307312, -0.010280378539881358,
        -0.030474368065192541, 0.00065196823422589709, -0.00395291710758381,
        -0.0065350956061044933, -0.017590376083896866, 0.022931941063869671,
        -0.019128423777239348, 0.0095129665445948253, 0.013245438750061875,
        -0.0067916666614841366, -0.010972211454391327, 0.025273142934224814,
        0.014471561538933716, -0.015417083505133858, 0.00083743935290770278,
        0.011527734820277157, 0.0029012466476496203, -0.029193929925598029,
        -0.0084349210852920718, 0.0038520338122005251, -0.0020119858846404941,
        -0.0056602651562688705, -0.0089773913409118521, -0.033578299062070945,
        0.00028822465334923014, -0.00060328479216208131, 0.019204590974891928,
        -0.016152639294939434, -0.0071178306349516359, -0.017961278343287576,
        -0.0096899705065884422, -0.020327942159082693, -0.0038501359129164319,
        0.0070909914573790726, 0.00029716644713644513, -0.023716782310077403,
        -0.019528925379039816, -0.00079844493918787736, -0.0070988027829033649,
        0.0084180765434620948, -0.016083506631342576, 0.0045924216366215534,
        0.011142612111522147, 0.002888176816865008, 0.00802537064633478,
        -0.012766805851510637, 0.020198639394994649, 0.0097083720639130951,
        0.0091676464508220964, -0.00435884056013626, -0.013915611244386256,
        0.013481596250711488, -0.014337918372558649, 0.019404586463669288,
        -0.0098214668758865552, 0.021056718189873844, 6.7614524033604955E-5,
        -0.013920410191938721, 0.0012444533110068793, 0.0040703287925533327,
        -0.0066164411107134608, -0.014974333383922839, -0.0020554198413561338,
        -0.0028486968111954818, 0.011394150631827239, 0.027818461693824466,
        0.0077734577488767654, -0.0049236040804607256, -0.0020032842971943765,
        0.010925444129072332, 0.0054961049166662047, -0.0088158408135867727,
        0.0087539925161988462, -0.01300384584270378, -0.013750681974357241,
        0.026417942821240634, 0.0081266442587447554, -0.020910479108107258,
        -0.0098168108728565063, -0.01764161752812244, 0.027626978631403558,
        -0.025233695603163339, -0.010542193718773045, -0.018464955723030148,
        0.0088771005876942376, 0.0078197398828802264, -0.008676081481760748,
        0.014778982212576603, 0.0099216342999255136, 0.014578018656252661,
        0.00077658714536532863, 0.012987083927544588, 0.0090609834519429222,
        -0.018946642862263007, -0.015045157065683578, -0.006708955495805813,
        0.00028310507157100804, 0.026868607494067113, 0.005148152977278061,
        -0.00397677173933013, -0.022065529202473247, 0.010942753006805252,
        -0.026368303207209478, 0.018624685483749133, -0.026103464924784658,
        -0.0056407823290818004, 0.00343380422761762, 0.018799855892486585,
        0.010379486000253233, -0.0084626604614132673, 0.010996078977180969,
        -0.023331145495973194, -0.021173176490147619, 0.012621099751947964,
        -0.0059666069414387388, 0.0095551466874497087, -0.01763049682847018,
        -0.010552065936043117, 0.0235417003104494, -0.021027674535218924,
        -0.011227475628336739, 0.014325270846793773, -0.0064743089203085991,
        0.0021113235790818012, 0.023947181421117326, -0.004366820879600275,
        -0.00027015795217459485, -0.002928147143792529, -0.0040119410416391789,
        -0.011995633089772275, -0.0095749095502177788, -0.0026711527621116919,
        -0.026968279318860644, 0.017340029164722735, -0.016107031952301287,
        -0.021484374634796546, -0.011107005940754857, 0.0038387692687362213,
        -0.013346087574324653, -0.0050152194694508693, 0.00070286148200660113,
        -0.0065410905186553568, -0.013551728193680333, 0.031463161842818277,
        0.002110052375679356, 0.006056030488751093, -0.010901626520437193,
        0.0040180202919192134, -0.00139063077213079, -0.0016082106577239631,
        -0.0040733006295044913, 0.015109673952605096, -0.017318680377902424,
        0.012378860685477245, 0.013014801428912381, 0.025499076864863943,
        0.012420422819569087, -0.00030263865313142078, 0.0019691900616251655,
        -0.0060079994935423008, 0.002611435060640399, -0.030088779710346191,
        -0.011032616059908081, 0.0080118760788806358, -0.030316702378155532,
        -0.00039940075457293794, 0.00062199231715660906, -0.013902232398568188,
        -0.015365759258540331, -0.019234763839184012, -0.00955593285013652,
        0.027122752855659227, -0.013816104117962422, 0.0077266967692022339,
        0.010055423397056583, -0.0075890470326120205, -0.0030718592407111738,
        0.014525417622050537, -0.023989189854599132, 0.025426244762906992,
        -0.0049107930699610839, -0.034167991056854592, 0.020292061026623013,
        -0.007931045052180544, 0.0098201000738324749, -0.0053120494846653366,
        0.0054531474425964892, 0.032684991012887576, -0.0016576777024524406,
        -0.0042867000048820757, -0.0084514957111480066, 0.0033564663822261706,
        -0.014886320335569357, -0.027907586703399035, -0.0060427601901836686,
        0.020732900002552995, 0.028364085358253192, 0.0073589236047119566,
        0.0063247825572223821, -0.013902088787738812, 0.010149899462971059,
        -0.0089484392443958, 0.011637354780539252, -0.023110073721109386,
        -0.014101398298792464, 0.0061543160019334334, -0.0089333438524918148,
        -0.013703435846692761, -0.010195124635655162, -0.015326067399257955,
        -0.0055545682398188941, 0.034806515719448164, 0.0041655120378532853,
        0.006071922631655664, 0.016990639436043575, -0.00960071796618779,
        0.0014932841242445974, -0.012403645218437958, 0.022100315930147996,
        -0.01170728470701575, -0.006053043326788193, 0.0028965731128382127,
        0.015295570203066901, -0.0027111013548173106, 0.009317607503347097,
        0.0044275077996890448, 0.00013819389241728506, 0.016027698071705475,
        -0.0015703656308963105, -0.0061521956029135759, -0.0024652990419707075,
        -0.0054272139308849067, -0.022785525212254052, 0.014889598450359412,
        0.01252901969428321, 0.00029986472187008676, 0.033006598408008736,
        -0.015452469486149355, -0.03140973827615702, 0.0067830258378828523,
        -0.0012766711399865298, 0.00813744710530078, -0.00809165333454218,
        -0.016391625927173907, 0.015510423358502346, 0.004895042274954969,
        -0.0012440063744654554, 0.0011142298498259258, -0.0053543217657067614,
        0.0015075798777473683, -0.018012801453393991, 0.017057939529644055,
        -0.010294658318733722, 0.0019717253461941694, -0.031465427156287175,
        -0.0053636403447456325, -0.018700403757107634, 0.040215110423038158,
        -0.0075923880036712693, 0.008546251829529913, 0.014408769111399513,
        -0.0089849357652853623, -0.0064581519232847929, 0.016416745527083748,
        -0.012505244609778102, 0.020993821982514829, 0.0101199838202945,
        0.016430608182581553, 0.0014444637689372097, -0.011138240723347986,
        0.0072471296147392193, -0.0023879030864215412, 0.00086417635209278172,
        0.02099687886444113, 0.00077414829374111813, -0.0089806512814890431,
        -0.0013761550060400805, -0.0017882830217159471, -0.013512044076921569,
        -0.00055633966496365021, -0.0010599323887105357, 0.0064797149222610793,
        -0.0035873837237929891, -0.016551428888803343, -0.011332614618193721,
        0.0047825420545592589, -0.0037818195274386167, 0.031578335216407939,
        0.025870917638113163, -0.015902671761643474, -0.00057669959501837015,
        -0.0064831192295961623, 0.024642699697047715, -0.0049361436627967138,
        -0.012339234714400406, 0.0057458600032989342, -0.024744892758821413,
        0.0060347399400733914, 0.0017727719543939558, -0.019778763845118039,
        0.0063841870124767448, -0.0035168176112569203, -0.021745978040826067,
        -0.036469723249254384, -0.03020396886499345, 0.022693872263818759,
        -0.0059529714426103377, 0.027834331440092289, -0.028955883845445823,
        -0.011481974886327444, 0.0022797971196413924, -0.014990783925671226,
        -0.02084657241059492, -0.009666741865220348, 0.017504266663738267,
        -0.0055325006161188219, 0.0071196271391368538, -0.0051653005714752467,
        -0.017542340603087042, -0.008319177152008474, 0.0018628582748523401,
        -0.025652390504981509, -0.0035321104022140184, -0.024094647200102154,
        -0.03605782290583371, -0.00741713252605771, -0.015118642573661438,
        -0.029340584889462909, 0.016263429833632558, 0.011436932341232772,
        -0.0036576609251943244, 0.012167466469851236, -0.0018450284304378037,
        0.0061840662591815835, 0.017280142226316051, 0.0048428229871760086,
        0.00757778731357165, -0.029895280180059755, -0.01460768542244208,
        -0.0070190548045756321, 0.001095608871848253, 0.001021979909506292,
        0.017229599694573414, 0.026931523577029028, -0.010563422876323699,
        0.0036670633203375628, -0.0086935726879527712, 0.0035367826162642723,
        -0.013630733601280363, -0.013294274383844685, -0.027252156728203764,
        -0.031680295099834964, 0.0056875839796279104, 0.036383455113412511,
        0.016641396816860398, -0.026659681010452123, -0.0065317708488546681,
        0.0078963296142955629, -0.0054835007197571, -0.019849320824055845,
        -0.0015511309950194732, 0.00801718977481245, 0.0060643843228890635,
        -0.018040397807473449, -0.0049885734800994147, -0.005399867711815714,
        0.00028680612312387412, -0.0038586998652956235, -0.020406747891271643,
        0.014574406872819438, -0.030500764634416214, -0.0054077092477865189,
        0.0046372854998416608, 0.042769944008921069, -0.0016580120923716921,
        -0.00929551084621051, -0.0068855515292257936, 0.01576262722128886,
        0.010517551133159803, 0.0084528776836444355, 0.019041333987724913,
        -0.0016123140883564911, 0.011980293010116378, -0.00986333240075282,
        -0.0029697589328645927, -0.00994369105908122, -0.0059793190732206018,
        -0.012605276835608293, 0.012592035031809685, 0.0193251970852042,
        0.0077760774532812989, -0.015392653585137505, 0.018961355429928297,
        -0.028300809077052, -0.022460157844348544, 0.011192561360428843,
        -0.0016653178308302288, -0.012388857690229817, 0.01263328622643423,
        -0.0048951717107396254, -0.042910847150704375, -0.021232459818053915,
        -0.014504638928902795, -0.0062305327144025072, -0.012878341916246459,
        -0.011473360705187037, 0.0065734687815719979, -0.0030936413719386611,
        0.0041099275580307312, 0.010280378539881358, 0.030474368065192541,
        -0.00065196823422589709, 0.00395291710758381, 0.0065350956061044933,
        0.017590376083896866, -0.022931941063869671, 0.019128423777239348,
        -0.0095129665445948253, -0.013245438750061875, 0.0067916666614841366,
        0.010972211454391327, -0.025273142934224814, -0.014471561538933716,
        0.015417083505133858, -0.00083743935290770278, -0.011527734820277157,
        -0.0029012466476496203, 0.029193929925598029, 0.0084349210852920718,
        -0.0038520338122005251, 0.0020119858846404941, 0.0056602651562688705,
        0.0089773913409118521, 0.033578299062070945, -0.00028822465334923014,
        0.00060328479216208131, -0.019204590974891928, 0.016152639294939434,
        0.0071178306349516359, 0.017961278343287576, 0.0096899705065884422,
        0.020327942159082693, 0.0038501359129164319, -0.0070909914573790726,
        -0.00029716644713644513, 0.023716782310077403, 0.019528925379039816,
        0.00079844493918787736, 0.0070988027829033649, -0.0084180765434620948,
        0.016083506631342576, -0.0045924216366215534, -0.011142612111522147,
        -0.002888176816865008, -0.00802537064633478, 0.012766805851510637,
        -0.020198639394994649, -0.0097083720639130951, -0.0091676464508220964,
        0.00435884056013626, 0.013915611244386256, -0.013481596250711488,
        0.014337918372558649, -0.019404586463669288, 0.0098214668758865552,
        -0.021056718189873844, -6.7614524033604955E-5, 0.013920410191938721,
        -0.0012444533110068793, -0.0040703287925533327, 0.0066164411107134608,
        0.014974333383922839, 0.0020554198413561338, 0.0028486968111954818,
        -0.011394150631827239, -0.027818461693824466, -0.0077734577488767654,
        0.0049236040804607256, 0.0020032842971943765, -0.010925444129072332,
        -0.0054961049166662047, 0.0088158408135867727, -0.0087539925161988462,
        0.01300384584270378, 0.013750681974357241, -0.026417942821240634,
        -0.0081266442587447554, 0.020910479108107258, 0.0098168108728565063,
        0.01764161752812244, -0.027626978631403558, 0.025233695603163339,
        0.010542193718773045, 0.018464955723030148, -0.0088771005876942376,
        -0.0078197398828802264, 0.008676081481760748, -0.014778982212576603,
        -0.0099216342999255136, -0.014578018656252661, -0.00077658714536532863,
        -0.012987083927544588, -0.0090609834519429222, 0.018946642862263007,
        0.015045157065683578, 0.006708955495805813, -0.00028310507157100804,
        -0.026868607494067113, -0.005148152977278061, 0.00397677173933013,
        0.022065529202473247, -0.010942753006805252, 0.026368303207209478,
        -0.018624685483749133, 0.026103464924784658, 0.0056407823290818004,
        -0.00343380422761762, -0.018799855892486585, -0.010379486000253233,
        0.0084626604614132673, -0.010996078977180969, 0.023331145495973194,
        0.021173176490147619, -0.012621099751947964, 0.0059666069414387388,
        -0.0095551466874497087, 0.01763049682847018, 0.010552065936043117,
        -0.0235417003104494, 0.021027674535218924, 0.011227475628336739,
        -0.014325270846793773, 0.0064743089203085991, -0.0021113235790818012,
        -0.023947181421117326, 0.004366820879600275, 0.00027015795217459485,
        0.002928147143792529, 0.0040119410416391789, 0.011995633089772275,
        0.0095749095502177788, 0.0026711527621116919, 0.026968279318860644,
        -0.017340029164722735, 0.016107031952301287, 0.021484374634796546,
        0.011107005940754857, -0.0038387692687362213, 0.013346087574324653,
        0.0050152194694508693, -0.00070286148200660113, 0.0065410905186553568,
        0.013551728193680333, -0.031463161842818277, -0.002110052375679356,
        -0.006056030488751093, 0.010901626520437193, -0.0040180202919192134,
        0.00139063077213079, 0.0016082106577239631, 0.0040733006295044913,
        -0.015109673952605096, 0.017318680377902424, -0.012378860685477245,
        -0.013014801428912381, -0.025499076864863943, -0.012420422819569087,
        0.00030263865313142078, -0.0019691900616251655, 0.0060079994935423008,
        -0.002611435060640399, 0.030088779710346191, 0.011032616059908081,
        -0.0080118760788806358, 0.030316702378155532, 0.00039940075457293794,
        -0.00062199231715660906, 0.013902232398568188, 0.015365759258540331,
        0.019234763839184012, 0.00955593285013652, -0.027122752855659227,
        0.013816104117962422, -0.0077266967692022339, -0.010055423397056583,
        0.0075890470326120205, 0.0030718592407111738, -0.014525417622050537,
        0.023989189854599132, -0.025426244762906992, 0.0049107930699610839,
        0.034167991056854592, -0.020292061026623013, 0.007931045052180544,
        -0.0098201000738324749, 0.0053120494846653366, -0.0054531474425964892,
        -0.032684991012887576, 0.0016576777024524406, 0.0042867000048820757,
        0.0084514957111480066, -0.0033564663822261706, 0.014886320335569357,
        0.027907586703399035, 0.0060427601901836686, -0.020732900002552995,
        -0.028364085358253192, -0.0073589236047119566, -0.0063247825572223821,
        0.013902088787738812, -0.010149899462971059, 0.0089484392443958,
        -0.011637354780539252, 0.023110073721109386, 0.014101398298792464,
        -0.0061543160019334334, 0.0089333438524918148, 0.013703435846692761,
        0.010195124635655162, 0.015326067399257955, 0.0055545682398188941,
        -0.034806515719448164, -0.0041655120378532853, -0.006071922631655664,
        -0.016990639436043575, 0.00960071796618779, -0.0014932841242445974,
        0.012403645218437958, -0.022100315930147996, 0.01170728470701575,
        0.006053043326788193, -0.0028965731128382127, -0.015295570203066901,
        0.0027111013548173106, -0.009317607503347097, -0.0044275077996890448,
        -0.00013819389241728506, -0.016027698071705475, 0.0015703656308963105,
        0.0061521956029135759, 0.0024652990419707075, 0.0054272139308849067,
        0.022785525212254052, -0.014889598450359412, -0.01252901969428321,
        -0.00029986472187008676, -0.033006598408008736, 0.015452469486149355,
        0.03140973827615702, -0.0067830258378828523, 0.0012766711399865298,
        -0.00813744710530078, 0.00809165333454218, 0.016391625927173907,
        -0.015510423358502346, -0.004895042274954969, 0.0012440063744654554,
        -0.0011142298498259258, 0.0053543217657067614, -0.0015075798777473683,
        0.018012801453393991, -0.017057939529644055, 0.010294658318733722,
        -0.0019717253461941694, 0.031465427156287175, 0.0053636403447456325,
        0.018700403757107634, -0.040215110423038158, 0.0075923880036712693,
        -0.008546251829529913, -0.014408769111399513, 0.0089849357652853623,
        0.0064581519232847929, -0.016416745527083748, 0.012505244609778102,
        -0.020993821982514829, -0.0101199838202945, -0.016430608182581553,
        -0.0014444637689372097, 0.011138240723347986, -0.0072471296147392193,
        0.0023879030864215412, -0.00086417635209278172, -0.02099687886444113,
        -0.00077414829374111813, 0.0089806512814890431, 0.0013761550060400805,
        0.0017882830217159471, 0.013512044076921569, 0.00055633966496365021,
        0.0010599323887105357, -0.0064797149222610793, 0.0035873837237929891,
        0.016551428888803343, 0.011332614618193721, -0.0047825420545592589,
        0.0037818195274386167, -0.031578335216407939, -0.025870917638113163,
        0.015902671761643474, 0.00057669959501837015, 0.0064831192295961623,
        -0.024642699697047715, 0.0049361436627967138, 0.012339234714400406,
        -0.0057458600032989342, 0.024744892758821413, -0.0060347399400733914,
        -0.0017727719543939558, 0.019778763845118039, -0.0063841870124767448,
        0.0035168176112569203, 0.021745978040826067, 0.036469723249254384,
        0.03020396886499345, -0.022693872263818759, 0.0059529714426103377,
        -0.027834331440092289, 0.028955883845445823, 0.011481974886327444,
        -0.0022797971196413924, 0.014990783925671226, 0.02084657241059492,
        0.009666741865220348, -0.017504266663738267, 0.0055325006161188219,
        -0.0071196271391368538, 0.0051653005714752467, 0.017542340603087042,
        0.008319177152008474, -0.0018628582748523401, 0.025652390504981509,
        0.0035321104022140184, 0.024094647200102154, 0.03605782290583371,
        0.00741713252605771, 0.015118642573661438, 0.029340584889462909,
        -0.016263429833632558, -0.011436932341232772, 0.0036576609251943244,
        -0.012167466469851236, 0.0018450284304378037, -0.0061840662591815835,
        -0.017280142226316051, -0.0048428229871760086, -0.00757778731357165,
        0.029895280180059755, 0.01460768542244208, 0.0070190548045756321,
        -0.001095608871848253, -0.001021979909506292, -0.017229599694573414,
        -0.026931523577029028, 0.010563422876323699, -0.0036670633203375628,
        0.0086935726879527712, -0.0035367826162642723, 0.013630733601280363,
        0.013294274383844685, 0.027252156728203764, 0.031680295099834964,
        -0.0056875839796279104, -0.036383455113412511, -0.016641396816860398,
        0.026659681010452123, 0.0065317708488546681, -0.0078963296142955629,
        0.0054835007197571, 0.019849320824055845, 0.0015511309950194732,
        -0.00801718977481245, -0.0060643843228890635, 0.018040397807473449,
        0.0049885734800994147, 0.005399867711815714, -0.00028680612312387412,
        0.0038586998652956235, 0.020406747891271643, -0.014574406872819438,
        0.030500764634416214, 0.0054077092477865189, -0.0046372854998416608,
        -0.042769944008921069, 0.0016580120923716921, 0.00929551084621051,
        0.0068855515292257936, -0.01576262722128886, -0.010517551133159803,
        -0.0084528776836444355, -0.019041333987724913, 0.0016123140883564911,
        -0.011980293010116378, 0.00986333240075282, 0.0029697589328645927,
        0.00994369105908122, 0.0059793190732206018, 0.012605276835608293,
        -0.012592035031809685, -0.0193251970852042, -0.0077760774532812989,
        0.015392653585137505, -0.018961355429928297, 0.028300809077052,
        0.022460157844348544, -0.011192561360428843, 0.0016653178308302288,
        0.012388857690229817, -0.01263328622643423, 0.0048951717107396254,
        0.042910847150704375, 0.021232459818053915, 0.014504638928902795,
        0.0062305327144025072, 0.012878341916246459, 0.011473360705187037,
        -0.0065734687815719979, 0.0030936413719386611, -0.0041099275580307312,
        -0.010280378539881358, -0.030474368065192541, 0.00065196823422589709,
        -0.00395291710758381, -0.0065350956061044933, -0.017590376083896866,
        0.022931941063869671, -0.019128423777239348, 0.0095129665445948253,
        0.013245438750061875, -0.0067916666614841366, -0.010972211454391327,
        0.025273142934224814, 0.014471561538933716, -0.015417083505133858,
        0.00083743935290770278, 0.011527734820277157, 0.0029012466476496203,
        -0.029193929925598029, -0.0084349210852920718, 0.0038520338122005251,
        -0.0020119858846404941, -0.0056602651562688705, -0.0089773913409118521,
        -0.033578299062070945, 0.00028822465334923014, -0.00060328479216208131,
        0.019204590974891928, -0.016152639294939434, -0.0071178306349516359,
        -0.017961278343287576, -0.0096899705065884422, -0.020327942159082693,
        -0.0038501359129164319, 0.0070909914573790726, 0.00029716644713644513,
        -0.023716782310077403, -0.019528925379039816, -0.00079844493918787736,
        -0.0070988027829033649, 0.0084180765434620948, -0.016083506631342576,
        0.0045924216366215534, 0.011142612111522147, 0.002888176816865008,
        0.00802537064633478, -0.012766805851510637, 0.020198639394994649,
        0.0097083720639130951, 0.0091676464508220964, -0.00435884056013626,
        -0.013915611244386256, 0.013481596250711488, -0.014337918372558649,
        0.019404586463669288, -0.0098214668758865552, 0.021056718189873844,
        6.7614524033604955E-5, -0.013920410191938721, 0.0012444533110068793,
        0.0040703287925533327, -0.0066164411107134608, -0.014974333383922839,
        -0.0020554198413561338, -0.0028486968111954818, 0.011394150631827239,
        0.027818461693824466, 0.0077734577488767654, -0.0049236040804607256,
        -0.0020032842971943765, 0.010925444129072332, 0.0054961049166662047,
        -0.0088158408135867727, 0.0087539925161988462, -0.01300384584270378,
        -0.013750681974357241, 0.026417942821240634, 0.0081266442587447554,
        -0.020910479108107258, -0.0098168108728565063, -0.01764161752812244,
        0.027626978631403558, -0.025233695603163339, -0.010542193718773045,
        -0.018464955723030148, 0.0088771005876942376, 0.0078197398828802264,
        -0.008676081481760748, 0.014778982212576603, 0.0099216342999255136,
        0.014578018656252661, 0.00077658714536532863, 0.012987083927544588,
        0.0090609834519429222, -0.018946642862263007, -0.015045157065683578,
        -0.006708955495805813, 0.00028310507157100804, 0.026868607494067113,
        0.005148152977278061, -0.00397677173933013, -0.022065529202473247,
        0.010942753006805252, -0.026368303207209478, 0.018624685483749133,
        -0.026103464924784658, -0.0056407823290818004, 0.00343380422761762,
        0.018799855892486585, 0.010379486000253233, -0.0084626604614132673,
        0.010996078977180969, -0.023331145495973194, -0.021173176490147619,
        0.012621099751947964, -0.0059666069414387388, 0.0095551466874497087,
        -0.01763049682847018, -0.010552065936043117, 0.0235417003104494,
        -0.021027674535218924, -0.011227475628336739, 0.014325270846793773,
        -0.0064743089203085991, 0.0021113235790818012, 0.023947181421117326,
        -0.004366820879600275, -0.00027015795217459485, -0.002928147143792529,
        -0.0040119410416391789, -0.011995633089772275, -0.0095749095502177788,
        -0.0026711527621116919, -0.026968279318860644, 0.017340029164722735,
        -0.016107031952301287, -0.021484374634796546, -0.011107005940754857,
        0.0038387692687362213, -0.013346087574324653, -0.0050152194694508693,
        0.00070286148200660113, -0.0065410905186553568, -0.013551728193680333,
        0.031463161842818277, 0.002110052375679356, 0.006056030488751093,
        -0.010901626520437193, 0.0040180202919192134, -0.00139063077213079,
        -0.0016082106577239631, -0.0040733006295044913, 0.015109673952605096,
        -0.017318680377902424, 0.012378860685477245, 0.013014801428912381,
        0.025499076864863943, 0.012420422819569087, -0.00030263865313142078,
        0.0019691900616251655, -0.0060079994935423008, 0.002611435060640399,
        -0.030088779710346191, -0.011032616059908081, 0.0080118760788806358,
        -0.030316702378155532, -0.00039940075457293794, 0.00062199231715660906,
        -0.013902232398568188, -0.015365759258540331, -0.019234763839184012,
        -0.00955593285013652, 0.027122752855659227, -0.013816104117962422,
        0.0077266967692022339, 0.010055423397056583, -0.0075890470326120205,
        -0.0030718592407111738, 0.014525417622050537, -0.023989189854599132,
        0.025426244762906992, -0.0049107930699610839, -0.034167991056854592,
        0.020292061026623013, -0.007931045052180544, 0.0098201000738324749,
        -0.0053120494846653366, 0.0054531474425964892, 0.032684991012887576,
        -0.0016576777024524406, -0.0042867000048820757, -0.0084514957111480066,
        0.0033564663822261706, -0.014886320335569357, -0.027907586703399035,
        -0.0060427601901836686, 0.020732900002552995, 0.028364085358253192,
        0.0073589236047119566, 0.0063247825572223821, -0.013902088787738812,
        0.010149899462971059, -0.0089484392443958, 0.011637354780539252,
        -0.023110073721109386, -0.014101398298792464, 0.0061543160019334334,
        -0.0089333438524918148, -0.013703435846692761, -0.010195124635655162,
        -0.015326067399257955, -0.0055545682398188941, 0.034806515719448164,
        0.0041655120378532853, 0.006071922631655664, 0.016990639436043575,
        -0.00960071796618779, 0.0014932841242445974, -0.012403645218437958,
        0.022100315930147996, -0.01170728470701575, -0.006053043326788193,
        0.0028965731128382127, 0.015295570203066901, -0.0027111013548173106,
        0.009317607503347097, 0.0044275077996890448, 0.00013819389241728506,
        0.016027698071705475, -0.0015703656308963105, -0.0061521956029135759,
        -0.0024652990419707075, -0.0054272139308849067, -0.022785525212254052,
        0.014889598450359412, 0.01252901969428321, 0.00029986472187008676,
        0.033006598408008736, -0.015452469486149355, -0.03140973827615702,
        0.0067830258378828523, -0.0012766711399865298, 0.00813744710530078,
        -0.00809165333454218, -0.016391625927173907, 0.015510423358502346,
        0.004895042274954969, -0.0012440063744654554, 0.0011142298498259258,
        -0.0053543217657067614, 0.0015075798777473683, -0.018012801453393991,
        0.017057939529644055, -0.010294658318733722, 0.0019717253461941694,
        -0.031465427156287175, -0.0053636403447456325, -0.018700403757107634,
        0.040215110423038158, -0.0075923880036712693, 0.008546251829529913,
        0.014408769111399513, -0.0089849357652853623, -0.0064581519232847929,
        0.016416745527083748, -0.012505244609778102, 0.020993821982514829,
        0.0101199838202945, 0.016430608182581553, 0.0014444637689372097,
        -0.011138240723347986, 0.0072471296147392193, -0.0023879030864215412,
        0.00086417635209278172, 0.02099687886444113, 0.00077414829374111813,
        -0.0089806512814890431, -0.0013761550060400805, -0.0017882830217159471,
        -0.013512044076921569, -0.00055633966496365021, -0.0010599323887105357,
        0.0064797149222610793, -0.0035873837237929891, -0.016551428888803343,
        -0.011332614618193721, 0.0047825420545592589, -0.0037818195274386167,
        0.031578335216407939, 0.025870917638113163, -0.015902671761643474,
        -0.00057669959501837015, -0.0064831192295961623, 0.024642699697047715,
        -0.0049361436627967138, -0.012339234714400406, 0.0057458600032989342,
        -0.024744892758821413, 0.0060347399400733914, 0.0017727719543939558,
        -0.019778763845118039, 0.0063841870124767448, -0.0035168176112569203,
        -0.021745978040826067, -0.036469723249254384, -0.03020396886499345,
        0.022693872263818759, -0.0059529714426103377, 0.027834331440092289,
        -0.028955883845445823, -0.011481974886327444, 0.0022797971196413924,
        -0.014990783925671226, -0.02084657241059492, -0.009666741865220348,
        0.017504266663738267, -0.0055325006161188219, 0.0071196271391368538,
        -0.0051653005714752467, -0.017542340603087042, -0.008319177152008474,
        0.0018628582748523401, -0.025652390504981509, -0.0035321104022140184,
        -0.024094647200102154, -0.03605782290583371, -0.00741713252605771,
        -0.015118642573661438, -0.029340584889462909, 0.016263429833632558,
        0.011436932341232772, -0.0036576609251943244, 0.012167466469851236,
        -0.0018450284304378037, 0.0061840662591815835, 0.017280142226316051,
        0.0048428229871760086, 0.00757778731357165, -0.029895280180059755,
        -0.01460768542244208, -0.0070190548045756321, 0.001095608871848253,
        0.001021979909506292, 0.017229599694573414, 0.026931523577029028,
        -0.010563422876323699, 0.0036670633203375628, -0.0086935726879527712,
        0.0035367826162642723, -0.013630733601280363, -0.013294274383844685,
        -0.027252156728203764, -0.031680295099834964, 0.0056875839796279104,
        0.036383455113412511, 0.016641396816860398, -0.026659681010452123,
        -0.0065317708488546681, 0.0078963296142955629, -0.0054835007197571,
        -0.019849320824055845, -0.0015511309950194732, 0.00801718977481245,
        0.0060643843228890635, -0.018040397807473449, -0.0049885734800994147,
        -0.005399867711815714, 0.00028680612312387412, -0.0038586998652956235,
        -0.020406747891271643, 0.014574406872819438, -0.030500764634416214,
        -0.0054077092477865189, 0.0046372854998416608, 0.042769944008921069,
        -0.0016580120923716921, -0.00929551084621051, -0.0068855515292257936,
        0.01576262722128886, 0.010517551133159803, 0.0084528776836444355,
        0.019041333987724913, -0.0016123140883564911, 0.011980293010116378,
        -0.00986333240075282, -0.0029697589328645927, -0.00994369105908122,
        -0.0059793190732206018, -0.012605276835608293, 0.012592035031809685,
        0.0193251970852042, 0.0077760774532812989, -0.015392653585137505,
        0.018961355429928297, -0.028300809077052, -0.022460157844348544,
        0.011192561360428843, -0.0016653178308302288, -0.012388857690229817,
        0.01263328622643423, -0.0048951717107396254, -0.042910847150704375,
        -0.021232459818053915, -0.014504638928902795, -0.0062305327144025072,
        -0.012878341916246459, -0.011473360705187037, 0.0065734687815719979,
        -0.0030936413719386611, 0.0041099275580307312, 0.010280378539881358,
        0.030474368065192541, -0.00065196823422589709, 0.00395291710758381,
        0.0065350956061044933, 0.017590376083896866, -0.022931941063869671,
        0.019128423777239348, -0.0095129665445948253, -0.013245438750061875,
        0.0067916666614841366, 0.010972211454391327, -0.025273142934224814,
        -0.014471561538933716, 0.015417083505133858, -0.00083743935290770278,
        -0.011527734820277157, -0.0029012466476496203, 0.029193929925598029,
        0.0084349210852920718, -0.0038520338122005251, 0.0020119858846404941,
        0.0056602651562688705, 0.0089773913409118521, 0.033578299062070945,
        -0.00028822465334923014, 0.00060328479216208131, -0.019204590974891928,
        0.016152639294939434, 0.0071178306349516359, 0.017961278343287576,
        0.0096899705065884422, 0.020327942159082693, 0.0038501359129164319,
        -0.0070909914573790726, -0.00029716644713644513, 0.023716782310077403,
        0.019528925379039816, 0.00079844493918787736, 0.0070988027829033649,
        -0.0084180765434620948, 0.016083506631342576, -0.0045924216366215534,
        -0.011142612111522147, -0.002888176816865008, -0.00802537064633478,
        0.012766805851510637, -0.020198639394994649, -0.0097083720639130951,
        -0.0091676464508220964, 0.00435884056013626, 0.013915611244386256,
        -0.013481596250711488, 0.014337918372558649, -0.019404586463669288,
        0.0098214668758865552, -0.021056718189873844, -6.7614524033604955E-5,
        0.013920410191938721, -0.0012444533110068793, -0.0040703287925533327,
        0.0066164411107134608, 0.014974333383922839, 0.0020554198413561338,
        0.0028486968111954818, -0.011394150631827239, -0.027818461693824466,
        -0.0077734577488767654 } ;

      Closed_loop_MPC_DW.FromWorkspace1_PWORK.TimePtr = (void *) pTimeValues0;
      Closed_loop_MPC_DW.FromWorkspace1_PWORK.DataPtr = (void *) pDataValues0;
      Closed_loop_MPC_DW.FromWorkspace1_IWORK.PrevIndex = 0;
    }

    /* Start for ToWorkspace: '<S2>/To Workspace3' */
    {
      int_T dimensions[1] = { 1 };

      Closed_loop_MPC_DW.ToWorkspace3_PWORK_o.LoggedData = rt_CreateLogVar(
        Closed_loop_MPC_M->rtwLogInfo,
        0.0,
        rtmGetTFinal(Closed_loop_MPC_M),
        Closed_loop_MPC_M->Timing.stepSize0,
        (&rtmGetErrorStatus(Closed_loop_MPC_M)),
        "e",
        SS_DOUBLE,
        0,
        0,
        0,
        1,
        1,
        dimensions,
        NO_LOGVALDIMS,
        (NULL),
        (NULL),
        0,
        1,
        0.009765625,
        1);
      if (Closed_loop_MPC_DW.ToWorkspace3_PWORK_o.LoggedData == (NULL))
        return;
    }

    /* Start for ToWorkspace: '<S2>/To Workspace4' */
    {
      int_T dimensions[1] = { 1 };

      Closed_loop_MPC_DW.ToWorkspace4_PWORK_f.LoggedData = rt_CreateLogVar(
        Closed_loop_MPC_M->rtwLogInfo,
        0.0,
        rtmGetTFinal(Closed_loop_MPC_M),
        Closed_loop_MPC_M->Timing.stepSize0,
        (&rtmGetErrorStatus(Closed_loop_MPC_M)),
        "yref",
        SS_DOUBLE,
        0,
        0,
        0,
        1,
        1,
        dimensions,
        NO_LOGVALDIMS,
        (NULL),
        (NULL),
        0,
        1,
        0.001953125,
        1);
      if (Closed_loop_MPC_DW.ToWorkspace4_PWORK_f.LoggedData == (NULL))
        return;
    }

    /* Start for RateTransition: '<S2>/TmpRTBAtUnit Delay4Inport1' */
    for (i = 0; i < 6; i++) {
      Closed_loop_MPC_B.TmpRTBAtUnitDelay4Inport1[i] =
        Closed_loop_MPC_P.TmpRTBAtUnitDelay4Inport1_Initi;
    }

    /* End of Start for RateTransition: '<S2>/TmpRTBAtUnit Delay4Inport1' */
    /* Start for Scope: '<S7>/Scope' */
    {
      int_T numCols = 2;
      Closed_loop_MPC_DW.Scope_PWORK.LoggedData = rt_CreateLogVar(
        Closed_loop_MPC_M->rtwLogInfo,
        0.0,
        rtmGetTFinal(Closed_loop_MPC_M),
        Closed_loop_MPC_M->Timing.stepSize0,
        (&rtmGetErrorStatus(Closed_loop_MPC_M)),
        "u",
        SS_DOUBLE,
        0,
        0,
        0,
        2,
        1,
        (int_T *)&numCols,
        NO_LOGVALDIMS,
        (NULL),
        (NULL),
        0,
        1,
        0.000244140625,
        1);
      if (Closed_loop_MPC_DW.Scope_PWORK.LoggedData == (NULL))
        return;
    }

    /* Start for DataStoreMemory: '<S5>/DataStoreMemory - P' */
    memcpy(&Closed_loop_MPC_DW.P[0],
           &Closed_loop_MPC_P.DataStoreMemoryP_InitialValue[0], sizeof(real_T) <<
           4U);

    /* Start for DataStoreMemory: '<S5>/DataStoreMemory - x' */
    Closed_loop_MPC_DW.x[0] = Closed_loop_MPC_P.DataStoreMemoryx_InitialValue[0];
    Closed_loop_MPC_DW.x[1] = Closed_loop_MPC_P.DataStoreMemoryx_InitialValue[1];
    Closed_loop_MPC_DW.x[2] = Closed_loop_MPC_P.DataStoreMemoryx_InitialValue[2];
    Closed_loop_MPC_DW.x[3] = Closed_loop_MPC_P.DataStoreMemoryx_InitialValue[3];
  }

  {
    int32_T i;

    /* InitializeConditions for RateTransition: '<Root>/v' */
    Closed_loop_MPC_DW.v_Buffer0 = Closed_loop_MPC_P.v_InitialCondition;

    /* InitializeConditions for UnitDelay: '<S2>/Unit Delay2' */
    Closed_loop_MPC_DW.UnitDelay2_DSTATE[0] =
      Closed_loop_MPC_P.UnitDelay2_InitialCondition;

    /* InitializeConditions for UnitDelay: '<S2>/Unit Delay' */
    Closed_loop_MPC_DW.UnitDelay_DSTATE[0] = Closed_loop_MPC_P.x0[0];

    /* InitializeConditions for UnitDelay: '<S2>/Unit Delay2' */
    Closed_loop_MPC_DW.UnitDelay2_DSTATE[1] =
      Closed_loop_MPC_P.UnitDelay2_InitialCondition;

    /* InitializeConditions for UnitDelay: '<S2>/Unit Delay' */
    Closed_loop_MPC_DW.UnitDelay_DSTATE[1] = Closed_loop_MPC_P.x0[1];

    /* InitializeConditions for UnitDelay: '<S2>/Unit Delay2' */
    Closed_loop_MPC_DW.UnitDelay2_DSTATE[2] =
      Closed_loop_MPC_P.UnitDelay2_InitialCondition;

    /* InitializeConditions for UnitDelay: '<S2>/Unit Delay' */
    Closed_loop_MPC_DW.UnitDelay_DSTATE[2] = Closed_loop_MPC_P.x0[2];

    /* InitializeConditions for UnitDelay: '<S2>/Unit Delay2' */
    Closed_loop_MPC_DW.UnitDelay2_DSTATE[3] =
      Closed_loop_MPC_P.UnitDelay2_InitialCondition;

    /* InitializeConditions for UnitDelay: '<S2>/Unit Delay' */
    Closed_loop_MPC_DW.UnitDelay_DSTATE[3] = Closed_loop_MPC_P.x0[3];
    for (i = 0; i < 6; i++) {
      /* InitializeConditions for UnitDelay: '<S2>/Unit Delay4' */
      Closed_loop_MPC_DW.UnitDelay4_DSTATE[i] =
        Closed_loop_MPC_P.UnitDelay4_InitialCondition;

      /* InitializeConditions for RateTransition: '<S2>/TmpRTBAtMATLAB FunctionInport8' */
      Closed_loop_MPC_DW.TmpRTBAtMATLABFunctionInport8_B[i] =
        Closed_loop_MPC_P.TmpRTBAtMATLABFunctionInport8_I;
    }

    /* InitializeConditions for UnitDelay: '<S2>/Unit Delay3' */
    Closed_loop_MPC_DW.UnitDelay3_DSTATE =
      Closed_loop_MPC_P.UnitDelay3_InitialCondition;

    /* InitializeConditions for RateTransition: '<Root>/u' */
    Closed_loop_MPC_DW.u_Buffer0 = Closed_loop_MPC_P.u_InitialCondition;

    /* InitializeConditions for RateTransition: '<S2>/TmpRTBAtUnit Delay4Inport1' */
    for (i = 0; i < 6; i++) {
      Closed_loop_MPC_DW.TmpRTBAtUnitDelay4Inport1_Buffe[i] =
        Closed_loop_MPC_P.TmpRTBAtUnitDelay4Inport1_Initi;
    }

    /* End of InitializeConditions for RateTransition: '<S2>/TmpRTBAtUnit Delay4Inport1' */

    /* InitializeConditions for UnitDelay: '<S2>/Unit Delay1' */
    for (i = 0; i < 6; i++) {
      Closed_loop_MPC_DW.UnitDelay1_DSTATE[i] =
        Closed_loop_MPC_P.UnitDelay1_InitialCondition;
    }

    /* End of InitializeConditions for UnitDelay: '<S2>/Unit Delay1' */
  }
}

/* Model terminate function */
void Closed_loop_MPC_terminate(void)
{
  /* Terminate for S-Function (ec_EL3102_adc): '<S10>/ec_EL3102_adc' */
  /* Level2 S-Function Block: '<S10>/ec_EL3102_adc' (ec_EL3102_adc) */
  {
    SimStruct *rts = Closed_loop_MPC_M->childSfunctions[0];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (ec_EL3102_adc): '<S12>/ec_EL3102_adc' */
  /* Level2 S-Function Block: '<S12>/ec_EL3102_adc' (ec_EL3102_adc) */
  {
    SimStruct *rts = Closed_loop_MPC_M->childSfunctions[1];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (ec_EL3102_adc): '<S11>/ec_EL3102_adc' */
  /* Level2 S-Function Block: '<S11>/ec_EL3102_adc' (ec_EL3102_adc) */
  {
    SimStruct *rts = Closed_loop_MPC_M->childSfunctions[2];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (ec_EL4132_dac): '<S13>/ec_EL4132_dac' */
  /* Level2 S-Function Block: '<S13>/ec_EL4132_dac' (ec_EL4132_dac) */
  {
    SimStruct *rts = Closed_loop_MPC_M->childSfunctions[3];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (ec_EL4132_dac): '<S14>/ec_EL4132_dac' */
  /* Level2 S-Function Block: '<S14>/ec_EL4132_dac' (ec_EL4132_dac) */
  {
    SimStruct *rts = Closed_loop_MPC_M->childSfunctions[4];
    sfcnTerminate(rts);
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/
void MdlOutputs(int_T tid)
{
  if (tid == 1)
    tid = 0;
  Closed_loop_MPC_output(tid);
}

void MdlUpdate(int_T tid)
{
  if (tid == 1)
    tid = 0;
  Closed_loop_MPC_update(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  Closed_loop_MPC_initialize();
}

void MdlTerminate(void)
{
  Closed_loop_MPC_terminate();
}

/* Registration function */
RT_MODEL_Closed_loop_MPC_T *Closed_loop_MPC(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)Closed_loop_MPC_M, 0,
                sizeof(RT_MODEL_Closed_loop_MPC_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&Closed_loop_MPC_M->solverInfo,
                          &Closed_loop_MPC_M->Timing.simTimeStep);
    rtsiSetTPtr(&Closed_loop_MPC_M->solverInfo, &rtmGetTPtr(Closed_loop_MPC_M));
    rtsiSetStepSizePtr(&Closed_loop_MPC_M->solverInfo,
                       &Closed_loop_MPC_M->Timing.stepSize0);
    rtsiSetErrorStatusPtr(&Closed_loop_MPC_M->solverInfo, (&rtmGetErrorStatus
      (Closed_loop_MPC_M)));
    rtsiSetRTModelPtr(&Closed_loop_MPC_M->solverInfo, Closed_loop_MPC_M);
  }

  rtsiSetSimTimeStep(&Closed_loop_MPC_M->solverInfo, MAJOR_TIME_STEP);
  rtsiSetSolverName(&Closed_loop_MPC_M->solverInfo,"FixedStepDiscrete");
  Closed_loop_MPC_M->solverInfoPtr = (&Closed_loop_MPC_M->solverInfo);

  /* Initialize timing info */
  {
    int_T *mdlTsMap = Closed_loop_MPC_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    mdlTsMap[2] = 2;
    mdlTsMap[3] = 3;
    Closed_loop_MPC_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    Closed_loop_MPC_M->Timing.sampleTimes =
      (&Closed_loop_MPC_M->Timing.sampleTimesArray[0]);
    Closed_loop_MPC_M->Timing.offsetTimes =
      (&Closed_loop_MPC_M->Timing.offsetTimesArray[0]);

    /* task periods */
    Closed_loop_MPC_M->Timing.sampleTimes[0] = (0.0);
    Closed_loop_MPC_M->Timing.sampleTimes[1] = (0.000244140625);
    Closed_loop_MPC_M->Timing.sampleTimes[2] = (0.001953125);
    Closed_loop_MPC_M->Timing.sampleTimes[3] = (0.009765625);

    /* task offsets */
    Closed_loop_MPC_M->Timing.offsetTimes[0] = (0.0);
    Closed_loop_MPC_M->Timing.offsetTimes[1] = (0.0);
    Closed_loop_MPC_M->Timing.offsetTimes[2] = (0.0);
    Closed_loop_MPC_M->Timing.offsetTimes[3] = (0.0);
  }

  rtmSetTPtr(Closed_loop_MPC_M, &Closed_loop_MPC_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = Closed_loop_MPC_M->Timing.sampleHitArray;
    int_T *mdlPerTaskSampleHits =
      Closed_loop_MPC_M->Timing.perTaskSampleHitsArray;
    Closed_loop_MPC_M->Timing.perTaskSampleHits = (&mdlPerTaskSampleHits[0]);
    mdlSampleHits[0] = 1;
    Closed_loop_MPC_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(Closed_loop_MPC_M, 40.037109375);
  Closed_loop_MPC_M->Timing.stepSize0 = 0.000244140625;
  Closed_loop_MPC_M->Timing.stepSize1 = 0.000244140625;
  Closed_loop_MPC_M->Timing.stepSize2 = 0.001953125;
  Closed_loop_MPC_M->Timing.stepSize3 = 0.009765625;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = NULL;
    Closed_loop_MPC_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(Closed_loop_MPC_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(Closed_loop_MPC_M->rtwLogInfo, (NULL));
    rtliSetLogT(Closed_loop_MPC_M->rtwLogInfo, "tout");
    rtliSetLogX(Closed_loop_MPC_M->rtwLogInfo, "");
    rtliSetLogXFinal(Closed_loop_MPC_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(Closed_loop_MPC_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(Closed_loop_MPC_M->rtwLogInfo, 0);
    rtliSetLogMaxRows(Closed_loop_MPC_M->rtwLogInfo, 0);
    rtliSetLogDecimation(Closed_loop_MPC_M->rtwLogInfo, 1);
    rtliSetLogY(Closed_loop_MPC_M->rtwLogInfo, "");
    rtliSetLogYSignalInfo(Closed_loop_MPC_M->rtwLogInfo, (NULL));
    rtliSetLogYSignalPtrs(Closed_loop_MPC_M->rtwLogInfo, (NULL));
  }

  /* External mode info */
  Closed_loop_MPC_M->Sizes.checksums[0] = (1754505918U);
  Closed_loop_MPC_M->Sizes.checksums[1] = (3415825128U);
  Closed_loop_MPC_M->Sizes.checksums[2] = (1573215694U);
  Closed_loop_MPC_M->Sizes.checksums[3] = (231559499U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[7];
    Closed_loop_MPC_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    systemRan[2] = (sysRanDType *)&Closed_loop_MPC_DW.Correct1_SubsysRanBC;
    systemRan[3] = (sysRanDType *)&Closed_loop_MPC_DW.Correct1_SubsysRanBC;
    systemRan[4] = &rtAlwaysEnabled;
    systemRan[5] = &rtAlwaysEnabled;
    systemRan[6] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(Closed_loop_MPC_M->extModeInfo,
      &Closed_loop_MPC_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(Closed_loop_MPC_M->extModeInfo,
                        Closed_loop_MPC_M->Sizes.checksums);
    rteiSetTPtr(Closed_loop_MPC_M->extModeInfo, rtmGetTPtr(Closed_loop_MPC_M));
  }

  Closed_loop_MPC_M->solverInfoPtr = (&Closed_loop_MPC_M->solverInfo);
  Closed_loop_MPC_M->Timing.stepSize = (0.000244140625);
  rtsiSetFixedStepSize(&Closed_loop_MPC_M->solverInfo, 0.000244140625);
  rtsiSetSolverMode(&Closed_loop_MPC_M->solverInfo, SOLVER_MODE_MULTITASKING);

  /* block I/O */
  Closed_loop_MPC_M->blockIO = ((void *) &Closed_loop_MPC_B);
  (void) memset(((void *) &Closed_loop_MPC_B), 0,
                sizeof(B_Closed_loop_MPC_T));

  {
    int32_T i;
    for (i = 0; i < 6; i++) {
      Closed_loop_MPC_B.TmpRTBAtMATLABFunctionInport8[i] = 0.0;
    }

    for (i = 0; i < 6; i++) {
      Closed_loop_MPC_B.TmpRTBAtMATLABFunctionOutport4[i] = 0.0;
    }

    for (i = 0; i < 6; i++) {
      Closed_loop_MPC_B.TmpRTBAtUnitDelay4Inport1[i] = 0.0;
    }

    for (i = 0; i < 6; i++) {
      Closed_loop_MPC_B.UnitDelay1[i] = 0.0;
    }

    Closed_loop_MPC_B.ec_EL3102_adc_a[0] = 0.0;
    Closed_loop_MPC_B.ec_EL3102_adc_a[1] = 0.0;
    Closed_loop_MPC_B.Gain9 = 0.0;
    Closed_loop_MPC_B.Gain8 = 0.0;
    Closed_loop_MPC_B.ec_EL3102_adc_f[0] = 0.0;
    Closed_loop_MPC_B.ec_EL3102_adc_f[1] = 0.0;
    Closed_loop_MPC_B.Gain7 = 0.0;
    Closed_loop_MPC_B.Gain6 = 0.0;
    Closed_loop_MPC_B.ec_EL3102_adc_m[0] = 0.0;
    Closed_loop_MPC_B.ec_EL3102_adc_m[1] = 0.0;
    Closed_loop_MPC_B.Gain5 = 0.0;
    Closed_loop_MPC_B.y = 0.0;
    Closed_loop_MPC_B.Sum = 0.0;
    Closed_loop_MPC_B.ZeroOrderHold = 0.0;
    Closed_loop_MPC_B.Gain1 = 0.0;
    Closed_loop_MPC_B.v = 0.0;
    Closed_loop_MPC_B.u = 0.0;
    Closed_loop_MPC_B.u_l = 0.0;
    Closed_loop_MPC_B.utot = 0.0;
    Closed_loop_MPC_B.ZeroOrderHold1 = 0.0;
    Closed_loop_MPC_B.TmpRTBAtToWorkspace5Inport1 = 0.0;
    Closed_loop_MPC_B.v_a = 0.0;
    Closed_loop_MPC_B.y_refMPC = 0.0;
    Closed_loop_MPC_B.e = 0.0;
    Closed_loop_MPC_B.e_c = 0.0;
    Closed_loop_MPC_B.Saturation = 0.0;
    Closed_loop_MPC_B.Saturation1 = 0.0;
    Closed_loop_MPC_B.Saturation2 = 0.0;
    Closed_loop_MPC_B.Saturation2_e = 0.0;
    Closed_loop_MPC_B.DataStoreRead[0] = 0.0;
    Closed_loop_MPC_B.DataStoreRead[1] = 0.0;
    Closed_loop_MPC_B.DataStoreRead[2] = 0.0;
    Closed_loop_MPC_B.DataStoreRead[3] = 0.0;
    Closed_loop_MPC_B.xref1[0] = 0.0;
    Closed_loop_MPC_B.xref1[1] = 0.0;
    Closed_loop_MPC_B.xref1[2] = 0.0;
    Closed_loop_MPC_B.xref1[3] = 0.0;
  }

  /* parameters */
  Closed_loop_MPC_M->defaultParam = ((real_T *)&Closed_loop_MPC_P);

  /* states (dwork) */
  Closed_loop_MPC_M->dwork = ((void *) &Closed_loop_MPC_DW);
  (void) memset((void *)&Closed_loop_MPC_DW, 0,
                sizeof(DW_Closed_loop_MPC_T));
  Closed_loop_MPC_DW.UnitDelay2_DSTATE[0] = 0.0;
  Closed_loop_MPC_DW.UnitDelay2_DSTATE[1] = 0.0;
  Closed_loop_MPC_DW.UnitDelay2_DSTATE[2] = 0.0;
  Closed_loop_MPC_DW.UnitDelay2_DSTATE[3] = 0.0;
  Closed_loop_MPC_DW.UnitDelay_DSTATE[0] = 0.0;
  Closed_loop_MPC_DW.UnitDelay_DSTATE[1] = 0.0;
  Closed_loop_MPC_DW.UnitDelay_DSTATE[2] = 0.0;
  Closed_loop_MPC_DW.UnitDelay_DSTATE[3] = 0.0;

  {
    int32_T i;
    for (i = 0; i < 6; i++) {
      Closed_loop_MPC_DW.UnitDelay4_DSTATE[i] = 0.0;
    }
  }

  Closed_loop_MPC_DW.UnitDelay3_DSTATE = 0.0;

  {
    int32_T i;
    for (i = 0; i < 6; i++) {
      Closed_loop_MPC_DW.UnitDelay1_DSTATE[i] = 0.0;
    }
  }

  Closed_loop_MPC_DW.v_Buffer0 = 0.0;

  {
    int32_T i;
    for (i = 0; i < 6; i++) {
      Closed_loop_MPC_DW.TmpRTBAtMATLABFunctionInport8_B[i] = 0.0;
    }
  }

  Closed_loop_MPC_DW.u_Buffer0 = 0.0;

  {
    int32_T i;
    for (i = 0; i < 6; i++) {
      Closed_loop_MPC_DW.TmpRTBAtUnitDelay4Inport1_Buffe[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 16; i++) {
      Closed_loop_MPC_DW.P[i] = 0.0;
    }
  }

  Closed_loop_MPC_DW.x[0] = 0.0;
  Closed_loop_MPC_DW.x[1] = 0.0;
  Closed_loop_MPC_DW.x[2] = 0.0;
  Closed_loop_MPC_DW.x[3] = 0.0;

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    Closed_loop_MPC_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 17;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* child S-Function registration */
  {
    RTWSfcnInfo *sfcnInfo = &Closed_loop_MPC_M->NonInlinedSFcns.sfcnInfo;
    Closed_loop_MPC_M->sfcnInfo = (sfcnInfo);
    rtssSetErrorStatusPtr(sfcnInfo, (&rtmGetErrorStatus(Closed_loop_MPC_M)));
    rtssSetNumRootSampTimesPtr(sfcnInfo, &Closed_loop_MPC_M->Sizes.numSampTimes);
    Closed_loop_MPC_M->NonInlinedSFcns.taskTimePtrs[0] = &(rtmGetTPtr
      (Closed_loop_MPC_M)[0]);
    Closed_loop_MPC_M->NonInlinedSFcns.taskTimePtrs[1] = &(rtmGetTPtr
      (Closed_loop_MPC_M)[1]);
    Closed_loop_MPC_M->NonInlinedSFcns.taskTimePtrs[2] = &(rtmGetTPtr
      (Closed_loop_MPC_M)[2]);
    Closed_loop_MPC_M->NonInlinedSFcns.taskTimePtrs[3] = &(rtmGetTPtr
      (Closed_loop_MPC_M)[3]);
    rtssSetTPtrPtr(sfcnInfo,Closed_loop_MPC_M->NonInlinedSFcns.taskTimePtrs);
    rtssSetTStartPtr(sfcnInfo, &rtmGetTStart(Closed_loop_MPC_M));
    rtssSetTFinalPtr(sfcnInfo, &rtmGetTFinal(Closed_loop_MPC_M));
    rtssSetTimeOfLastOutputPtr(sfcnInfo, &rtmGetTimeOfLastOutput
      (Closed_loop_MPC_M));
    rtssSetStepSizePtr(sfcnInfo, &Closed_loop_MPC_M->Timing.stepSize);
    rtssSetStopRequestedPtr(sfcnInfo, &rtmGetStopRequested(Closed_loop_MPC_M));
    rtssSetDerivCacheNeedsResetPtr(sfcnInfo,
      &Closed_loop_MPC_M->derivCacheNeedsReset);
    rtssSetZCCacheNeedsResetPtr(sfcnInfo, &Closed_loop_MPC_M->zCCacheNeedsReset);
    rtssSetContTimeOutputInconsistentWithStateAtMajorStepPtr(sfcnInfo,
      &Closed_loop_MPC_M->CTOutputIncnstWithState);
    rtssSetSampleHitsPtr(sfcnInfo, &Closed_loop_MPC_M->Timing.sampleHits);
    rtssSetPerTaskSampleHitsPtr(sfcnInfo,
      &Closed_loop_MPC_M->Timing.perTaskSampleHits);
    rtssSetSimModePtr(sfcnInfo, &Closed_loop_MPC_M->simMode);
    rtssSetSolverInfoPtr(sfcnInfo, &Closed_loop_MPC_M->solverInfoPtr);
  }

  Closed_loop_MPC_M->Sizes.numSFcns = (5);

  /* register each child */
  {
    (void) memset((void *)&Closed_loop_MPC_M->NonInlinedSFcns.childSFunctions[0],
                  0,
                  5*sizeof(SimStruct));
    Closed_loop_MPC_M->childSfunctions =
      (&Closed_loop_MPC_M->NonInlinedSFcns.childSFunctionPtrs[0]);

    {
      int_T i;
      for (i = 0; i < 5; i++) {
        Closed_loop_MPC_M->childSfunctions[i] =
          (&Closed_loop_MPC_M->NonInlinedSFcns.childSFunctions[i]);
      }
    }

    /* Level2 S-Function Block: Closed_loop_MPC/<S10>/ec_EL3102_adc (ec_EL3102_adc) */
    {
      SimStruct *rts = Closed_loop_MPC_M->childSfunctions[0];

      /* timing info */
      time_T *sfcnPeriod = Closed_loop_MPC_M->NonInlinedSFcns.Sfcn0.sfcnPeriod;
      time_T *sfcnOffset = Closed_loop_MPC_M->NonInlinedSFcns.Sfcn0.sfcnOffset;
      int_T *sfcnTsMap = Closed_loop_MPC_M->NonInlinedSFcns.Sfcn0.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &Closed_loop_MPC_M->NonInlinedSFcns.blkInfo2[0]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &Closed_loop_MPC_M->NonInlinedSFcns.inputOutputPortInfo2[0]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, Closed_loop_MPC_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &Closed_loop_MPC_M->NonInlinedSFcns.methods2[0]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &Closed_loop_MPC_M->NonInlinedSFcns.methods3[0]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &Closed_loop_MPC_M->NonInlinedSFcns.methods4[0]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &Closed_loop_MPC_M->NonInlinedSFcns.statesInfo2[0]);
        ssSetPeriodicStatesInfo(rts,
          &Closed_loop_MPC_M->NonInlinedSFcns.periodicStatesInfo[0]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &Closed_loop_MPC_M->NonInlinedSFcns.Sfcn0.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);
        _ssSetPortInfo2ForOutputUnits(rts,
          &Closed_loop_MPC_M->NonInlinedSFcns.Sfcn0.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &Closed_loop_MPC_M->NonInlinedSFcns.Sfcn0.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 2);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            Closed_loop_MPC_B.ec_EL3102_adc_a));
        }
      }

      /* path info */
      ssSetModelName(rts, "ec_EL3102_adc");
      ssSetPath(rts,
                "Closed_loop_MPC/Plant1/Inputs and outputs/EL3102/ec_EL3102_adc");
      ssSetRTModel(rts,Closed_loop_MPC_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &Closed_loop_MPC_M->NonInlinedSFcns.Sfcn0.params;
        ssSetSFcnParamsCount(rts, 1);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)Closed_loop_MPC_P.ec_EL3102_adc_P1_Size);
      }

      /* registration */
      ec_EL3102_adc(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.0);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: Closed_loop_MPC/<S12>/ec_EL3102_adc (ec_EL3102_adc) */
    {
      SimStruct *rts = Closed_loop_MPC_M->childSfunctions[1];

      /* timing info */
      time_T *sfcnPeriod = Closed_loop_MPC_M->NonInlinedSFcns.Sfcn1.sfcnPeriod;
      time_T *sfcnOffset = Closed_loop_MPC_M->NonInlinedSFcns.Sfcn1.sfcnOffset;
      int_T *sfcnTsMap = Closed_loop_MPC_M->NonInlinedSFcns.Sfcn1.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &Closed_loop_MPC_M->NonInlinedSFcns.blkInfo2[1]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &Closed_loop_MPC_M->NonInlinedSFcns.inputOutputPortInfo2[1]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, Closed_loop_MPC_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &Closed_loop_MPC_M->NonInlinedSFcns.methods2[1]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &Closed_loop_MPC_M->NonInlinedSFcns.methods3[1]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &Closed_loop_MPC_M->NonInlinedSFcns.methods4[1]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &Closed_loop_MPC_M->NonInlinedSFcns.statesInfo2[1]);
        ssSetPeriodicStatesInfo(rts,
          &Closed_loop_MPC_M->NonInlinedSFcns.periodicStatesInfo[1]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &Closed_loop_MPC_M->NonInlinedSFcns.Sfcn1.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);
        _ssSetPortInfo2ForOutputUnits(rts,
          &Closed_loop_MPC_M->NonInlinedSFcns.Sfcn1.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &Closed_loop_MPC_M->NonInlinedSFcns.Sfcn1.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 2);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            Closed_loop_MPC_B.ec_EL3102_adc_f));
        }
      }

      /* path info */
      ssSetModelName(rts, "ec_EL3102_adc");
      ssSetPath(rts,
                "Closed_loop_MPC/Plant1/Inputs and outputs/EL3102_2/ec_EL3102_adc");
      ssSetRTModel(rts,Closed_loop_MPC_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &Closed_loop_MPC_M->NonInlinedSFcns.Sfcn1.params;
        ssSetSFcnParamsCount(rts, 1);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       Closed_loop_MPC_P.ec_EL3102_adc_P1_Size_j);
      }

      /* registration */
      ec_EL3102_adc(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.0);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: Closed_loop_MPC/<S11>/ec_EL3102_adc (ec_EL3102_adc) */
    {
      SimStruct *rts = Closed_loop_MPC_M->childSfunctions[2];

      /* timing info */
      time_T *sfcnPeriod = Closed_loop_MPC_M->NonInlinedSFcns.Sfcn2.sfcnPeriod;
      time_T *sfcnOffset = Closed_loop_MPC_M->NonInlinedSFcns.Sfcn2.sfcnOffset;
      int_T *sfcnTsMap = Closed_loop_MPC_M->NonInlinedSFcns.Sfcn2.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &Closed_loop_MPC_M->NonInlinedSFcns.blkInfo2[2]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &Closed_loop_MPC_M->NonInlinedSFcns.inputOutputPortInfo2[2]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, Closed_loop_MPC_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &Closed_loop_MPC_M->NonInlinedSFcns.methods2[2]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &Closed_loop_MPC_M->NonInlinedSFcns.methods3[2]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &Closed_loop_MPC_M->NonInlinedSFcns.methods4[2]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &Closed_loop_MPC_M->NonInlinedSFcns.statesInfo2[2]);
        ssSetPeriodicStatesInfo(rts,
          &Closed_loop_MPC_M->NonInlinedSFcns.periodicStatesInfo[2]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &Closed_loop_MPC_M->NonInlinedSFcns.Sfcn2.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);
        _ssSetPortInfo2ForOutputUnits(rts,
          &Closed_loop_MPC_M->NonInlinedSFcns.Sfcn2.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &Closed_loop_MPC_M->NonInlinedSFcns.Sfcn2.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 2);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            Closed_loop_MPC_B.ec_EL3102_adc_m));
        }
      }

      /* path info */
      ssSetModelName(rts, "ec_EL3102_adc");
      ssSetPath(rts,
                "Closed_loop_MPC/Plant1/Inputs and outputs/EL3102_1/ec_EL3102_adc");
      ssSetRTModel(rts,Closed_loop_MPC_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &Closed_loop_MPC_M->NonInlinedSFcns.Sfcn2.params;
        ssSetSFcnParamsCount(rts, 1);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       Closed_loop_MPC_P.ec_EL3102_adc_P1_Size_k);
      }

      /* registration */
      ec_EL3102_adc(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.0);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: Closed_loop_MPC/<S13>/ec_EL4132_dac (ec_EL4132_dac) */
    {
      SimStruct *rts = Closed_loop_MPC_M->childSfunctions[3];

      /* timing info */
      time_T *sfcnPeriod = Closed_loop_MPC_M->NonInlinedSFcns.Sfcn3.sfcnPeriod;
      time_T *sfcnOffset = Closed_loop_MPC_M->NonInlinedSFcns.Sfcn3.sfcnOffset;
      int_T *sfcnTsMap = Closed_loop_MPC_M->NonInlinedSFcns.Sfcn3.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &Closed_loop_MPC_M->NonInlinedSFcns.blkInfo2[3]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &Closed_loop_MPC_M->NonInlinedSFcns.inputOutputPortInfo2[3]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, Closed_loop_MPC_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &Closed_loop_MPC_M->NonInlinedSFcns.methods2[3]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &Closed_loop_MPC_M->NonInlinedSFcns.methods3[3]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &Closed_loop_MPC_M->NonInlinedSFcns.methods4[3]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &Closed_loop_MPC_M->NonInlinedSFcns.statesInfo2[3]);
        ssSetPeriodicStatesInfo(rts,
          &Closed_loop_MPC_M->NonInlinedSFcns.periodicStatesInfo[3]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &Closed_loop_MPC_M->NonInlinedSFcns.Sfcn3.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &Closed_loop_MPC_M->NonInlinedSFcns.Sfcn3.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &Closed_loop_MPC_M->NonInlinedSFcns.Sfcn3.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &Closed_loop_MPC_M->NonInlinedSFcns.Sfcn3.UPtrs0;
          sfcnUPtrs[0] = &Closed_loop_MPC_B.Saturation;
          sfcnUPtrs[1] = &Closed_loop_MPC_B.Saturation1;
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 2);
        }
      }

      /* path info */
      ssSetModelName(rts, "ec_EL4132_dac");
      ssSetPath(rts,
                "Closed_loop_MPC/Plant1/Inputs and outputs/EL4132/ec_EL4132_dac");
      ssSetRTModel(rts,Closed_loop_MPC_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &Closed_loop_MPC_M->NonInlinedSFcns.Sfcn3.params;
        ssSetSFcnParamsCount(rts, 1);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)Closed_loop_MPC_P.ec_EL4132_dac_P1_Size);
      }

      /* registration */
      ec_EL4132_dac(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.0);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: Closed_loop_MPC/<S14>/ec_EL4132_dac (ec_EL4132_dac) */
    {
      SimStruct *rts = Closed_loop_MPC_M->childSfunctions[4];

      /* timing info */
      time_T *sfcnPeriod = Closed_loop_MPC_M->NonInlinedSFcns.Sfcn4.sfcnPeriod;
      time_T *sfcnOffset = Closed_loop_MPC_M->NonInlinedSFcns.Sfcn4.sfcnOffset;
      int_T *sfcnTsMap = Closed_loop_MPC_M->NonInlinedSFcns.Sfcn4.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &Closed_loop_MPC_M->NonInlinedSFcns.blkInfo2[4]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &Closed_loop_MPC_M->NonInlinedSFcns.inputOutputPortInfo2[4]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, Closed_loop_MPC_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &Closed_loop_MPC_M->NonInlinedSFcns.methods2[4]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &Closed_loop_MPC_M->NonInlinedSFcns.methods3[4]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &Closed_loop_MPC_M->NonInlinedSFcns.methods4[4]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &Closed_loop_MPC_M->NonInlinedSFcns.statesInfo2[4]);
        ssSetPeriodicStatesInfo(rts,
          &Closed_loop_MPC_M->NonInlinedSFcns.periodicStatesInfo[4]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &Closed_loop_MPC_M->NonInlinedSFcns.Sfcn4.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &Closed_loop_MPC_M->NonInlinedSFcns.Sfcn4.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &Closed_loop_MPC_M->NonInlinedSFcns.Sfcn4.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &Closed_loop_MPC_M->NonInlinedSFcns.Sfcn4.UPtrs0;
          sfcnUPtrs[0] = &Closed_loop_MPC_B.Saturation2;
          sfcnUPtrs[1] = &Closed_loop_MPC_B.Saturation2_e;
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 2);
        }
      }

      /* path info */
      ssSetModelName(rts, "ec_EL4132_dac");
      ssSetPath(rts,
                "Closed_loop_MPC/Plant1/Inputs and outputs/EL4132 2/ec_EL4132_dac");
      ssSetRTModel(rts,Closed_loop_MPC_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &Closed_loop_MPC_M->NonInlinedSFcns.Sfcn4.params;
        ssSetSFcnParamsCount(rts, 1);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       Closed_loop_MPC_P.ec_EL4132_dac_P1_Size_n);
      }

      /* registration */
      ec_EL4132_dac(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.0);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }
  }

  /* Initialize Sizes */
  Closed_loop_MPC_M->Sizes.numContStates = (0);/* Number of continuous states */
  Closed_loop_MPC_M->Sizes.numY = (0); /* Number of model outputs */
  Closed_loop_MPC_M->Sizes.numU = (0); /* Number of model inputs */
  Closed_loop_MPC_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  Closed_loop_MPC_M->Sizes.numSampTimes = (4);/* Number of sample times */
  Closed_loop_MPC_M->Sizes.numBlocks = (113);/* Number of blocks */
  Closed_loop_MPC_M->Sizes.numBlockIO = (35);/* Number of block outputs */
  Closed_loop_MPC_M->Sizes.numBlockPrms = (176);/* Sum of parameter "widths" */
  return Closed_loop_MPC_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
