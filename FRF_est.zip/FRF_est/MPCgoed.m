function [u_MPC,Ntot,xref1,yref_] = MPCgoed(v,clock,x,xprev,yref0,xref0,yref,yrefprev,mpc)
%% Extract struct
ts_out = mpc.ts_out;
ts_in = mpc.ts_in;
Nmin = mpc.N;
Ad = mpc.Ad;
Bd = mpc.Bd;
C = mpc.C;
osd = mpc.osd;

n = size(Ad,1);
p = n + 1;

%% Find dynamic prediction horizon length
tmod = mod(clock,ts_out);
Ndyn = round(-1/ts_in*tmod + Nmin);

%% Future reference generation
v = v*ones(1,Ndyn);
xref = zeros(n,Ndyn+1);
yref_ = yref0;
xref(:,1) = xref0;
for k = 1:Ndyn
    xref(:,k+1) = Ad*xref(:,k) + Bd*v(k);
    yref_(k+1) = C*xref(:,k+1);
end
xref1 = xref(:,2);

%% MPC
% Wait one period before becoming active (if osd == 1)
if clock < ts_out && osd == 1
    u_MPC = 0;
    Ntot = 0;
    return
end

% Augmented state vector
y = C*x;
xaug = [x - xprev; y];
yprev = C*xprev;

% Current reference and disturbance vector
if osd == 1
   yrefprev = yrefprev(:);
   yref = yref(:);
   if Nmin == Ndyn
      yrefnow = [yrefprev(end-Ndyn+1:end); yref_(2:end)]; 
   else
      yrefnow = [yrefprev(end-Ndyn+1:end); yref(2:end)];
   end
   g = [y; yrefnow(1:end-1)].^3;
   gprev = [yprev; y; yrefnow(1:end-2)].^3;
   Ntot = Nmin + Ndyn;
else   
   yrefnow = yref_(2:1+Ndyn);
   yrefnow = yrefnow(:);
   if Ndyn == 1
       g = y^3;
       gprev = yprev.^3;
   elseif Ndyn == 2
       g = [y; yrefnow(1)].^3;
       gprev = [yprev; y].^3;
   else
       g = [y; yrefnow(1:end-1)].^3;
       gprev = [yprev; y; yrefnow(1:end-2)].^3;
    end
    Ntot = Ndyn;
end
delta_g = g - gprev;

% MPC cost matrices
Sx = mpc.Sx(1:Ntot,:);
Su = mpc.Su(1:Ntot,1:Ntot);
Sg = mpc.Sg(1:Ntot,1:Ntot);
Omega = mpc.Omega(1:Ntot,1:Ntot);
Psi = mpc.Psi(1:Ntot,1:Ntot);

G = 2*(Psi + Su'*Omega*Su);
F = 2*Su'*Omega;
GinvF = G\F;

uN = -GinvF*(Sx*xaug + Sg*delta_g - yrefnow);

% uN = -mpc.GinvFSx(1:Ntot,(Ndyn-1)*p+1:p*Ndyn)*xaug - mpc.GinvFSg(1:Ntot,mpc.Nidx(Ndyn):mpc.Nidx(Ndyn+1)-1)*delta_g + mpc.GinvF(1:Ntot,mpc.Nidx(Ndyn):mpc.Nidx(Ndyn+1)-1)*yrefnow;
u_MPC = [1 zeros(1,Ntot-1)]*uN;
end   


