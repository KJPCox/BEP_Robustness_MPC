clear all;close all;clc;
load('y_offset')

%% Load model
load('MdlfullNLD')
%load('model_n4')
Ad = NLModel.A;
Bd = NLModel.B;
Cc = NLModel.C;
Ed = NLModel.E;
kc = 2e9;
alpha = 1;
%% MPC
input = 0; % type of input signal (multisine = 0; sine = 1)
MPCswitch = 1; % (1 == on; 0 == off)0
% Plant sample frequency (DONT CHANGE)
fs = 4096;
Ts = 1/fs;

% MPC tuning knobs
fs_mpc = 512; % [Hz] MPC sample rate
N = 5; % maximal prediction horizon 
Q = 3e8; % penalisation weight for output reference deviation
R = 1; % penalisation weight for input rate of change

Q_UKF = 5*eye(4);
R_UKF = 1;
ts_in = 1/fs_mpc;
ts_out = N*ts_in;   
fs_out = 1/ts_out;

switch input
    case 0    
     %% Create multisine
    fs = 1/ts_out;        % [Hz] sampling frequency
    ts = 1/fs;      % [s] sampling time
    N_ = 820;       % number of samples per period
    fres = fs/N_;    % [Hz] frequency resolution for FULL multisine
    P = 5;          % number of periods
    R_ = 2;         % number of realisations
    Amp = 0.015;        % [N] RMS value of the multisine amplitude
    fmax = fs/2;       % [Hz] maximal excited frequency
    type = 'odd';  % type of multisine {odd,full}
    ngroup = 4;   % number of lines among which a detection line is randomly selected

    [u,exclines,non_odd,non_even] = fMultisine(fs,N_,P,R_,Amp,type,[],fmax,ngroup);

    t = linspace(0,N_*P*ts-ts,N_*P);
    tsim_ = t(end)+(N-1)*ts_in;
    
    disp(['Pure experiment time: ',num2str(P*N_/fs*R_),' s'])
    
    case 1
    % Sine excitation parameters
    Amp = 0.02;
    sin_int = 256;
    fe = fs_mpc/sin_int;
    numper = 30;
    tsim = numper*1/fe;

    % Construct outer-loop excitation signal 
    t = 0:ts_out:tsim;
    t_ = tsim+ts_out:ts_out:2*tsim+ts_out;
    v = Amp*sin(2*pi*fe*t);
    t__ = [t t_];
    v__ = [v.*linspace(0.5,1,length(t)) v];
    tsim_ = t__(end);
end

% Discretise again with new sample time
sysd = d2d(ss(Ad,[Bd Ed],Cc,0,1/NLModel.fs),ts_in);
Ad = sysd.a; Bd = sysd.b(:,1); Ed = sysd.b(:,2:end);

% Augmented model with:
% - State vector [delta_x; y]
% - Control input delta_u
% - Disturbance input delta_g
n = size(Ad,1);
q = size(Cc,1);
A_ = [Ad zeros(n,q); Cc*Ad eye(q)];
B_ = [Bd; Cc*Bd];
E_ = [Ed; Cc*Ed];
C_ = [zeros(q,n) eye(q)];

disp(['Outer-loop sample time: ',num2str(ts_in*N),' s   [',num2str(1/(ts_in*N)),' Hz]']);

%% Calculate prediction matrices
[mpc.Sx,mpc.Su,mpc.Sg,mpc.Omega,mpc.Psi] = impcpredmats(A_,B_,C_,E_,Q,Q,R,N);

% Store important data in struct
mpc.N = N;
mpc.Ad = Ad;
mpc.Bd = Bd;
mpc.C = Cc;
mpc.ts_in = ts_in;
mpc.ts_out = ts_out;
osd = 0;
mpc.osd = osd;

%% Experiment
% Load calibration details: offset, polynomials, and gain scalings
load('/home/ebox/Kevin/calibration_parameters.mat')

% Initialise experiment
open('Closed_loop_MPC.mdl')
x0 = zeros(4,1);

switch input
    case 0
    y = zeros(N*N_,P,R_);
    y_original = zeros(N*N_,P,R_);
    %for k = 1:R_
    for k=1
        disp(['Realisation: ',num2str(k),' of ',num2str(R_)]);

        
        % Assign input signals
        uff.time = t';
        uff.signals.dimensions = 1;
        v = reshape(u(:,:,k),N_*P,1)';
        uff.signals.values = v';
        
        assign_closed_loop_MPC;
    
        % Perform experiment
        clear Closed_loop_MPC.mat
        rtwbuild('Closed_loop_MPC')
        !./Closed_loop_MPC
        
        % Retrieve data
        load('Closed_loop_MPC.mat')

        y(:,:,k) = reshape(rt_yfb_sinspec,N*N_,P);
    end
    data.u = u; % [N x P x R]
    data.y = y;
    data.Amp = Amp;
    data.type = type;
    data.ngroup = ngroup;
    data.fs = fs;
    data.fs_mpc = fs_mpc;
    data.fres = fres; % frequency resolution for FULL multisine
    data.fmax = fmax;
    data.exclines = exclines;
    data.non_even = non_even;
    data.non_odd = non_odd;
    data.t = rt_tout;
    data.kc = kc;
    
    y_offset = mean(rt_yreal);
    save('y_offset','y_offset');

    %% Data analyis
    Ptr = 1; % number of rejected transient periods

    % Remove transients
    y = y(:,1+Ptr:P,:);
  
    % FFT
    Y = fft(y);

    % Nonlinear distortion analysis
    [PY,PstdY,f] = fSingleSidedAmplitudeSpectrum(Y,fs_mpc);
    PY_conv = PY;
    PstdY_conv = PstdY;
    f_conv = f;
    PY(1) = []; PstdY(1) = []; f(1) = []; non_even(1) = []; % Exclude DC frequency
    
    %%
%     f_filter = find(f > 20);
%     PY_db = mag2db(PY);
%     PY_db(f_filter) = 0;
%     PstdY_db = mag2db(PstdY);
%     PstdY_db(f_filter) = 0;
%     
%     figure
%     hold on                                               
%     plot(f(exclines),PY_db(exclines),'k')
%     plot(f(non_even),PY_db(non_even),'bx')
%     plot(f(non_odd),PY_db(non_odd),'ro')
%     plot(f,PstdY_db ,'color',[0.6 0.6 0.6])
%     legend('y','even NL','odd NL','noise')
%     xlabel('f [Hz]'), ylabel('magnitude [dB]')
%     xlim([0 fmax])
%     set(gca,'xscale','log')
%     title('Nonlinear distortion analysis')
%     grid
    
    figure
    hold on                                               
    plot(f(exclines),mag2db(PY(exclines)),'k')
    plot(f(non_even),mag2db(PY(non_even)),'bx')
    plot(f(non_odd),mag2db(PY(non_odd)),'ro')
    plot(f,mag2db(PstdY) ,'color',[0.6 0.6 0.6])
    legend('y','even NL','odd NL','noise')
    xlabel('f [Hz]'), ylabel('magnitude [dB]')
    xlim([0 fmax])
    set(gca,'xscale','log')
    title('Nonlinear distortion analysis')
    grid
    
    data.Y = Y;
    data.fs_mpc = fs_mpc;
    
    %%
    f_filter = find(f_conv > 20);
    PY_conv(f_filter) = 0;
    PstdY_conv(f_filter) = 0;
    N_f = N*N_;
    y_PY = SingleSidedSpectrum2TimeDomainSignal(PY_conv,N_f);
    y_PstdY = SingleSidedSpectrum2TimeDomainSignal(PstdY_conv,N_f);
    
    exclines_conv = [exclines fliplr(exclines)];
    non_even_conv = [non_even fliplr(non_even)];
    non_odd_conv  = [non_odd fliplr(non_odd)];
    
    rms_.rms_exc = rms(y_PY(exclines_conv));
    rms_.rms_ne  = rms(y_PY(non_even_conv));
    rms_.rms_no  = rms(y_PY(non_odd_conv));
    rms_.rms_noise = rms(y_PstdY);
    
    case 1
    % Assign input signals
    uff.time = t__';
    uff.signals.dimensions = 1;
    uff.signals.values = v__';

    assign_closed_loop_MPC;

    % Perform experiment
    clear Closed_loop_MPC.mat
    rtwbuild('Closed_loop_MPC')
    !./Closed_loop_MPC

    % Retrieve data
    load('Closed_loop_MPC.mat')

    y = rt_y(:,2);
    y_offset = mean(rt_yreal);
    save('y_offset','y_offset');


    data.yhat = rt_yhat;
    data.xhat = rt_xhat;
    data.yref = rt_yref;
    data.yfb = rt_yfb;
    data.yfb_sinspec = rt_yfb_sinspec;
    data.v = v__;
    data.tout = t__;
    data.umpc = rt_umpc;
    data.utot = rt_utot;
    data.sin_int = sin_int;
    data.numper = numper;
    data.kc = kc;
    data.Q = Q;
    data.R = R;
    data.Np = N;
    data.Q_UKF = Q_UKF;
    data.R_UKF = R_UKF;
    data.fs_mpc = fs_mpc;
    data.fs = fs;
    data.tplant = rt_tout;
    
    plotexperiments(data);
end
% return;
%%
if MPCswitch == 0
   MPC_state = 'noMPC';
else
    MPC_state = 'MPC';
end

folder1 = '/Figures/Distortion Analysis/Double_Poly_u3_u5/rms_values';
basefilename1 = sprintf('rms_%.1e_%s.mat', alpha, MPC_state);
fullfilename1 = fullfile(folder1, basefilename1);
save([pwd fullfilename1],'rms_');

folder2 = '/Figures/Distortion Analysis/Double_Poly_u3_u5/';
basefilename2 = sprintf('NLDA_%.1e_%s.fig', alpha, MPC_state);
fullfilename2 = fullfile(folder2, basefilename2);
saveas(figure(1),[pwd fullfilename2]);
%%
% figure()
% plot(reshape(rt_umpc, [], 5))
