function T = fC2T(C_old,C_new)

[p, n] = size(C_old);
T = eye(n);
T(n-p+1:end,:) = C_new(:,n-p+1:end)\(C_old - C_new(:,1:n-p)*T(1:n-p,:));