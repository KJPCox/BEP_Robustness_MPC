% Calc_T_matrix calculates the T_matrix value, which is subsequently used 
% to calculate the A, B and C matrices used for the PNLSS estimation.
%
%   Description:
%       The T_inverse matrix is calculated first and build as following 
%       T_inv = [a1 b1 c1 d1; a2 b2 c2 d2; a3 b3 c3 d3; a4 b4 c4 d4]; 
%       This is calculated by assigning the values of a_i, b_i and c_i with
%       i equal to 1,2,3,4 randomly. The values a_4, b_4, c_4 and d_4 are then 
%       calculated based on the fact that the new C_BLA matrix is equal 
%       C_BLA*T^-1 = [0 0 0 1].
%
%       Finally, the T matrix is calculated by solving T^-1*T=I for T.
%       This T_matrix is then used to calculate the new A,B and C matrices.

%%
close all; clear all; clc;

%%
load('A_lin_mat');
A_BLA = A;
load('B_lin_mat');
B_BLA = B;
load('C_lin_mat');
C_BLA = C;
clear A B C;

%% When files are not available
% A_BLA = [-0.808917024571652,-0.586921424906011,-0.00209620901956728,-0.00153752525194644;
%     0.586921424906011,-0.809545721039018,0.00100268262343107,0.000899310566941920;
%     -0.00209620901956774,-0.00100268262343040,0.986912137174831,-0.0783507062911589;
%     0.00153752525194622,0.000899310566942046,0.0783507062911577,0.981681884078161];
% 
% B_BLA = [-0.0108139393207521;0.00154042639035460;0.0165495606202779;-0.0161457578525910];
% 
% C_BLA = [-0.0108139393207520,-0.00154042639035556,0.0165495606202780,0.0161457578525909];
%% a
a1 = 2;
a2 = 5;
a3 = 1/4;
calc_step = C_BLA(1)*a1 + C_BLA(2)*a2 + C_BLA(3)*a3;
a4=-calc_step/C_BLA(4);
res_a=C_BLA(1)*a1 + C_BLA(2)*a2 + C_BLA(3)*a3 + C_BLA(4)*a4;       % Equal to 0

%% b
b1 = 1;
b2 = 1/2;
b3 = 6;
calc_step = C_BLA(1)*b1 + C_BLA(2)*b2 + C_BLA(3)*b3;
b4=-calc_step/C_BLA(4);
res_b=C_BLA(1)*b1 + C_BLA(2)*b2 + C_BLA(3)*b3 + C_BLA(4)*b4;       % Equal to 0

%% c
c1 = 1/6;
c2 = 4;
c3 = 3;
calc_step = C_BLA(1)*c1 + C_BLA(2)*c2 + C_BLA(3)*c3;
c4=-calc_step/C_BLA(4);
res_c=C_BLA(1)*c1 + C_BLA(2)*c2 + C_BLA(3)*c3 + C_BLA(4)*c4;       % Equal to 0

%% d
d1 = 1;
d2 = 1/8;
d3 = 4;
calc_step = C_BLA(1)*d1 + C_BLA(2)*d2 + C_BLA(3)*d3;
d4=(1-calc_step)/C_BLA(4);
res_d=C_BLA(1)*d1 + C_BLA(2)*d2 + C_BLA(3)*d3 + C_BLA(4)*d4;       % Equal to 1

%% Calculate T
T_inv = [a1 b1 c1 d1; a2 b2 c2 d2; a3 b3 c3 d3; a4 b4 c4 d4];
T = T_inv\eye(4);

%% Check
T_check = T*T_inv;                          % Equal to identity matrix (T*T^-1=I)
C = C_BLA*T_inv;                            % New C_BLA matrix, should be equal to [0 0 0 1]
C = [0 0 0 1];
%% Calculate A and B matrices
A = T*A_BLA*T_inv;
B = T*B_BLA;
