close all
clear
clc

%% Load models

load('MdlfullNLD.mat')
model_orig = NLModel;
load('model_n4.mat')
model_new = NLModel;
clear NLModel;

%% Transform model_orig into the same form as model_new

model_orig_PNLSS = model_new;
T = fC2T(model_orig.C,model_new.C);
model_orig_PNLSS.A = T*model_orig.A/T;
model_orig_PNLSS.B = T*model_orig.B;
model_orig_PNLSS.C = model_orig.C/T;
model_orig_PNLSS.D = model_orig.D;
model_orig_PNLSS.E(:,32) = T*model_orig.E;

%% Compute impulse response of all models

u = transpose([1e-2 zeros(1,1000)]);
y_orig = fFilterNLSS_outputNL(model_orig,u);
y_orig_PNLSS = fFilterNLSS(model_orig_PNLSS,u);
y_new = fFilterNLSS(model_new,u);

%% Plot impulse responses

figure
subplot(211)
plot(u)
ylabel('Input')
title('Impulse response')
subplot(212)
plot(y_orig)
hold on
plot(y_orig_PNLSS,'r')
plot(y_new,'g')
xlabel('Sample number')
ylabel('Output')
legend('original model','original model in PNLSS form','new model')