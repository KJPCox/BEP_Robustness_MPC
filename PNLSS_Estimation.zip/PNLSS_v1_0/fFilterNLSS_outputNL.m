function [y,states] = fFilterNLSS_outputNL(model,u)

[A,B,C,D,E] = deal(model.A,model.B,model.C,model.D,model.E);
NLtype = model.NLtype;
expnl = model.expnl;

if strcmp(NLtype,'output')
    [n, m] = size(B);
    p = size(C,1);
    N = length(u);
    
    y = zeros(p,N);
    states = zeros(n,N);
    
    x_t = zeros(n,1);
    u_t = zeros(m,1);
    y_t = zeros(p,1);
    for t = 1:N
        zeta_t = repmat(y_t,[1,length(expnl)]).^repmat(expnl,[p,1]);
        x_t = [A B E]*[x_t; u_t; zeta_t];
        u_t = u(t);
        y_t = [C D]*[x_t; u_t];
        
        states(:,t) = x_t;
        y(:,t) = y_t;
    end
end