%% Clear workspace, command window, and figures

clear
clc
close all
%%
load('MdlfullNLD.mat');
model_orig = NLModel;
load('model_n4.mat');
model_new = NLModel;
clear NLModel;
%%
u = transpose([1e-2 zeros(1,1000)]);
y1 = fFilterNLSS(model_new,u);
plot(y1)

y2 = fFilterNLSS(model_orig,u);