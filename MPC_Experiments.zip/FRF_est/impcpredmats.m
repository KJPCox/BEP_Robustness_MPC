function [Sx,Su,Sg,Omega,Psi] = impcpredmats(A,B,C,E,P,Q,R,N)
% According to Lectures_8_2019.pdf
Sx = zeros(N,size(A,1));
Su = zeros(N,N);
Sg = zeros(N,N);
Omega = zeros(N,N);
Psi = zeros(N,N);

p = size(B,2);
q = size(C,1);
r = size(E,2);

if q ~= length(P)
    error('Sizes of P and C do not correspond.')
end
if q ~= length(Q)
    error('Sizes of Q and C do not correspond.')
end
if p ~= size(R,2)
    error('B and R must have the same number of columns.')
end

for i = 1:N
    Sx(1+(i-1)*q:q*i,:) = C*A^i;
    for j = 1:i
        Su(1+(i-1)*q:q*i,1+(j-1)*p:p*j) = C*A^(i-j)*B;
        Sg(1+(i-1)*q:q*i,1+(j-1)*r:r*j) = C*A^(i-j)*E;
    end
    Omega(1+(i-1)*q:q*i,1+(i-1)*q:q*i) = Q;
    Psi(1+(i-1)*p:p*i,1+(i-1)*p:p*i) = R;
end
Omega(1+(N-1)*q:q*N,1+(N-1)*q:q*N) = P;

% F = 2*Gamma'*Omega*Phi;
% G = 2*(Psi + Gamma'*Omega*Gamma);
% Kmpc = [-eye(size(B,2)) zeros(size(B,2),size(F,1)-size(B,2))]*inv(G)*F; % u = Kmpc*x (only in unconstrained case!)


