function y_PY = SingleSidedSpectrum2TimeDomainSignal(PY,N)

if mod(N,2) == 0 % even aantal samples => Nyquist frequentie op het grid
    Y_PY = [PY(1); PY(2:N/2)/2; PY(N/2+1); flipud(conj(PY(2:N/2)/2))];
else % oneven aantal samples => Nyquist frequentie niet op het grid
    Y_PY = [PY(1); PY(2:(N+1)/2)/2; flipud(conj(PY(2:(N+1)/2)/2))];
end
y_PY = ifft(Y_PY)*N; % normalisatie opheffen
