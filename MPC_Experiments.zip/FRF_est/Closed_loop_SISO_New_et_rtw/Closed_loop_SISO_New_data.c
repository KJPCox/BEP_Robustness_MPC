/*
 * Closed_loop_SISO_New_data.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Closed_loop_SISO_New".
 *
 * Model version              : 1.114
 * Simulink Coder version : 9.0 (R2018b) 24-May-2018
 * C source code generated on : Thu Feb 25 12:23:56 2021
 *
 * Target selection: ectarget.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Closed_loop_SISO_New.h"
#include "Closed_loop_SISO_New_private.h"

/* Block parameters (default storage) */
P_Closed_loop_SISO_New_T Closed_loop_SISO_New_P = {
  /* Variable: kc
   * Referenced by: '<Root>/Gain'
   */
  2.0E+9,

  /* Variable: ku1
   * Referenced by: '<S5>/Gain'
   */
  0.9,

  /* Variable: ku2
   * Referenced by: '<S5>/Gain1'
   */
  0.9,

  /* Variable: ku3
   * Referenced by: '<S5>/Gain2'
   */
  0.9,

  /* Variable: ku4
   * Referenced by: '<S5>/Gain3'
   */
  0.9,

  /* Variable: ku5
   * Referenced by: '<S5>/Gain4'
   */
  0.9,

  /* Variable: ky1
   * Referenced by: '<S5>/Gain9'
   */
  0.0014711270209060165,

  /* Variable: ky2
   * Referenced by: '<S5>/Gain8'
   */
  0.0010953537484850297,

  /* Variable: ky3
   * Referenced by: '<S5>/Gain7'
   */
  0.0013073093857132075,

  /* Variable: ky4
   * Referenced by: '<S5>/Gain6'
   */
  0.0016010332156881847,

  /* Variable: ky5
   * Referenced by: '<S5>/Gain5'
   */
  0.000931519218060358,

  /* Variable: o1
   * Referenced by: '<S5>/Constant'
   */
  3.9968160811765436,

  /* Variable: o2
   * Referenced by: '<S5>/Constant1'
   */
  4.416226011940485,

  /* Variable: o3
   * Referenced by: '<S5>/Constant2'
   */
  7.8718536098555614,

  /* Variable: o4
   * Referenced by: '<S5>/Constant3'
   */
  6.9928364017859774,

  /* Variable: o5
   * Referenced by: '<S5>/Constant5'
   */
  5.9916004708268584,

  /* Variable: p1
   * Referenced by: '<S5>/Polynomial'
   */
  { 0.0023790071185090366, -0.057630635083187817, 0.5896882252898068,
    -3.3209450195567691, 11.244874343339497, -23.502053155795878,
    30.015845809243448, -23.007983101497519, 11.864336262350207 },

  /* Variable: p2
   * Referenced by: '<S5>/Polynomial1'
   */
  { 0.00074322211504302359, -0.021362472547475635, 0.25244502957816212,
    -1.6164472306616784, 6.1785801271350138, -14.586712686983553,
    21.247636173693124, -19.073476076963949, 11.844168873563451 },

  /* Variable: p3
   * Referenced by: '<S5>/Polynomial2'
   */
  { 0.00074322211504302359, -0.021362472547475635, 0.25244502957816212,
    -1.6164472306616784, 6.1785801271350138, -14.586712686983553,
    21.247636173693124, -19.073476076963949, 11.844168873563451 },

  /* Variable: p4
   * Referenced by: '<S5>/Polynomial3'
   */
  { -0.00072279458047684608, 0.01402075217613682, -0.1085939164635078,
    0.40135172950343151, -0.51105216718729585, -1.2832980716721274,
    6.0006452077685362, -10.063497320587294, 9.84199867973437 },

  /* Variable: p5
   * Referenced by: '<S5>/Polynomial5'
   */
  { -0.00072279458047684608, 0.01402075217613682, -0.1085939164635078,
    0.40135172950343151, -0.51105216718729585, -1.2832980716721274,
    6.0006452077685362, -10.063497320587294, 9.84199867973437 },

  /* Variable: y_offset
   * Referenced by: '<Root>/Constant1'
   */
  0.0049110294244077849,

  /* Mask Parameter: CompareToConstant_const
   * Referenced by: '<S1>/Constant'
   */
  0.00055,

  /* Expression: 1
   * Referenced by: '<Root>/nsensor'
   */
  1.0,

  /* Computed Parameter: ec_EL3102_adc_P1_Size
   * Referenced by: '<S6>/ec_EL3102_adc'
   */
  { 1.0, 1.0 },

  /* Expression: link_id
   * Referenced by: '<S6>/ec_EL3102_adc'
   */
  1.0,

  /* Computed Parameter: ec_EL3102_adc_P1_Size_j
   * Referenced by: '<S8>/ec_EL3102_adc'
   */
  { 1.0, 1.0 },

  /* Expression: link_id
   * Referenced by: '<S8>/ec_EL3102_adc'
   */
  2.0,

  /* Computed Parameter: ec_EL3102_adc_P1_Size_k
   * Referenced by: '<S7>/ec_EL3102_adc'
   */
  { 1.0, 1.0 },

  /* Expression: link_id
   * Referenced by: '<S7>/ec_EL3102_adc'
   */
  3.0,

  /* Expression: 0
   * Referenced by: '<Root>/Constant'
   */
  0.0,

  /* Computed Parameter: ec_EL4132_dac_P1_Size
   * Referenced by: '<S9>/ec_EL4132_dac'
   */
  { 1.0, 1.0 },

  /* Expression: link_id
   * Referenced by: '<S9>/ec_EL4132_dac'
   */
  1.0,

  /* Expression: 0
   * Referenced by: synthesized block
   */
  0.0,

  /* Expression: 2.5
   * Referenced by: '<S4>/Saturation'
   */
  2.5,

  /* Expression: -2.5
   * Referenced by: '<S4>/Saturation'
   */
  -2.5,

  /* Computed Parameter: ec_EL4132_dac_P1_Size_n
   * Referenced by: '<S10>/ec_EL4132_dac'
   */
  { 1.0, 1.0 },

  /* Expression: link_id
   * Referenced by: '<S10>/ec_EL4132_dac'
   */
  2.0,

  /* Expression: 2.5
   * Referenced by: '<S4>/Saturation1'
   */
  2.5,

  /* Expression: -2.5
   * Referenced by: '<S4>/Saturation1'
   */
  -2.5,

  /* Expression: 2.5
   * Referenced by: '<S4>/Saturation2'
   */
  2.5,

  /* Expression: -2.5
   * Referenced by: '<S4>/Saturation2'
   */
  -2.5,

  /* Expression: 2.5
   * Referenced by: '<S2>/Saturation2'
   */
  2.5,

  /* Expression: -2.5
   * Referenced by: '<S2>/Saturation2'
   */
  -2.5
};
