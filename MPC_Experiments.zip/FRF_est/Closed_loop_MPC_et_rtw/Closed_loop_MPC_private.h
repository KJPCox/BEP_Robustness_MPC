/*
 * Closed_loop_MPC_private.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Closed_loop_MPC".
 *
 * Model version              : 1.172
 * Simulink Coder version : 9.0 (R2018b) 24-May-2018
 * C source code generated on : Wed Jun 23 14:54:02 2021
 *
 * Target selection: ectarget.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Closed_loop_MPC_private_h_
#define RTW_HEADER_Closed_loop_MPC_private_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
#include "zero_crossing_types.h"
#include "Closed_loop_MPC.h"

/* Used by FromWorkspace Block: '<Root>/From Workspace1' */
#ifndef rtInterpolate
# define rtInterpolate(v1,v2,f1,f2)    (((v1)==(v2))?((double)(v1)): (((f1)*((double)(v1)))+((f2)*((double)(v2)))))
#endif

#ifndef rtRound
# define rtRound(v)                    ( ((v) >= 0) ? floor((v) + 0.5) : ceil((v) - 0.5) )
#endif

extern real_T rt_powd_snf(real_T u0, real_T u1);
extern real_T rt_roundd_snf(real_T u);
extern real_T rt_hypotd_snf(real_T u0, real_T u1);
extern int32_T div_nzp_s32_floor(int32_T numerator, int32_T denominator);
extern void ec_EL3102_adc(SimStruct *rts);
extern void ec_EL4132_dac(SimStruct *rts);
void Closed_loop_MPC_output0(void);
void Closed_loop_MPC_update0(void);
void Closed_loop_MPC_output2(void);
void Closed_loop_MPC_update2(void);
void Closed_loop_MPC_output3(void);
void Closed_loop_MPC_update3(void);

#endif                                 /* RTW_HEADER_Closed_loop_MPC_private_h_ */
