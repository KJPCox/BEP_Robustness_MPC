function [PY,PstdY,f] = fSingleSidedAmplitudeSpectrum(Y,fs)
% fSingleSidedAmplitudeSpectrum outputs:
%       - (PY) single-sided amplitude spectrum of data in Y;
%       - (PstdY) single-sided amplitude spectrum of the standard deviation
%       in Y, due to noise;
%       - (f) corresponding frequency grid [Hz].
% Based on inputs:
%       - (Y) [N x P x R] FFT of steady-state measurement data in Y, where 
%       P is the number of periods, N the number of data points per period 
%       and R the number of realisations;
%       - (fs) sampling frequency [Hz].

[N,P,~] = size(Y);

f = fs*(0:N/2)/N; % frequency grid

NY = Y - repmat(mean(Y,2),[1 P 1]); % Y - Ymean_R for every [N x P x R]
stdY = sqrt(1/(P-1)/P*sum(abs(NY).^2,2)); % Standard deviation of the output spectrum  

PstdY_ = squeeze(abs(stdY/N)); % Normalisation
PstdY = PstdY_(1:N/2+1,:); % Positive frequencies
PstdY(2:end-1,:) = 2*PstdY(2:end-1,:); % Double the energy in positive frequencies (except for DC and Nyquist frequency)
PstdY = mean(PstdY,2); % Average over R

PY_ = squeeze(abs(mean(Y,2)/N)); % Normalisation
PY = PY_(1:N/2+1,:); % Positive frequencies
PY(2:end-1,:) = 2*PY(2:end-1,:); % Double the energy in positive frequencies (except for DC and Nyquist frequency)
PY = mean(PY,2); % Average over R
end