function yk = MeasurementFcn(xk,C)
    % Recreate discrete state-space matrices from U
    C = reshape(C,1,4);
        
    % Output equation
    yk = C*xk;
end